package com.example.randomblocks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Статистика игроков (1.13.0): убийства и смерти для скорборда («У/С»).
 *
 * <p>Убийства считаются только по игрокам, смерти — любые (падение, лава, мобы, ПВП).
 * Хранится в {@code config/randomblocks-stats.json}.</p>
 */
public final class Stats {

	public static final class Entry {
		public String name = "";
		public int kills;
		public int deaths;
	}

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Type TYPE = new TypeToken<LinkedHashMap<String, Entry>>() { }.getType();

	private static final Map<UUID, Entry> ENTRIES = new HashMap<>();

	private Stats() {
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("randomblocks-stats.json");
	}

	public static synchronized void load() {
		ENTRIES.clear();
		Path path = file();
		if (!Files.exists(path)) {
			return;
		}
		try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
			Map<String, Entry> raw = GSON.fromJson(reader, TYPE);
			if (raw == null) {
				return;
			}
			raw.forEach((key, value) -> {
				try {
					if (value != null) {
						if (value.name == null) {
							value.name = "";
						}
						ENTRIES.put(UUID.fromString(key), value);
					}
				} catch (IllegalArgumentException ignored) {
					// битая запись
				}
			});
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("stats file not read: {}", t.toString());
		}
	}

	public static synchronized void save() {
		Map<String, Entry> raw = new LinkedHashMap<>();
		ENTRIES.forEach((uuid, entry) -> raw.put(uuid.toString(), entry));
		try (Writer writer = Files.newBufferedWriter(file(), StandardCharsets.UTF_8)) {
			GSON.toJson(raw, writer);
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("stats file not saved: {}", t.toString());
		}
	}

	private static synchronized Entry entry(UUID uuid, String name) {
		Entry entry = ENTRIES.computeIfAbsent(uuid, key -> new Entry());
		if (name != null && !name.isEmpty()) {
			entry.name = name;
		}
		return entry;
	}

	public static void touch(UUID uuid, String name) {
		synchronized (Stats.class) {
			entry(uuid, name);
		}
	}

	public static int kills(UUID uuid) {
		synchronized (Stats.class) {
			Entry entry = ENTRIES.get(uuid);
			return entry == null ? 0 : entry.kills;
		}
	}

	public static int deaths(UUID uuid) {
		synchronized (Stats.class) {
			Entry entry = ENTRIES.get(uuid);
			return entry == null ? 0 : entry.deaths;
		}
	}

	public static void addKill(UUID uuid, String name) {
		synchronized (Stats.class) {
			entry(uuid, name).kills++;
		}
		save();
	}

	public static void addDeath(UUID uuid, String name) {
		synchronized (Stats.class) {
			entry(uuid, name).deaths++;
		}
		save();
	}

	/** «1/0» — убийства/смерти, как в скорборде. */
	public static String text(UUID uuid) {
		return kills(uuid) + "/" + deaths(uuid);
	}
}
