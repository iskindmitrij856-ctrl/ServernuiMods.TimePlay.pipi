package com.example.randomblocks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.network.ServerPlayerEntity;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Деньги и «риллики» (1.13.0).
 *
 * <p>Две валюты на игрока: обычные деньги ({@code /eco}) и риллики ({@code /p}) — как на фото
 * скорборда владельца сервера. Хранятся в {@code config/randomblocks-economy.json} и переживают
 * перезапуск. Команды умеют работать и с офлайн-игроками: ник → UUID берётся из привилегий
 * (там сохраняются все, кто когда-либо заходил).</p>
 */
public final class Economy {

	public static final class Entry {
		public String name = "";
		public long money;
		public long rubles;
	}

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Type TYPE = new TypeToken<LinkedHashMap<String, Entry>>() { }.getType();

	private static final Map<UUID, Entry> ENTRIES = new HashMap<>();

	private Economy() {
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("randomblocks-economy.json");
	}

	public static synchronized void load() {
		ENTRIES.clear();
		Path path = file();
		if (!Files.exists(path)) {
			return;
		}
		try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
			Map<String, Entry> raw = GSON.fromJson(reader, TYPE);
			if (raw == null) {
				return;
			}
			for (Map.Entry<String, Entry> item : raw.entrySet()) {
				try {
					Entry entry = item.getValue();
					if (entry == null) {
						continue;
					}
					if (entry.name == null) {
						entry.name = "";
					}
					ENTRIES.put(UUID.fromString(item.getKey()), entry);
				} catch (IllegalArgumentException ignored) {
					// битая запись — пропускаем
				}
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("economy file not read: {}", t.toString());
		}
	}

	public static synchronized void save() {
		Map<String, Entry> raw = new LinkedHashMap<>();
		ENTRIES.forEach((uuid, entry) -> raw.put(uuid.toString(), entry));
		try (Writer writer = Files.newBufferedWriter(file(), StandardCharsets.UTF_8)) {
			GSON.toJson(raw, writer);
		} catch (IOException e) {
			RandomBlocks.LOGGER.warn("economy file not saved: {}", e.toString());
		}
	}

	private static synchronized Entry entry(UUID uuid, String name) {
		Entry entry = ENTRIES.computeIfAbsent(uuid, key -> new Entry());
		if (name != null && !name.isEmpty()) {
			entry.name = name;
		}
		return entry;
	}

	/** Запомнить ник (чтобы потом можно было выдать деньги офлайн-игроку). */
	public static void remember(ServerPlayerEntity player) {
		boolean changed;
		synchronized (Economy.class) {
			Entry entry = entry(player.getUuid(), player.getEntityName());
			changed = !player.getEntityName().equals(entry.name);
			entry.name = player.getEntityName();
		}
		if (changed) {
			save();
		}
	}

	/** UUID по нику: сначала среди тех, кто уже сохранён, потом — среди онлайн-игроков. */
	public static UUID uuidByName(String name) {
		synchronized (Economy.class) {
			for (Map.Entry<UUID, Entry> item : ENTRIES.entrySet()) {
				if (item.getValue().name != null && item.getValue().name.equalsIgnoreCase(name)) {
					return item.getKey();
				}
			}
		}
		return null;
	}

	public static String nameOf(UUID uuid) {
		synchronized (Economy.class) {
			Entry entry = ENTRIES.get(uuid);
			return entry == null ? null : entry.name;
		}
	}

	public static long money(UUID uuid) {
		synchronized (Economy.class) {
			Entry entry = ENTRIES.get(uuid);
			return entry == null ? 0L : entry.money;
		}
	}

	public static long rubles(UUID uuid) {
		synchronized (Economy.class) {
			Entry entry = ENTRIES.get(uuid);
			return entry == null ? 0L : entry.rubles;
		}
	}

	public static void setMoney(UUID uuid, String name, long value) {
		synchronized (Economy.class) {
			entry(uuid, name).money = Math.max(0L, value);
		}
		save();
	}

	public static void addMoney(UUID uuid, String name, long delta) {
		setMoney(uuid, name, money(uuid) + delta);
	}

	public static void setRubles(UUID uuid, String name, long value) {
		synchronized (Economy.class) {
			entry(uuid, name).rubles = Math.max(0L, value);
		}
		save();
	}

	public static void addRubles(UUID uuid, String name, long delta) {
		setRubles(uuid, name, rubles(uuid) + delta);
	}

	/** «99 488» — как на фото скорборда: разряды разделены пробелом. */
	public static String format(long value) {
		String digits = Long.toString(Math.abs(value));
		StringBuilder out = new StringBuilder();
		int count = 0;
		for (int i = digits.length() - 1; i >= 0; i--) {
			out.append(digits.charAt(i));
			if (++count % 3 == 0 && i > 0) {
				out.append(' ');
			}
		}
		return (value < 0 ? "-" : "") + out.reverse();
	}
}
