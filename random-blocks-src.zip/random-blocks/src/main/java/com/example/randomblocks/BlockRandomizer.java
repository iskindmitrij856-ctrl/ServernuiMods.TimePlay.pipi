package com.example.randomblocks;

import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.Material;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Вся логика «наступил на блок — он стал другим блоком».
 */
public final class BlockRandomizer {

	private BlockRandomizer() {
	}

	/** Кэш списка блоков, которые могут выпасть. Сбрасывается при перезагрузке конфига. */
	private static List<Block> pool;

	public static void invalidatePool() {
		pool = null;
	}

	public static List<Block> pool(ModConfig cfg) {
		List<Block> cached = pool;
		if (cached == null) {
			cached = buildPool(cfg);
			pool = cached;
			RandomBlocks.LOGGER.info("Block pool built: {} blocks can be produced", cached.size());
		}
		return cached;
	}

	private static List<Block> buildPool(ModConfig cfg) {
		List<Block> list = new ArrayList<>();
		Registry.BLOCK.stream().forEach(block -> {
			BlockState state = block.getDefaultState();
			if (!isFullCubeBlock(state)) return;                                  // воздух, жидкости, неполные блоки
			if (block instanceof BlockEntityProvider) return;                      // сундуки, печи и т.п.
			if (cfg.isProduceBlocked(block)) return;                               // блэклист
			if (!cfg.allowHazardous && cfg.isHazardous(block)) return;            // магма, кактус, огонь...
			if (cfg.naturalOnly && !isNatural(state.getMaterial())) return;        // только природные материалы
			list.add(block);
		});

		// Блоки, которые игрок явно добавил в extraBlocks (например, стекло или лёд).
		for (String rawId : cfg.extraBlocks) {
			Block block = lookup(rawId);
			if (block != null && !list.contains(block)) {
				list.add(block);
			}
		}
		return list;
	}

	public static Block lookup(String rawId) {
		if (rawId == null) {
			return null;
		}
		Identifier id = Identifier.tryParse(rawId.trim());
		if (id == null) {
			return null;
		}
		// Registry#containsId есть только в клиентском jar 1.16.5 — на сервере используем getIds().
		if (!Registry.BLOCK.getIds().contains(id)) {
			return null;
		}
		return Registry.BLOCK.get(id);
	}

	/** Полноразмерный куб (камень, земля, дерево…). Тогда у блока одинаковая высота и игрок ничего не заметит. */
	public static boolean isFullCubeBlock(BlockState state) {
		return !state.isAir() && state.isOpaque() && !state.getMaterial().isLiquid();
	}

	/**
	 * Главная страховка: у блока должна быть коллизия ровно 1 блок в высоту.
	 * Тогда замена блока никогда не сдвинет игрока (иначе клиент «прыгает» и сервер
	 * может кикнуть его за неверную позицию). Отсекает грядки, тропинки, песок душ и т.п.
	 */
	public static boolean isFullHeightCollision(BlockView world, BlockPos pos, BlockState state) {
		VoxelShape shape = state.getCollisionShape(world, pos);
		if (shape.isEmpty()) {
			return false;
		}
		Box box = shape.getBoundingBox();
		return box.minY > -0.001D && box.getYLength() >= 0.999D;
	}

	private static boolean isNatural(Material material) {
		return material == Material.STONE
				|| material == Material.SOIL
				|| material == Material.AGGREGATE
				|| material == Material.WOOD
				|| material == Material.NETHER_WOOD
				|| material == Material.LEAVES
				|| material == Material.PLANT
				|| material == Material.ICE
				|| material == Material.DENSE_ICE;
	}

	/**
	 * Блок, на котором стоит игрок: сначала берём блок «в ногах», а если там воздух или трава —
	 * значит игрок стоит на том, что под ним.
	 *
	 * @return null, если игрок в воде/лаве (там ничего не трогаем).
	 */
	public static BlockPos blockUnder(PlayerEntity player) {
		World world = player.world;
		BlockPos feet = player.getBlockPos();
		BlockState atFeet = world.getBlockState(feet);
		if (atFeet.getMaterial().isLiquid()) {
			return null;
		}
		if (atFeet.isAir() || !atFeet.getMaterial().isSolid()) {
			return feet.down();
		}
		return feet;
	}

	// ------------------------------------------------------------------
	//  «На этот блок уже наступали» — чтобы стоя на месте блок не переделывался каждый тик
	// ------------------------------------------------------------------

	private static final Map<UUID, BlockPos> LAST_BLOCK = new HashMap<>();

	public static boolean isSameAsLast(ServerPlayerEntity player, BlockPos pos) {
		return pos.equals(LAST_BLOCK.get(player.getUuid()));
	}

	public static void rememberLast(ServerPlayerEntity player, BlockPos pos) {
		if (LAST_BLOCK.size() > 512) {
			LAST_BLOCK.clear();
		}
		LAST_BLOCK.put(player.getUuid(), pos.toImmutable());
	}

	/** Забыть все «последние блоки» — вызывается при /randomblock start, чтобы мод сработал сразу. */
	public static void forgetLastBlocks() {
		LAST_BLOCK.clear();
	}

	/** Блочные проверки (без мира): полный куб, защита, содержимое. */
	public static boolean canReplaceBlock(Block block, ModConfig cfg) {
		if (!isFullCubeBlock(block.getDefaultState())) {
			return false;
		}
		if (cfg.protectBlockEntities && block instanceof BlockEntityProvider) {
			return false;
		}
		return !cfg.isProtected(block);
	}

	/** Можно ли вообще превратить этот блок. */
	public static boolean canReplace(World world, BlockPos pos, ModConfig cfg) {
		BlockState state = world.getBlockState(pos);
		if (state.isAir() || state.getMaterial().isLiquid()) {
			return false;
		}
		Block block = state.getBlock();
		if (cfg.protectBlockEntities && block instanceof BlockEntityProvider) {
			return false;
		}
		if (cfg.isProtected(block)) {
			return false;
		}
		if (cfg.onlyFullBlocks && !isFullHeightCollision(world, pos, state)) {
			return false;
		}
		return true;
	}

	/** Превращает блок в случайный другой. @return true, если что-то изменилось. */
	public static boolean transform(ServerWorld world, BlockPos pos, ModConfig cfg) {
		if (!canReplace(world, pos, cfg)) {
			return false;
		}
		List<Block> blocks = pool(cfg);
		if (blocks.isEmpty()) {
			return false;
		}
		BlockState current = world.getBlockState(pos);
		BlockState next = current;
		// Ищем именно ДРУГОЙ блок, у которого такая же высота (чтобы игрок не сдвинулся).
		for (int attempt = 0; attempt < 32; attempt++) {
			next = blocks.get(world.random.nextInt(blocks.size())).getDefaultState();
			if (next.getBlock() == current.getBlock()) {
				continue;
			}
			if (!cfg.onlyFullBlocks || isFullHeightCollision(world, pos, next)) {
				break;
			}
		}
		if (next.getBlock() == current.getBlock()) {
			return false;
		}
		if (cfg.dropItems) {
			// Раньше здесь стоял world.breakBlock(pos, true), но маппинги сборки указывают на метод,
			// которого в рантайме нет (NoSuchMethodError). Ломаем вручную: дроп + звук и частицы.
			BlockState old = world.getBlockState(pos);
			Block.dropStacks(old, world, pos);
			world.syncWorldEvent(2001, pos, Block.getRawIdFromState(old));
		}
		world.setBlockState(pos, next, 3);
		return true;
	}
}
