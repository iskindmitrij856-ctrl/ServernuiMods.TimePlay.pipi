package com.example.randomblocks.command;

import com.example.randomblocks.Bans;
import com.example.randomblocks.ItemTimerManager;
import com.example.randomblocks.Permissions;
import com.example.randomblocks.RandomBlocks;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;

/**
 * Блокировки (1.13.0): {@code /ban <ник> [время] [причина]}, {@code /unban <ник>},
 * {@code /bans} — список.
 *
 * <p>Всё это доступно только OWNER и <b>видно только владельцам</b> (и в консоли сервера):
 * обычным игрокам мод про баны ничего не пишет, чтобы не засорять чат.</p>
 *
 * <p>Время как везде в моде: {@code 30m}, {@code 2h}, {@code 7d}; если не указать — навсегда.
 * Причина — остаток строки (можно по-русски, с пробелами).</p>
 */
public final class BanCommand {

	private BanCommand() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
			try {
				registerAll(dispatcher);
				RandomBlocks.LOGGER.info("Ban commands registered");
			} catch (Throwable t) {
				RandomBlocks.LOGGER.error("Ban commands not registered: {}", t.toString());
			}
		});
	}

	private static void registerAll(CommandDispatcher<ServerCommandSource> dispatcher) {
		// Ванильные /ban и /pardon требуют OP — убираем их узлы, чтобы наши версии (для OWNER)
		// были видны обычным игрокам с привилегией.
		VipCommand.dropVanilla(dispatcher, "ban");
		VipCommand.dropVanilla(dispatcher, "pardon");
		VipCommand.dropVanilla(dispatcher, "banlist");

		dispatcher.register(CommandManager.literal("ban")
				.executes(context -> Suggestions.usage(context,
						"§6Как использовать: §e/ban <ник> [время] [причина]§7 — время вида §e30m§7, §e2h§7, §e7d§7 (без времени — навсегда)."))
				.then(CommandManager.argument("ник", StringArgumentType.word()).suggests(Suggestions.NICKS)
						.executes(context -> ban(context, 0L, "без причины"))
						.then(CommandManager.argument("время", StringArgumentType.word()).suggests(Suggestions.TIMES)
								.executes(context -> ban(context,
										banMillis(context, StringArgumentType.getString(context, "время")),
										"без причины"))
								.then(CommandManager.argument("причина", StringArgumentType.greedyString())
										.suggests(Suggestions.BAN_REASONS)
										.executes(context -> ban(context,
												banMillis(context, StringArgumentType.getString(context, "время")),
												StringArgumentType.getString(context, "причина")))))));

		dispatcher.register(CommandManager.literal("unban")
				.executes(context -> Suggestions.usage(context, "§6Как использовать: §e/unban <ник>§7 — снять блокировку."))
				.then(CommandManager.argument("ник", StringArgumentType.word()).suggests(Suggestions.NICKS)
						.executes(BanCommand::unban)));

		dispatcher.register(CommandManager.literal("bans").executes(BanCommand::list));
	}

	/** Игрок-отправитель или null (из консоли игрока нет — {@code getPlayer()} там бросает исключение). */
	private static ServerPlayerEntity playerOf(ServerCommandSource source) {
		return source.getEntity() instanceof ServerPlayerEntity ? (ServerPlayerEntity) source.getEntity() : null;
	}

	/** «forever» и «навсегда» — бан без срока (иначе парсер вернул бы −1). */
	private static long banMillis(CommandContext<ServerCommandSource> context, String raw) {
		if (raw == null) {
			return 0L;
		}
		String text = raw.trim().toLowerCase(java.util.Locale.ROOT);
		if (text.equals("forever") || text.equals("permanent") || text.equals("навсегда")) {
			return 0L;
		}
		int seconds = ItemTimerManager.parseDurationSeconds(raw);
		return seconds > 0 ? seconds * 1000L : 0L;
	}

	private static int ban(CommandContext<ServerCommandSource> context, long millis, String reason)
			throws CommandSyntaxException {
		ServerPlayerEntity owner = playerOf(context.getSource());
		if (!Permissions.ownerOrOp(context.getSource())) {
			context.getSource().sendError(new LiteralText("§cБлокировать игроков может только OWNER (или оператор/консоль)."));
			return 0;
		}
		String name = StringArgumentType.getString(context, "ник");
		long until = millis > 0 ? System.currentTimeMillis() + millis : 0L;

		String by = owner == null ? "консоль" : owner.getEntityName();
		Bans.ban(name, reason, by, until);
		Bans.Entry entry = Bans.active(name);
		onlyOwner(context.getSource(), "§c[Баны]§r §e" + name + "§r забанен на §e" + Bans.left(entry)
				+ "§r. Причина: §f" + reason);

		ServerPlayerEntity target = context.getSource().getMinecraftServer().getPlayerManager().getPlayer(name);
		if (target != null) {
			target.networkHandler.disconnect(new LiteralText("§cТы забанен на этом сервере.\n§7Причина: §f"
					+ reason + "\n§7Бан: §f" + Bans.left(entry)));
		}
		return 1;
	}

	private static int unban(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		if (!Permissions.ownerOrOp(context.getSource())) {
			context.getSource().sendError(new LiteralText("§cСнимать блокировки может только OWNER (или оператор/консоль)."));
			return 0;
		}
		String name = StringArgumentType.getString(context, "ник");
		boolean removed = Bans.unban(name);
		onlyOwner(context.getSource(), removed
				? "§c[Баны]§r §e" + name + "§r разбанен."
				: "§c[Баны]§r §e" + name + "§r в списке банов не найден.");
		return removed ? 1 : 0;
	}

	private static int list(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		if (!Permissions.ownerOrOp(context.getSource())) {
			context.getSource().sendError(new LiteralText("§cСписок банов видят только владельцы."));
			return 0;
		}
		java.util.List<Bans.Entry> all = Bans.all();
		if (all.isEmpty()) {
			context.getSource().sendFeedback(new LiteralText("§6[Баны]§r список пуст."), false);
			return 0;
		}
		context.getSource().sendFeedback(new LiteralText("§6[Баны]§r всего: §e" + all.size()), false);
		for (Bans.Entry entry : all) {
			context.getSource().sendFeedback(new LiteralText("§7· §e" + entry.name + "§7 — " + Bans.left(entry)
					+ "§7, причина: §f" + entry.reason + "§7 (бан: " + entry.by + ")"), false);
		}
		return all.size();
	}

	/** Сообщение про бан — только владельцам и тому, кто выполнил команду (и в лог сервера). */
	private static void onlyOwner(ServerCommandSource source, String message) {
		RandomBlocks.LOGGER.info("[Баны] {}", message.replaceAll("§.", ""));
		if (source.getEntity() == null) {
			source.sendFeedback(new LiteralText(message), false);       // консоль
		}
		for (ServerPlayerEntity player : source.getMinecraftServer().getPlayerManager().getPlayerList()) {
			if (Permissions.isOwner(player)) {
				player.sendMessage(new LiteralText(message), false);
			}
		}
	}
}
