package com.example.randomblocks;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Кто что может: лестница команд по привилегиям.
 *
 * <p>Правило владельца сервера: <b>привилегия выше имеет все команды привилегий ниже</b>,
 * поэтому здесь для каждой команды указана только та привилегия, с которой она появляется,
 * а проверка — «моя привилегия не ниже нужной».</p>
 *
 * <p>OWNER может всё и без ограничений: у него не работают ни проверки привилегий,
 * ни перезарядки (см. {@link Cooldowns}).</p>
 */
public final class Permissions {

	// ------------------------------------------------------------------
	//  Названия возможностей (узлов)
	// ------------------------------------------------------------------

	public static final String HOME = "home";
	public static final String SPAWN = "spawn";
	public static final String RTP = "rtp";
	public static final String CRAFT = "craft";
	public static final String HAT = "hat";
	public static final String FEED = "feed";
	public static final String RTP_FAR = "rtpfar";
	public static final String ENDERCHEST = "enderchest";
	public static final String EXTINGUISH = "ext";
	public static final String CLEAR = "clear";
	public static final String REPAIR = "repair";
	public static final String NEAR = "near";
	public static final String INVSEE = "invsee";
	public static final String INVSEE_TAKE = "invsee.take";
	public static final String REPAIR_ALL = "repairall";
	public static final String HEAL = "heal";
	public static final String BROADCAST = "broadcast";
	public static final String LIGHTNING = "lightning";
	public static final String RTP_NEAR = "rtpnear";
	public static final String FLY = "fly";
	public static final String GRANT = "grant";
	public static final String WEATHER = "weather";
	public static final String TIME = "time";
	/** Выдавать привилегии ниже своей (и снимать их). */
	public static final String RANK_MANAGE = "rank.manage";

	/** Привилегия, с которой доступна команда. */
	public static Rank required(String node) {
		switch (node) {
			case HOME:
			case SPAWN:
			case RTP:
				return Rank.PLAYER;
			case CRAFT:                                    // /craft
				return Rank.HERO;
			case HAT:
			case FEED:
			case RTP_FAR:
				return Rank.TITAN;
			case ENDERCHEST:
			case EXTINGUISH:
			case CLEAR:
				return Rank.AVENDER;
			case REPAIR:
			case NEAR:
				return Rank.OVERLORD;
			case INVSEE:
			case REPAIR_ALL:
			case HEAL:
				return Rank.MAGISTER;
			case BROADCAST:
			case LIGHTNING:
			case RTP_NEAR:
				return Rank.IMPERATOR;
			case FLY:
			case GRANT:
			case WEATHER:
			case TIME:
				return Rank.DRAGON;
			case INVSEE_TAKE:
				return Rank.OWNER;
			case RANK_MANAGE:
				return Rank.HERO;
			default:
				return Rank.OWNER;
		}
	}

	/** Доступна ли игроку команда (с учётом того, включены ли команды привилегий). */
	public static boolean has(ServerPlayerEntity player, String node) {
		if (player == null) {
			return false;
		}
		if (!RandomBlocks.getConfig().rankCommandsEnabled) {
			return false;
		}
		return rankOf(player).weight >= required(node).weight;
	}

	public static Rank rankOf(ServerPlayerEntity player) {
		return RankManager.rankOf(player);
	}

	/** Доступ для команд владельца: сам OWNER или консоль/оператор (чтобы работало из консоли). */
	public static boolean ownerOrOp(net.minecraft.server.command.ServerCommandSource source) {
		if (source == null) {
			return false;
		}
		if (source.getEntity() instanceof ServerPlayerEntity
				&& isOwner((ServerPlayerEntity) source.getEntity())) {
			return true;
		}
		return source.hasPermissionLevel(2);
	}

	public static boolean isOwner(ServerPlayerEntity player) {
		return rankOf(player) == Rank.OWNER;
	}

	/** Сколько точек дома можно игроку. */
	public static int homeLimit(ServerPlayerEntity player) {
		if (!RandomBlocks.getConfig().rankCommandsEnabled) {
			return RandomBlocks.getConfig().maxHomes;
		}
		return rankOf(player).homes;
	}

	/** Цифра лимита для сообщений: у OWNER — «∞». */
	public static String homeLimitText(ServerPlayerEntity player) {
		int limit = homeLimit(player);
		return limit == Integer.MAX_VALUE ? "∞" : Integer.toString(limit);
	}

	/**
	 * Может ли игрок распоряжаться указанной привилегией.
	 * OWNER — любую, остальные — только строго ниже своей.
	 */
	public static boolean canManage(ServerPlayerEntity issuer, Rank target) {
		if (issuer == null) {
			return false;
		}
		Rank own = rankOf(issuer);
		if (own == Rank.OWNER) {
			return true;
		}
		return target.weight < own.weight;
	}

	/** Может ли игрок вообще выдавать/снимать привилегии. */
	public static boolean canManageAny(ServerPlayerEntity player) {
		return has(player, RANK_MANAGE) || isOwner(player);
	}

	/** Короткая строка о том, что доступно игроку — для /rank. */
	public static String availableText(ServerPlayerEntity player) {
		StringBuilder list = new StringBuilder();
		add(list, player, RTP, "/rtp");
		add(list, player, CRAFT, "/craft");
		add(list, player, HAT, "/hat");
		add(list, player, FEED, "/feed");
		add(list, player, RTP_FAR, "/rtpfar");
		add(list, player, ENDERCHEST, "/ec");
		add(list, player, EXTINGUISH, "/ext");
		add(list, player, CLEAR, "/clear");
		add(list, player, REPAIR, "/repair");
		add(list, player, NEAR, "/near");
		add(list, player, HEAL, "/heal");
		add(list, player, INVSEE, "/invsee");
		add(list, player, REPAIR_ALL, "/repair all");
		add(list, player, BROADCAST, "/broadcast");
		add(list, player, LIGHTNING, "/lightning");
		add(list, player, RTP_NEAR, "/rtpnear");
		add(list, player, FLY, "/fly");
		add(list, player, GRANT, "/grant");
		add(list, player, WEATHER, "/sun,/rain");
		add(list, player, TIME, "/day,/night");
		return list.toString();
	}

	private static void add(StringBuilder list, ServerPlayerEntity player, String node, String label) {
		if (has(player, node)) {
			if (list.length() > 0) {
				list.append("§7, §e");
			}
			list.append(label);
		}
	}
}
