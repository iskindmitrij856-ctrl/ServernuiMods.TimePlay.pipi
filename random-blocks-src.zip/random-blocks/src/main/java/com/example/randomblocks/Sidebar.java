package com.example.randomblocks;

import net.minecraft.network.packet.s2c.play.ScoreboardDisplayS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardObjectiveUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardPlayerUpdateS2CPacket;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ServerScoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Скорборд справа (1.13.0) — как на фото владельца сервера, но без «Клан» и «Ромашки»:
 *
 * <pre>
 *        ГРИФ #1        (заголовок, настраивается)
 *   ▌ Ник: Tester
 *   ▌ Ранг: …           (бейдж привилегии — там, где он есть)
 *   ▌ У/С: 1/0
 *   ▌ Баланс: 99 488 ₽
 *   ▌ Рилликов: 0 ₽
 *   ▌ Пинг: 30 мс
 *        TimePlay.pipi
 * </pre>
 *
 * <p>Ванильный сайдбар один на всех игроков, а строки у каждого свои — поэтому мод собирает
 * скорборд <b>каждому игроку отдельно</b>: объектив и строки отправляются пакетами прямо в его
 * соединение ({@link ScoreboardObjectiveUpdateS2CPacket} и {@link ScoreboardPlayerUpdateS2CPacket}).
 * Так его видят все клиенты, даже без мода, а содержимое успевает меняться у каждого своё.</p>
 */
public final class Sidebar {

	private static final String OBJECTIVE = "rb_sidebar";
	private static final int SIDEBAR_SLOT = 1;

	/** Что сейчас написано в каждой строке скорборда у игрока (чтобы не слать лишние пакеты). */
	private static final Map<UUID, String[]> LINES = new HashMap<>();
	/** Кому уже создавали объектив. */
	private static final Map<UUID, Boolean> CREATED = new HashMap<>();
	/** Невидимая запись игрока для строки ранга (у каждой записи своя команда с фото-бейджем). */
	private static final Map<UUID, String> ENTRIES = new HashMap<>();
	private static final Map<String, UUID> ENTRY_OWNERS = new HashMap<>();

	private static ScoreboardObjective objective;
	private static long lastTick;

	private Sidebar() {
	}

	public static boolean enabled() {
		ModConfig config = RandomBlocks.getConfig();
		return config != null && config.sidebarEnabled && config.ranksEnabled;
	}

	/** Раз в секунду обновить скорборд всем игрокам. */
	public static void tick(net.minecraft.server.MinecraftServer server) {
		if (!enabled() || server == null) {
			return;
		}
		long now = System.currentTimeMillis();
		if (now - lastTick < 1000L) {
			return;
		}
		lastTick = now;
		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			try {
				update(player);
			} catch (Throwable t) {
				RandomBlocks.LOGGER.warn("sidebar not updated for {}: {}", player.getEntityName(), t.toString());
			}
		}
	}

	/** Игрок зашёл — создать ему объектив заново (клиент мог забыть). */
	public static void onJoin(ServerPlayerEntity player) {
		CREATED.remove(player.getUuid());
		LINES.remove(player.getUuid());
		// строку ранга пересобираем заново — на случай, если привилегия сменилась в офлайне
		ENTRIES.remove(player.getUuid());
	}

	public static void onQuit(UUID uuid) {
		CREATED.remove(uuid);
		LINES.remove(uuid);
		String entry = ENTRIES.remove(uuid);
		if (entry != null) {
			ENTRY_OWNERS.remove(entry);
		}
	}

	private static ScoreboardObjective objective(ServerPlayerEntity player) {
		if (objective == null) {
			Scoreboard scoreboard = player.getServer().getScoreboard();
			ScoreboardObjective existing = scoreboard.getObjective(OBJECTIVE);
			objective = existing != null ? existing
					: scoreboard.addObjective(OBJECTIVE, ScoreboardCriterion.DUMMY,
							new LiteralText("§6§l" + RandomBlocks.getConfig().sidebarTitle),
							ScoreboardCriterion.RenderType.INTEGER);
		}
		return objective;
	}

	private static void update(ServerPlayerEntity player) {
		ScoreboardObjective obj = objective(player);
		UUID uuid = player.getUuid();
		if (!Boolean.TRUE.equals(CREATED.get(uuid))) {
			player.networkHandler.sendPacket(new ScoreboardObjectiveUpdateS2CPacket(obj, 0));   // 0 = создать
			player.networkHandler.sendPacket(new ScoreboardDisplayS2CPacket(SIDEBAR_SLOT, obj));
			CREATED.put(uuid, Boolean.TRUE);
		}
		// Строка ранга рисуется фото-бейджем. В скорборд картинку «в лоб» не положить: строки —
		// это обычный текст с §-кодами. Зато у каждой строки может быть своя команда (team), а её
		// префикс — полноценный Text, в том числе с нашим растровым шрифтом. Поэтому строка ранга —
		// это невидимая запись, у которой вся видимая часть лежит в префиксе команды привилегии.
		Rank rank = RankManager.rankOf(player);
		rankLine(player, obj, uuid, rank);
		String[] wanted = lines(player);
		String[] current = LINES.get(uuid);
		if (current == null) {
			current = new String[wanted.length];
		}
		for (int i = 0; i < wanted.length; i++) {
			String line = wanted[i];
			if (line.equals(current[i])) {
				continue;
			}
			if (current[i] != null) {
				player.networkHandler.sendPacket(new ScoreboardPlayerUpdateS2CPacket(
						ServerScoreboard.UpdateMode.REMOVE, obj.getName(), current[i], 0));
			}
			if (line.isEmpty()) {
				current[i] = null;
				continue;
			}
			player.networkHandler.sendPacket(new ScoreboardPlayerUpdateS2CPacket(
					ServerScoreboard.UpdateMode.CHANGE, obj.getName(), line, plainScore(i)));
			current[i] = line;
		}
		LINES.put(uuid, current);
	}

	/** Оценки строк без строки ранга (она вставлена между «Ник» и «У/С»). */
	private static int plainScore(int index) {
		if (index == 0) {
			return 7;                 // Ник
		}
		return 6 - index;             // У/С=5 … низ=1
	}

	/**
	 * Строка ранга: невидимая запись игрока + команда привилегии, в префиксе которой
	 * «▌ Ранг: » и фото-бейдж привилегии (или обычный текст, если фото у привилегии нет).
	 */
	private static void rankLine(ServerPlayerEntity player, ScoreboardObjective obj, UUID uuid, Rank rank) {
		String entry = entryFor(player);
		Scoreboard scoreboard = player.getServer().getScoreboard();
		Team team = rankTeam(scoreboard, rank);
		Team current = scoreboard.getPlayerTeam(entry);
		if (current != team) {
			if (current != null) {
				scoreboard.clearPlayerTeam(entry);
			}
			scoreboard.addPlayerToTeam(entry, team);
		}
		player.networkHandler.sendPacket(new ScoreboardPlayerUpdateS2CPacket(
				ServerScoreboard.UpdateMode.CHANGE, obj.getName(), entry, 6));
	}

	/** Команда для строки ранга: своя на каждую привилегию, префикс ставится один раз при создании. */
	private static Team rankTeam(Scoreboard scoreboard, Rank rank) {
		int index = RANK_TEAM_INDEX(rank);
		String name = "rb_sr" + index;
		Team team = scoreboard.getTeam(name);
		if (team == null) {
			team = scoreboard.addTeam(name);
			MutableText prefix = new LiteralText("§6▌ §fРанг: ");
			prefix.append(RankBadges.prefix(rank));
			team.setPrefix(prefix);
			team.setColor(Formatting.RESET);
		}
		return team;
	}

	private static int RANK_TEAM_INDEX(Rank rank) {
		switch (rank) {
			case PLAYER: return 0;
			case HERO: return 1;
			case TITAN: return 2;
			case AVENDER: return 3;
			case OVERLORD: return 4;
			case MAGISTER: return 5;
			case IMPERATOR: return 6;
			case DRAGON: return 7;
			default: return 8;         // OWNER
		}
	}

	/** Невидимая запись строки ранга: только §-коды (в игре не видно ни одного символа). */
	private static String entryFor(ServerPlayerEntity player) {
		UUID uuid = player.getUuid();
		String known = ENTRIES.get(uuid);
		if (known != null) {
			return known;
		}
		int hash = uuid.hashCode();
		for (int attempt = 0; attempt < 256; attempt++) {
			int value = (hash + attempt * 31) & 0xFF;
			String entry = "§" + Integer.toHexString(value & 0xF) + "§" + Integer.toHexString((value >> 4) & 0xF);
			UUID owner = ENTRY_OWNERS.get(entry);
			if (owner == null || owner.equals(uuid)) {
				ENTRY_OWNERS.put(entry, uuid);
				ENTRIES.put(uuid, entry);
				return entry;
			}
		}
		return "§f";
	}

	/** Строки скорборда для этого игрока (кроме ранга — он выше): сверху вниз. */
	private static String[] lines(ServerPlayerEntity player) {
		ModConfig config = RandomBlocks.getConfig();
		String[] strings = {
				"§6▌ §fНик: §e" + player.getEntityName(),                                        // оценка 7
				"§6▌ §fУ/С: §e" + Stats.text(player.getUuid()),                                  // 5
				"§6▌ §fБаланс: §a" + Economy.format(Economy.money(player.getUuid())),            // 4
				"§6▌ §fРилликов: §a" + Economy.format(Economy.rubles(player.getUuid())),         // 3
				"§6▌ §fПинг: §e" + player.pingMilliseconds + " §bмс",                            // 2
				"§6" + config.sidebarFooter,                                                     // 1
		};
		// Уникальность строк: невидимые §-коды в конце (в игре их не видно).
		for (int i = 0; i < strings.length; i++) {
			strings[i] = strings[i] + "§" + Integer.toHexString(i);
		}
		return strings;
	}

	/** Убрать скорборд (мод выключили). */
	public static void hideAll(net.minecraft.server.MinecraftServer server) {
		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			try {
				player.networkHandler.sendPacket(new ScoreboardObjectiveUpdateS2CPacket(objective(player), 1));
			} catch (Throwable ignored) {
				// клиент просто не получит удаление
			}
		}
		CREATED.clear();
		LINES.clear();
	}
}
