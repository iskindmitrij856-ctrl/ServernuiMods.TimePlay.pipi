package com.example.randomblocks.mixin;

import com.example.randomblocks.ChatRouter;
import com.example.randomblocks.CombatTag;
import com.example.randomblocks.DonateCase;
import com.example.randomblocks.DonateMenu;
import com.example.randomblocks.ModConfig;
import com.example.randomblocks.Permissions;
import com.example.randomblocks.RandomBlocks;
import com.example.randomblocks.ResourcePack;
import com.example.randomblocks.gui.DonateScreenHandler;
import com.mojang.authlib.GameProfile;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import com.example.randomblocks.EventManager;
import com.example.randomblocks.RandomBlocks;
import com.example.randomblocks.SpawnZone;
import com.example.randomblocks.gui.ViewInventoryScreenHandler;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ConfirmScreenActionS2CPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import java.util.List;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Перехват того, что приходит от игрока.
 *
 * <ul>
 *     <li><b>Чат:</b> голосование за события ловит «1»…«4», а обычные сообщения уходят
 *         в {@link ChatRouter} — он решает, кто их увидит (рядом или все) и как они выглядят.</li>
 *     <li><b>Зона спавна:</b> ломать и ставить блоки там нельзя даже в креативе —
 *         команды на ломание и на установку блока просто отменяются, а игроку возвращается
 *         настоящий блок, чтобы клиент не «дорисовывал» сломанный.</li>
 * </ul>
 */
@Mixin(ServerPlayNetworkHandler.class)
public class ServerPlayNetworkHandlerMixin {

	@Shadow
	public ServerPlayerEntity player;

	// ------------------------------------------------------------------
	//  Таб: без голов игроков
	// ------------------------------------------------------------------

	/**
	 * В табе не должно быть голов игроков (просьба владельца).
	 *
	 * <p>Голову клиент рисует по «скину» игрока, а скин приходит в списке игроков
	 * ({@code player_info}) отдельным свойством профиля. Убираем это свойство прямо в пакете,
	 * который уходит игроку: список остаётся (ники видны), а рисовать голову становится не из чего.
	 * Своих скинов в мире это не касается — там профиль игрока не меняется.</p>
	 */
	/** Сколько раз игрок отказался от ресурспака (первый раз предупреждаем, дальше — кик). */
	private static final java.util.Map<java.util.UUID, Integer> RBC_PACK_DECLINES = new java.util.concurrent.ConcurrentHashMap<>();

	/**
	 * Ответ клиента на ресурспак. Если игрок отказался, привилегии у него рисовались бы
	 * квадратиками — поэтому предупреждаем и отправляем пак заново, а если он отказывается
	 * ещё раз и в настройках пак обязательный ({@code resourcePackRequired}) — не пускаем в игру
	 * с понятным объяснением (как ванильный {@code require-resource-pack=true}).
	 */
	@Inject(method = "onResourcePackStatus(Lnet/minecraft/network/packet/c2s/play/ResourcePackStatusC2SPacket;)V",
			at = @At("HEAD"))
	private void randomblocks$onPackStatus(net.minecraft.network.packet.c2s.play.ResourcePackStatusC2SPacket packet,
			CallbackInfo ci) {
		try {
			ServerPlayerEntity player = ((ServerPlayNetworkHandler) (Object) this).player;
			ModConfig config = RandomBlocks.getConfig();
			if (player == null || config == null || !config.resourcePackEnabled) {
				return;
			}
			// У пакета нет публичного геттера — берём поле по типу (имя в рантайме обфусцировано).
			net.minecraft.network.packet.c2s.play.ResourcePackStatusC2SPacket.Status status = null;
			for (java.lang.reflect.Field field : net.minecraft.network.packet.c2s.play
					.ResourcePackStatusC2SPacket.class.getDeclaredFields()) {
				if (field.getType() == net.minecraft.network.packet.c2s.play
						.ResourcePackStatusC2SPacket.Status.class) {
					field.setAccessible(true);
					status = (net.minecraft.network.packet.c2s.play
							.ResourcePackStatusC2SPacket.Status) field.get(packet);
					break;
				}
			}
			if (status == null) {
				return;
			}
			if (status == net.minecraft.network.packet.c2s.play.ResourcePackStatusC2SPacket.Status.SUCCESSFULLY_LOADED) {
				RBC_PACK_DECLINES.remove(player.getUuid());
				player.sendMessage(new net.minecraft.text.LiteralText(
						"§a[Пак]§r ресурспак загружен — привилегии видно с фото."), false);
				return;
			}
			if (status != net.minecraft.network.packet.c2s.play.ResourcePackStatusC2SPacket.Status.DECLINED
					&& status != net.minecraft.network.packet.c2s.play.ResourcePackStatusC2SPacket.Status.FAILED_DOWNLOAD) {
				return;
			}
			int declines = RBC_PACK_DECLINES.merge(player.getUuid(), 1, Integer::sum);
			if (!config.resourcePackRequired) {
				player.sendMessage(new net.minecraft.text.LiteralText(
						"§6[Пак]§r без ресурспака привилегии будут квадратиками. Принять: настройки → ресурспаки."), false);
				return;
			}
			if (declines <= 1) {
				player.sendMessage(new net.minecraft.text.LiteralText(
						"§c[Пак]§r Примите ресурспак: он нужен, чтобы привилегии были картинками, а не квадратиками."), false);
				ResourcePack.send(player);                       // предлагаем ещё раз
			} else {
				player.networkHandler.disconnect(new net.minecraft.text.LiteralText(
						"§cЧтобы играть, примите ресурспак.\n§7Он нужен, чтобы вы видели фото-привилегии.\n"
								+ "§7Просто нажмите «Да» в окне «Принять ресурспак»."));
				RandomBlocks.LOGGER.info("{} kicked: resource pack declined twice", player.getEntityName());
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("pack status failed: {}", t.toString());
		}
	}

	/**
	 * Головы в табе: в ванильном клиенте 1.16.5 они рисуются только при зашифрованном соединении
	 * (PlayerListHud: {@code isInSingleplayer() || connection.isEncrypted()}), то есть на offline-серверах
	 * их нет вовсе. Принудительно убрать головы серверной стороной нельзя (поле пакета getEntries()
	 * в рантайме отсутствует), поэтому фильтр удалён.
	 */

	@Inject(method = "onGameMessage(Lnet/minecraft/network/packet/c2s/play/ChatMessageC2SPacket;)V",
			at = @At("HEAD"), cancellable = true)
	private void randomblocks$onChat(ChatMessageC2SPacket packet, CallbackInfo ci) {
		String message = packet.getChatMessage();

		// 0. ПВП-бой: пока идёт бой (ударил игрока / ударили тебя), команды писать нельзя.
		//    Владельцу (OWNER) бой команды не запрещает — иначе в бою не получилось бы
		//    ни забанить, ни телепортироваться к игроку.
		if (message.startsWith("/") && CombatTag.tagged(player) && !Permissions.isOwner(player)) {
			player.sendMessage(new LiteralText(CombatTag.message(player)), false);
			ci.cancel();
			return;
		}

		// 0.1. Команды (например «/rank user Nick parent set HERO») приходят тем же пакетом чата,
		//    поэтому их трогать нельзя — пусть игра выполняет их как обычно.
		if (message.startsWith("/")) {
			return;
		}

		// 1. Голосование: «1»…«4» — это голос, в чат не уходит.
		int number = EventManager.parseVote(message);
		if (number >= 0 && EventManager.vote(player, number)) {
			RandomBlocks.LOGGER.info("Vote from {}: {}", player.getEntityName(), number);
			ci.cancel();
			return;
		}

		// 2. Обычное сообщение: без «!» — только тем, кто рядом (Ⓛ), с «!» — всем (Ⓖ).
		if (ChatRouter.handle(player, message)) {
			ci.cancel();
		}
	}

	// ------------------------------------------------------------------
	//  Зона спавна: блоки
	// ------------------------------------------------------------------

	@Inject(method = "onPlayerAction(Lnet/minecraft/network/packet/c2s/play/PlayerActionC2SPacket;)V",
			at = @At("HEAD"), cancellable = true)
	private void randomblocks$onPlayerAction(PlayerActionC2SPacket packet, CallbackInfo ci) {
		PlayerActionC2SPacket.Action action = packet.getAction();
		if (action != PlayerActionC2SPacket.Action.START_DESTROY_BLOCK
				&& action != PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK) {
			return;
		}
		BlockPos pos = packet.getPos();
		if (!SpawnZone.protect(player, pos)) {
			return;
		}
		resendBlock(pos);
		player.sendMessage(new LiteralText("§cЗона спавна: тут ломать нельзя."), true);
		ci.cancel();
	}

	/** Вернуть клиенту настоящее состояние блока — вместо того, что он нарисовал у себя. */
	private void resendBlock(BlockPos pos) {
		player.networkHandler.sendPacket(new BlockUpdateS2CPacket(pos, player.world.getBlockState(pos)));
	}

	// ------------------------------------------------------------------
	//  /invsee: «только смотреть» — ни взять, ни перетащить
	// ------------------------------------------------------------------

	/**
	 * Любой клик по чужому инвентарю (кроме OWNER) отклоняется — и не «тихо», а так, как ваниль
	 * делает при рассинхроне: подтверждение с ошибкой + полная пересылка содержимого окна и
	 * курсора. Без этой пересылки клиент оставляет у себя предмет, который он нарисовал своей
	 * предсказанной анимацией (shift-клик, перетаскивание, клонирование в креативе) — то самое
	 * «фантомное» взятие. Здесь его состояние принудительно совпадает с сервером.
	 */
	@Inject(method = "onClickSlot(Lnet/minecraft/network/packet/c2s/play/ClickSlotC2SPacket;)V",
			at = @At("HEAD"), cancellable = true)
	private void randomblocks$onClickSlot(ClickSlotC2SPacket packet, CallbackInfo ci) {
		ScreenHandler handler = player.currentScreenHandler;
		if (!(handler instanceof ViewInventoryScreenHandler)
				|| ((ViewInventoryScreenHandler) handler).isEditable()
				|| handler.syncId != packet.getSyncId()) {
			return;
		}
		player.networkHandler.sendPacket(
				new ConfirmScreenActionS2CPacket(packet.getSyncId(), packet.getActionId(), false));
		DefaultedList<ItemStack> stacks = DefaultedList.of();
		for (Slot slot : handler.slots) {
			stacks.add(slot.getStack());
		}
		player.onHandlerRegistered(handler, stacks);        // содержимое окна + курсор
		if (handler instanceof DonateScreenHandler) {
			// В меню /donate по клику показываем, что это за привилегия и сколько стоит.
			DonateMenu.handleClick(player, packet.getSlot());
		}
		ci.cancel();
	}

	@Inject(method = "onPlayerInteractBlock(Lnet/minecraft/network/packet/c2s/play/PlayerInteractBlockC2SPacket;)V",
			at = @At("HEAD"), cancellable = true)
	private void randomblocks$onInteractBlock(PlayerInteractBlockC2SPacket packet, CallbackInfo ci) {
		// Донат-кейс: любой блок, отмеченный /dk create, открывается только ключом —
		// обычное открытие сундука/шалера/эндер-сундука мы перехватываем.
		try {
			BlockPos casePos = packet.getBlockHitResult().getBlockPos();
			if (DonateCase.isCase(player.world, casePos)) {
				ci.cancel();
				DonateCase.open(player, casePos);
				return;
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("donate case interaction failed: {}", t.toString());
		}

		// Трогаем только установку блока (когда в руке блок) — сундуки, кнопки и прочее
		// в зоне спавна работают как обычно.
		if (!(player.getStackInHand(packet.getHand()).getItem() instanceof BlockItem)) {
			return;
		}
		BlockPos pos = packet.getBlockHitResult().getBlockPos();
		// Блок встаёт не в тот блок, по которому щёлкнули, а в соседний с ним — по стороне клика.
		// Поэтому проверяем оба места: иначе можно было бы «доставить» блок в зону снаружи.
		BlockPos placed = pos.offset(packet.getBlockHitResult().getSide());
		boolean blockedHere = SpawnZone.protect(player, pos);
		boolean blockedThere = SpawnZone.protect(player, placed);
		if (!blockedHere && !blockedThere) {
			return;
		}
		// Гасим фантомный блок: клиент уже нарисовал у себя установку, поэтому возвращаем ему
		// настоящее состояние И у нажатого блока, И у того места, куда блок должен был встать.
		resendBlock(pos);
		if (!placed.equals(pos)) {
			resendBlock(placed);
		}
		player.sendMessage(new LiteralText("§cЗона спавна: тут ставить блоки нельзя."), true);
		ci.cancel();
	}
}
