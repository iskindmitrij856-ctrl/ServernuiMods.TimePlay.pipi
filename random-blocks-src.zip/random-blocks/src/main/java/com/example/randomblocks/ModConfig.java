package com.example.randomblocks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Настройки мода. Файл: config/randomblocks.json (создаётся автоматически).
 */
public class ModConfig {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
	private static final String FILE_NAME = "randomblocks.json";

	// ------------------------------------------------------------------
	//  Часть 1. Случайные блоки под ногами
	// ------------------------------------------------------------------

	/** Запущен ли режим случайных блоков (/randomblock start / stop). По умолчанию — выключено. */
	public boolean enabled = false;

	/** Шанс (0.0 … 1.0), что блок под ногами превратится. 1.0 = всегда. */
	public double transformChance = 1.0D;

	/** true — трогаем только полноразмерные блоки (тогда никаких провалов и застреваний). */
	public boolean onlyFullBlocks = true;

	/** true — блок превращается ещё и при прыжке на месте (в тот же блок, на который уже вставали). */
	public boolean transformOnLandingSameBlock = false;

	/** Не трогать блоки игроков в креативе. */
	public boolean skipCreative = false;

	/** Не трогать блоки под наблюдателями (spectator). */
	public boolean skipSpectator = true;

	/** Не превращать блоки с содержимым (сундуки, печи, бочки, шалкеры и т.д.). */
	public boolean protectBlockEntities = true;

	/** Блоки, которые никогда не превращаются. */
	public List<String> protectBlocks = new ArrayList<>(Arrays.asList(
			"minecraft:bedrock",
			"minecraft:barrier",
			"minecraft:command_block",
			"minecraft:chain_command_block",
			"minecraft:repeating_command_block",
			"minecraft:structure_block",
			"minecraft:structure_void",
			"minecraft:jigsaw",
			"minecraft:end_portal",
			"minecraft:end_portal_frame",
			"minecraft:end_gateway",
			"minecraft:nether_portal",
			"minecraft:dragon_egg",
			"minecraft:spawner"));

	/** Блоки, которые не могут выпасть как «случайный другой блок». */
	public List<String> produceBlacklist = new ArrayList<>(Arrays.asList(
			"minecraft:bedrock",
			"minecraft:barrier",
			"minecraft:command_block",
			"minecraft:chain_command_block",
			"minecraft:repeating_command_block",
			"minecraft:structure_block",
			"minecraft:structure_void",
			"minecraft:jigsaw",
			"minecraft:end_portal",
			"minecraft:end_portal_frame",
			"minecraft:end_gateway",
			"minecraft:nether_portal",
			"minecraft:dragon_egg",
			"minecraft:spawner"));

	/** Опасные для стояния блоки (магма, кактус, костёр, сладкие ягоды и т.д.). */
	public List<String> hazardousBlocks = new ArrayList<>(Arrays.asList(
			"minecraft:magma_block",
			"minecraft:cactus",
			"minecraft:sweet_berry_bush",
			"minecraft:campfire",
			"minecraft:soul_campfire",
			"minecraft:fire",
			"minecraft:soul_fire",
			"minecraft:lava"));

	/** Разрешить превращать блоки в опасные (магма/кактус/огонь). По умолчанию выключено. */
	public boolean allowHazardous = false;

	/** true — в случайные блоки попадут только природные материалы (камень, земля, дерево, листва, песок…). */
	public boolean naturalOnly = false;

	/** Дополнительные блоки, которые тоже могут выпадать (даже если они не полноразмерные). */
	public List<String> extraBlocks = new ArrayList<>(Arrays.asList(
			"minecraft:glass",
			"minecraft:glowstone",
			"minecraft:ice",
			"minecraft:packed_ice",
			"minecraft:blue_ice",
			"minecraft:sea_lantern",
			"minecraft:redstone_lamp"));

	/** Выпадать ли предмету из превращённого блока (по умолчанию — нет, чтобы не засорять мир). */
	public boolean dropItems = false;

	// ------------------------------------------------------------------
	//  Часть 2. Случайные предметы по таймеру
	// ------------------------------------------------------------------

	/** Запущен ли таймер выдачи предметов (/randomblock item start / stop). */
	public boolean itemTimerEnabled = false;

	/** Интервал выдачи предметов в секундах (300 = 5 минут). */
	public int itemIntervalSeconds = 300;

	/** Шанс (0.0 … 1.0), что выданный предмет будет зачарован. */
	public double itemEnchantChance = 0.5D;

	/** Минимальный «уровень» зачарования (как уровень стола чар: 1 = почти ничего, 30 = максимум). */
	public int itemEnchantMinLevel = 1;

	/** Максимальный «уровень» зачарования. */
	public int itemEnchantMaxLevel = 30;

	/** Сколько предметов максимум выпадает за раз (1 = всегда один). */
	public int itemAmountMax = 1;

	/** Шанс, что выданный предмет придёт ПАЧКОЙ (не 1 штука). 0.15 = 15%. */
	public double itemMultiDropChance = 0.15D;

	/** Сколько штук минимум в такой пачке. */
	public int itemMultiDropMin = 2;

	/** Сколько штук максимум в такой пачке. */
	public int itemMultiDropMax = 16;

	/** Показывать ли кастомную плашку таймера предметов внизу экрана (над хотбаром). */
	public boolean itemOverlayEnabled = true;

	/** Предметы, которые никогда не выпадают (творческие/отладочные). */
	public List<String> itemBlacklist = new ArrayList<>(Arrays.asList(
			"minecraft:air",
			"minecraft:debug_stick",
			"minecraft:command_block",
			"minecraft:chain_command_block",
			"minecraft:repeating_command_block",
			"minecraft:structure_block",
			"minecraft:structure_void",
			"minecraft:jigsaw",
			"minecraft:barrier"));

	// ------------------------------------------------------------------
	//  Часть 3. Случайные события (по умолчанию — сами, без голосования)
	// ------------------------------------------------------------------

	/** Запущен ли таймер событий (/randomevent start / stop). По умолчанию — выключено. */
	public boolean eventTimerEnabled = false;

	/**
	 * false (по умолчанию) — события случаются САМИ, без голосования: раз в eventIntervalSeconds
	 * одно случайное событие ровно в момент, когда таймер дошёл до нуля.
	 * true — старое поведение: в чат приходит голосование на 4 варианта.
	 */
	public boolean eventVotingEnabled = false;

	/** Интервал между голосованиями в секундах (300 = 5 минут). */
	public int eventIntervalSeconds = 300;

	/** Сколько секунд даётся игрокам на голосование. */
	public int eventVoteDurationSeconds = 10;

	/** Сколько вариантов показывать в голосовании (2–4). */
	public int eventOptionsCount = 4;

	/** Разрешать ли отрицательные события (голод, молнии, нашествие и т.п.). */
	public boolean eventAllowNegative = true;

	/** Показывать ли кастомный таймер (плашка сверху по центру) — рисует клиентская часть мода. */
	public boolean eventOverlayEnabled = true;

	/**
	 * Шанс, что случайное событие окажется ПЛОХИМ.
	 * 0.6 = 60% плохих / 40% хороших (смешанные события считаются по своему характеру).
	 */
	public double eventNegativeChance = 0.60D;

	// ------------------------------------------------------------------

	// ------------------------------------------------------------------
	//  Часть 5. Телепорт-команды (/spawn, /sethome, /home)
	// ------------------------------------------------------------------

	/** Сколько точек дома разрешено одному игроку (1…100). По умолчанию 10. */
	public int maxHomes = 10;

	// ------------------------------------------------------------------
	//  Часть 6. Привилегии (префиксы в чате, табе и над головой)
	// ------------------------------------------------------------------

	/** Показывать префиксы привилегий (PLAYER, HERO, … OWNER) в чате, табе и над головой. */
	public boolean ranksEnabled = true;

	/** Разрешать команды привилегий (/rtp, /craft, /fly и прочие). */
	public boolean rankCommandsEnabled = true;

	/**
	 * Показывать у привилегий, для которых есть картинка (сейчас — OWNER), фото-бейдж вместо
	 * слова в чате, табе и над головой. Если выключить — везде будет обычный текстовый префикс.
	 */
	public boolean rankBadges = true;

	// ------------------------------------------------------------------
	//  Часть 7. Чат и зона спавна
	// ------------------------------------------------------------------

	/** Локальный чат: обычное сообщение видят только те, кто рядом; с «!» — все. */
	public boolean localChatEnabled = true;

	/** Насколько «рядом» для локального чата (в блоках). */
	public double localChatRadius = 100.0D;

	/** Значок локального сообщения (по умолчанию «Ⓛ» — L в кружочке). */
	public String localChatIcon = "Ⓛ";

	/** Значок сообщения для всех (по умолчанию «Ⓖ» — G в кружочке). */
	public String globalChatIcon = "Ⓖ";

	/** Защита зоны вокруг /setspawn: там нельзя ломать блоки и драться. */
	public boolean spawnZoneEnabled = true;

	/** Размер зоны вокруг спавна (сторона квадрата в блоках): 1000×1000. */
	public int spawnZoneSize = 1000;

	/** Показывать собственный скорборд (ГРИФ #1, ник, ранг, У/С, деньги, риллики, пинг). */
	public boolean sidebarEnabled = true;

	/** Заголовок скорборда (на фото владельца — «ГРИФ #1»). */
	public String sidebarTitle = "ГРИФ #1";

	/** Нижняя строка скорборда — адрес для красоты (на фото было nc.ReallyWorld.ne). */
	public String sidebarFooter = "TimePlay.pipi";

	/** ПВП-бой: удар по игроку включает бой на combatTagSeconds секунд (каждый удар продлевает). */
	public boolean combatTagEnabled = true;

	/** Сколько секунд длится бой после удара по игроку. */
	public int combatTagSeconds = 20;

	/** Писать ли в чат сообщения о смертях (владелец просил выключить). */
	public boolean announceDeaths = false;

	/** Писать ли в чат достижения (владелец просил выключить). */
	public boolean announceAdvancements = false;

	/** Убирать ли игровые «головы» (скины) из таба — список игроков оставляем, скин в нём чистим. */
	public boolean hideTabHeads = true;

	/** Объявлять ли в чат всем, что кто-то выкрутил привилегию в донат-кейсе (по умолчанию — тихо). */
	public boolean donateCaseAnnounce = false;

	/** Отдавать ли друзьям ресурспак с фото-бейджами (игра сама предложит его скачать). */
	public boolean resourcePackEnabled = true;

	/** Адрес, по которому друзья видят сервер (пусто — 127.0.0.1: для игры с того же компьютера). */
	public String resourcePackHost = "";

	/** Готовая ссылка на пак (если задана — используется вместо host/порта). */
	public String resourcePackUrl = "";
	/**
	 * Обязательный ресурспак: клиент обязан принять его, иначе выйдет с сервера.
	 * Так друзья точно увидят фото-привилегии (без пака вместо картинок — квадратики).
	 * Если пак не нужен как обязательный — поставьте false.
	 */
	public boolean resourcePackRequired = true;

	/** Порт для раздачи пака (0 — занять порт сервера или следующий свободный). */
	public int resourcePackServePort = 0;

	/** Подробный лог превращений и выдач в logs/latest.log (удобно для проверки). */
	public boolean debugLog = false;

	/** Разрешить команду /randomblock. */
	public boolean commandEnabled = true;

	// ------------------------------------------------------------------

	public static Path configPath() {
		return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
	}

	public static ModConfig load() {
		Path path = configPath();
		ModConfig cfg = new ModConfig();
		if (Files.exists(path)) {
			try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
				ModConfig loaded = GSON.fromJson(reader, ModConfig.class);
				if (loaded != null) {
					cfg = loaded;
				}
			} catch (Exception e) {
				RandomBlocks.LOGGER.error("Could not read {}, using defaults", path, e);
				cfg = new ModConfig();
			}
		}
		cfg.validate();
		cfg.save();
		return cfg;
	}

	public void save() {
		try {
			Path path = configPath();
			Files.createDirectories(path.getParent());
			try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
				GSON.toJson(this, writer);
			}
		} catch (IOException e) {
			RandomBlocks.LOGGER.error("Could not save config", e);
		}
	}

	/** Чинит «кривые» значения, чтобы мод не падал из-за опечаток в конфиге. */
	public void validate() {
		if (transformChance < 0.0D) transformChance = 0.0D;
		if (transformChance > 1.0D) transformChance = 1.0D;

		if (protectBlocks == null) protectBlocks = new ArrayList<>();
		if (produceBlacklist == null) produceBlacklist = new ArrayList<>();
		if (hazardousBlocks == null) hazardousBlocks = new ArrayList<>();
		if (extraBlocks == null) extraBlocks = new ArrayList<>();
		if (itemBlacklist == null) itemBlacklist = new ArrayList<>();

		if (itemIntervalSeconds < 1) itemIntervalSeconds = 1;
		if (itemIntervalSeconds > 604800) itemIntervalSeconds = 604800;   // максимум — 7 суток
		if (itemEnchantChance < 0.0D) itemEnchantChance = 0.0D;
		if (itemEnchantChance > 1.0D) itemEnchantChance = 1.0D;
		if (itemEnchantMinLevel < 1) itemEnchantMinLevel = 1;
		if (itemEnchantMaxLevel < itemEnchantMinLevel) itemEnchantMaxLevel = itemEnchantMinLevel;
		if (itemEnchantMaxLevel > 100) itemEnchantMaxLevel = 100;
		if (itemAmountMax < 1) itemAmountMax = 1;
		if (itemAmountMax > 64) itemAmountMax = 64;
		if (itemMultiDropChance < 0.0D) itemMultiDropChance = 0.0D;
		if (itemMultiDropChance > 1.0D) itemMultiDropChance = 1.0D;
		if (itemMultiDropMin < 2) itemMultiDropMin = 2;
		if (itemMultiDropMax < itemMultiDropMin) itemMultiDropMax = itemMultiDropMin;
		if (itemMultiDropMax > 64) itemMultiDropMax = 64;

		if (eventIntervalSeconds < 5) eventIntervalSeconds = 5;
		if (eventIntervalSeconds > 604800) eventIntervalSeconds = 604800;
		if (eventVoteDurationSeconds < 3) eventVoteDurationSeconds = 3;
		if (eventVoteDurationSeconds > 600) eventVoteDurationSeconds = 600;
		if (eventOptionsCount < 2) eventOptionsCount = 2;
		if (eventOptionsCount > 4) eventOptionsCount = 4;
		if (maxHomes < 1) maxHomes = 1;
		if (maxHomes > 100) maxHomes = 100;

		if (eventNegativeChance < 0.0D) eventNegativeChance = 0.0D;
		if (eventNegativeChance > 1.0D) eventNegativeChance = 1.0D;

		if (spawnZoneSize < 2) spawnZoneSize = 2;
		if (spawnZoneSize > 100000) spawnZoneSize = 100000;
		if (sidebarTitle == null || sidebarTitle.trim().isEmpty()) sidebarTitle = "ГРИФ #1";
		if (sidebarFooter == null || sidebarFooter.trim().isEmpty()) sidebarFooter = "TimePlay.pipi";
		if (combatTagSeconds < 1) combatTagSeconds = 1;
		if (combatTagSeconds > 600) combatTagSeconds = 600;
	}

	// ------------------------------------------------------------------

	public boolean isProtected(Block block) {
		return matchesBlock(protectBlocks, block);
	}

	public boolean isProduceBlocked(Block block) {
		return matchesBlock(produceBlacklist, block);
	}

	public boolean isHazardous(Block block) {
		return matchesBlock(hazardousBlocks, block);
	}

	public boolean isItemBlacklisted(Item item) {
		if (itemBlacklist == null || itemBlacklist.isEmpty()) {
			return false;
		}
		Identifier id = Registry.ITEM.getId(item);
		if (id == null) {
			return false;
		}
		return matches( itemBlacklist, id.toString());
	}

	private static boolean matchesBlock(List<String> ids, Block block) {
		if (ids == null || ids.isEmpty()) {
			return false;
		}
		Identifier id = Registry.BLOCK.getId(block);
		if (id == null) {
			return false;
		}
		return matches(ids, id.toString());
	}

	private static boolean matches(List<String> ids, String value) {
		for (String entry : ids) {
			if (entry != null && entry.trim().equalsIgnoreCase(value)) {
				return true;
			}
		}
		return false;
	}
}
