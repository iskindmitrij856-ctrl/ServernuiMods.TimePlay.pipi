package com.example.randomblocks.command;

import com.example.randomblocks.Cooldowns;
import com.example.randomblocks.Permissions;
import com.example.randomblocks.RandomBlocks;
import com.example.randomblocks.RandomTeleport;
import com.example.randomblocks.Rank;
import com.example.randomblocks.RankManager;
import com.example.randomblocks.gui.ViewInventoryScreenHandler;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.item.ItemStack;
import net.minecraft.network.MessageType;
import net.minecraft.screen.ScreenHandlerContext;
import com.example.randomblocks.gui.VirtualCraftingScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Hand;
import net.minecraft.util.Util;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.lang.reflect.Field;
import java.util.Map;

/**
 * Команды привилегий (то, что даёт каждая ступень).
 *
 * <p>Правило простое: <b>чем выше привилегия, тем больше команд</b>, и все команды нижних
 * привилегий у верхних тоже есть (проверка — «моя привилегия не ниже нужной»).</p>
 *
 * <ul>
 *     <li>PLAYER — {@code /rtp}, {@code /sethome …}; 1 точка дома;</li>
 *     <li>HERO — {@code /craft}; 2 точки;</li>
 *     <li>TITAN — {@code /hat}, {@code /feed} (раз в 2 мин), {@code /rtpfar} (раз в мин); 4 точки;</li>
 *     <li>AVENDER — {@code /enderchest} ({@code /ec}), {@code /ext}, {@code /clear}; 6 точек;</li>
 *     <li>OVERLORD — {@code /repair}, {@code /near}; 12 точек;</li>
 *     <li>MAGISTER — {@code /invsee}, {@code /repair all}, {@code /heal}; 32 точки;</li>
 *     <li>IMPERATOR — {@code /broadcast}, {@code /lightning}, {@code /rtpnear}; 48 точек;</li>
 *     <li>DRAGON — {@code /fly}, {@code /grant}, {@code /sun}, {@code /rain}, {@code /day}, {@code /night}; 100 точек;</li>
 *     <li>OWNER — всё то же без перезарядок и без ограничений, {@code /invsee} с возможностью взять предмет; точек дома ∞.</li>
 * </ul>
 */
public final class VipCommand {

	private static final int RTP_RADIUS = 2000;
	private static final int RTP_FAR_RADIUS = 10000;
	private static final double NEAR_RADIUS = 100.0D;

	private VipCommand() {
	}

	public static void register() {
		tryRegister(dispatcher -> {
			player(dispatcher, "rtp", Permissions.RTP, VipCommand::rtp);
			player(dispatcher, "craft", Permissions.CRAFT, VipCommand::craft);
			player(dispatcher, "hat", Permissions.HAT, VipCommand::hat);
			player(dispatcher, "feed", Permissions.FEED, VipCommand::feed);
			player(dispatcher, "rtpfar", Permissions.RTP_FAR, VipCommand::rtpFar);
			player(dispatcher, "enderchest", Permissions.ENDERCHEST, VipCommand::enderChest);
			player(dispatcher, "ec", Permissions.ENDERCHEST, VipCommand::enderChest);
			player(dispatcher, "ext", Permissions.EXTINGUISH, VipCommand::extinguish);
			player(dispatcher, "repair", Permissions.REPAIR, context -> repair(context, false),
					CommandManager.literal("all").executes(context -> repair(context, true)));
			player(dispatcher, "near", Permissions.NEAR, VipCommand::near);
			player(dispatcher, "heal", Permissions.HEAL, VipCommand::heal);
			player(dispatcher, "invsee", Permissions.INVSEE, VipCommand::invseeNoArgs,
					CommandManager.argument("ник", StringArgumentType.word()).suggests(NICKS)
							.executes(VipCommand::invsee));
			player(dispatcher, "broadcast", Permissions.BROADCAST, VipCommand::broadcastNoArgs,
					CommandManager.argument("текст", StringArgumentType.greedyString()).executes(VipCommand::broadcast));
			player(dispatcher, "lightning", Permissions.LIGHTNING, VipCommand::lightning);
			player(dispatcher, "rtpnear", Permissions.RTP_NEAR, VipCommand::rtpNear);
			player(dispatcher, "fly", Permissions.FLY, VipCommand::fly);
			player(dispatcher, "sun", Permissions.WEATHER, context -> weather(context, false));
			player(dispatcher, "rain", Permissions.WEATHER, context -> weather(context, true));
			player(dispatcher, "day", Permissions.TIME, context -> time(context, true));
			player(dispatcher, "night", Permissions.TIME, context -> time(context, false));

			// /clear — свой инвентарь (с AVENDER), с ником — чужой (OP или OWNER).
			// Ванильный /clear требует OP и обязательный аргумент, поэтому его узел убираем:
			// иначе наш вариант был бы не виден обычным игрокам (Brigadier оставляет чужое требование).
			dropVanillaClear(dispatcher);
			dispatcher.register(CommandManager.literal("clear")
					.requires(source -> source.getEntity() instanceof ServerPlayerEntity || source.hasPermissionLevel(2))
					.executes(VipCommand::clearSelf)
					.then(CommandManager.argument("ник", StringArgumentType.word()).suggests(NICKS)
							.executes(VipCommand::clearOther)));

			// /grant — «донат» от DRAGON: выдать HERO…TITAN, раз в 5 дней.
			dispatcher.register(CommandManager.literal("grant")
					.requires(source -> source.getEntity() instanceof ServerPlayerEntity)
					.then(CommandManager.argument("ник", StringArgumentType.word()).suggests(NICKS)
							.then(CommandManager.argument("привилегия", StringArgumentType.word())
									.suggests((context, builder) -> {
										builder.suggest("hero");
										builder.suggest("titan");
										return builder.buildFuture();
									})
									.executes(VipCommand::grant))));
		});
	}

	// ------------------------------------------------------------------
	//  Регистрация
	// ------------------------------------------------------------------

	private interface Registrar {
		void register(CommandDispatcher<ServerCommandSource> dispatcher);
	}

	private static void tryRegister(Registrar registrar) {
		try {
			CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
				try {
					registrar.register(dispatcher);
				} catch (Throwable t) {
					RandomBlocks.LOGGER.warn("VIP commands not registered: {}", t.toString());
				}
			});
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("VIP commands not registered: {}", t.toString());
		}
	}

	/** Игроку: отсекаем консоль и командные блоки, дальше проверяется привилегия. */
	private static void player(CommandDispatcher<ServerCommandSource> dispatcher, String name, String node,
			VipCommand.Executor executor, com.mojang.brigadier.builder.ArgumentBuilder<ServerCommandSource, ?>... extra) {
		com.mojang.brigadier.builder.LiteralArgumentBuilder<ServerCommandSource> builder = CommandManager.literal(name)
				.requires(source -> source.getEntity() instanceof ServerPlayerEntity)
				.executes(context -> run(context, node, name, executor));
		for (com.mojang.brigadier.builder.ArgumentBuilder<ServerCommandSource, ?> child : extra) {
			// дети («/repair all», «/invsee <ник>») получают проверки внутри своих исполнителей
			builder = builder.then(child);
		}
		dispatcher.register(builder);
	}

	private interface Executor {
		int run(CommandContext<ServerCommandSource> context) throws CommandSyntaxException;
	}

	private static int run(CommandContext<ServerCommandSource> context, String node, String label, Executor executor)
			throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		if (!Permissions.has(player, node)) {
			noPermission(player, node, label);
			return 0;
		}
		if (!Cooldowns.ready(player, node)) {
			cooldown(player, node, label);
			return 0;
		}
		return executor.run(context);
	}

	// ------------------------------------------------------------------
	//  Сообщения-подсказки
	// ------------------------------------------------------------------

	private static void noPermission(ServerPlayerEntity player, String node, String label) {
		player.sendMessage(new LiteralText("§cКоманда §e/" + label + "§c доступна с привилегии §e"
				+ Permissions.required(node).name + "§c. У тебя §e" + RankManager.rankOf(player).name + "§c."), false);
	}

	private static void cooldown(ServerPlayerEntity player, String node, String label) {
		player.sendMessage(new LiteralText("§cРано! §e/" + label + "§c можно снова через §e"
				+ Cooldowns.format(Cooldowns.remaining(player, node)) + "§c."), false);
	}

	private static void ok(ServerPlayerEntity player, String message) {
		player.sendMessage(new LiteralText("§6[Привилегии]§r " + message), false);
	}

	// ------------------------------------------------------------------
	//  PLAYER: /rtp
	// ------------------------------------------------------------------

	private static int rtp(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		return RandomTeleport.around(context.getSource().getPlayer(), RTP_RADIUS) ? 1 : 0;
	}

	// ------------------------------------------------------------------
	//  HERO: /craft
	// ------------------------------------------------------------------

	private static int craft(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		// Виртуальный верстак: обычная серверная сетка 3×3 (CraftingScreenHandler).
		//
		// ВАЖНО: контекст должен быть «настоящим» (мир + точка), а не ScreenHandlerContext.EMPTY.
		// В 1.16.5 CraftingScreenHandler считает результат крафта внутри context.run(...), а у EMPTY
		// этот вызов — пустышка: сетка заполнялась, но слот результата оставался пустым, из-за чего
		// «нельзя крафтить». С настоящим контекстом результат считается, а ингредиенты списываются.
		player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
				(syncId, inventory, viewer) -> new VirtualCraftingScreenHandler(syncId, inventory,
						ScreenHandlerContext.create(player.world, player.getBlockPos())),
				new LiteralText("§6§lВерстак")));
		player.sendMessage(new LiteralText("§6[Привилегии]§r верстак открыт (сетка 3×3)."), true);
		return 1;
	}

	// ------------------------------------------------------------------
	//  TITAN: /hat, /feed, /rtpfar
	// ------------------------------------------------------------------

	private static int hat(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		ItemStack hand = player.getMainHandStack().copy();
		if (hand.isEmpty()) {
			ok(player, "§cвозьми предмет в руку — надену его на голову.");
			return 0;
		}
		ItemStack old = player.inventory.getStack(39).copy();     // 39 — слот шлема
		player.inventory.setStack(39, hand);
		player.setStackInHand(Hand.MAIN_HAND, old);
		player.inventory.markDirty();
		ok(player, "на голову надето: §e" + hand.getName().getString() + "§r.");
		return 1;
	}

	private static int feed(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		HungerManager hunger = player.getHungerManager();
		// Важно: setSaturationLevel есть только в клиентском jar, в серверном его нет —
		// на нём сервер падал с NoSuchMethodError. Поэтому используем add(food, saturation):
		// он есть и на сервере, и на клиенте.
		hunger.setFoodLevel(20);
		hunger.add(0, 5.0F);
		Cooldowns.mark(player, Permissions.FEED);
		ok(player, "голод восполнен" + Cooldowns.note(player, Permissions.FEED));
		return 1;
	}

	private static int rtpFar(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		if (!RandomTeleport.around(player, RTP_FAR_RADIUS)) {
			return 0;
		}
		Cooldowns.mark(player, Permissions.RTP_FAR);
		return 1;
	}

	// ------------------------------------------------------------------
	//  AVENDER: /enderchest, /ext, /clear
	// ------------------------------------------------------------------

	private static int enderChest(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
				(syncId, inventory, viewer) -> GenericContainerScreenHandler.createGeneric9x3(
						syncId, inventory, player.getEnderChestInventory()),
				new LiteralText("Эндер-сундук")));
		return 1;
	}

	private static int extinguish(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		player.extinguish();
		Cooldowns.mark(player, Permissions.EXTINGUISH);
		ok(player, "огонь потушен" + Cooldowns.note(player, Permissions.EXTINGUISH));
		return 1;
	}

	private static int clearSelf(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		if (!Permissions.has(player, Permissions.CLEAR)) {
			noPermission(player, Permissions.CLEAR, "clear");
			return 0;
		}
		player.inventory.clear();
		player.currentScreenHandler.sendContentUpdates();
		player.inventory.markDirty();
		ok(player, "инвентарь очищен.");
		return 1;
	}

	private static int clearOther(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		ServerCommandSource source = context.getSource();
		if (!source.hasPermissionLevel(2) && !Permissions.isOwner(player)) {
			ok(player, "§cчистить чужой инвентарь может только оператор (или OWNER).");
			return 0;
		}
		String name = StringArgumentType.getString(context, "ник");
		ServerPlayerEntity target = source.getMinecraftServer().getPlayerManager().getPlayer(name);
		if (target == null) {
			ok(player, "§cигрок §e" + name + "§c не в сети.");
			return 0;
		}
		target.inventory.clear();
		target.currentScreenHandler.sendContentUpdates();
		target.inventory.markDirty();
		ok(player, "инвентарь игрока §e" + target.getEntityName() + "§r очищен.");
		ok(target, "твой инвентарь очистил §e" + player.getEntityName() + "§r.");
		return 1;
	}

	// ------------------------------------------------------------------
	//  OVERLORD: /repair, /near
	// ------------------------------------------------------------------

	private static int repair(CommandContext<ServerCommandSource> context, boolean all) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		String node = all ? Permissions.REPAIR_ALL : Permissions.REPAIR;
		if (!Permissions.has(player, node)) {
			noPermission(player, node, all ? "repair all" : "repair");
			return 0;
		}
		if (all) {
			int fixed = 0;
			for (int slot = 0; slot < player.inventory.size(); slot++) {
				ItemStack stack = player.inventory.getStack(slot);
				if (fix(stack)) {
					player.inventory.setStack(slot, stack);
					fixed++;
				}
			}
			player.currentScreenHandler.sendContentUpdates();
			player.inventory.markDirty();
			ok(player, fixed == 0 ? "§cчинить нечего." : "починено предметов: §e" + fixed + "§r.");
			return fixed == 0 ? 0 : 1;
		}
		ItemStack hand = player.getMainHandStack();
		if (hand.isEmpty()) {
			ok(player, "§cвозьми предмет в руку.");
			return 0;
		}
		if (!fix(hand)) {
			ok(player, "§cэтот предмет не нужно чинить (или он не ломается).");
			return 0;
		}
		player.setStackInHand(Hand.MAIN_HAND, hand);
		player.currentScreenHandler.sendContentUpdates();
		ok(player, "предмет в руке починен: §e" + hand.getName().getString() + "§r.");
		return 1;
	}

	private static boolean fix(ItemStack stack) {
		if (stack.isEmpty() || !stack.isDamageable() || !stack.isDamaged()) {
			return false;
		}
		stack.setDamage(0);
		return true;
	}

	private static int near(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		StringBuilder found = new StringBuilder();
		int count = 0;
		for (ServerPlayerEntity other : player.getServer().getPlayerManager().getPlayerList()) {
			if (other == player || other.getServerWorld() != player.getServerWorld()) {
				continue;
			}
			double distance = Math.sqrt(other.squaredDistanceTo(player));
			if (distance > NEAR_RADIUS) {
				continue;
			}
			if (count > 0) {
				found.append("§7, §e");
			}
			found.append(other.getEntityName()).append("§7 (").append((int) distance).append(" бл.)");
			count++;
		}
		if (count == 0) {
			ok(player, "рядом никого нет §7(проверено в радиусе " + (int) NEAR_RADIUS + " блоков).");
			return 0;
		}
		ok(player, "рядом игроков: §e" + count + "§r — " + found);
		return 1;
	}

	// ------------------------------------------------------------------
	//  MAGISTER: /invsee, /heal
	// ------------------------------------------------------------------

	private static int invseeNoArgs(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		StringBuilder online = new StringBuilder();
		for (String name : player.getServer().getPlayerManager().getPlayerNames()) {
			if (online.length() > 0) {
				online.append("§7, §e");
			}
			online.append(name);
		}
		ok(player, "кого смотреть? §e/invsee <ник>§r. Сейчас в игре: §e" + online);
		return 0;
	}

	private static int invsee(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		String name = StringArgumentType.getString(context, "ник");
		ServerPlayerEntity target = player.getServer().getPlayerManager().getPlayer(name);
		if (target == null) {
			ok(player, "§cигрок §e" + name + "§c не в сети.");
			return 0;
		}
		boolean editable = Permissions.isOwner(player);
		player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
				(syncId, inventory, viewer) -> new ViewInventoryScreenHandler(syncId, inventory,
						target.inventory, editable),
				new LiteralText("§fИнвентарь: §e" + target.getEntityName()
						+ (editable ? " §7(OWNER: можно брать)" : " §7(только просмотр)"))));
		return 1;
	}

	private static int heal(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		player.setHealth(player.getMaxHealth());
		Cooldowns.mark(player, Permissions.HEAL);
		ok(player, "здоровье восстановлено" + Cooldowns.note(player, Permissions.HEAL));
		return 1;
	}

	// ------------------------------------------------------------------
	//  IMPERATOR: /broadcast, /lightning, /rtpnear
	// ------------------------------------------------------------------

	private static int broadcastNoArgs(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		ok(player, "что объявить? §e/broadcast <текст>§r. Перезарядка — 5 минут.");
		return 0;
	}

	private static int broadcast(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		String text = StringArgumentType.getString(context, "текст");
		// Объявление: красный жирный заголовок [ОБЪЯВЛЕНИЕ], сам текст — БЕЗ ника автора.
		player.getServer().getPlayerManager().broadcastChatMessage(
				new LiteralText("§4§l[ОБЪЯВЛЕНИЕ]§r §f" + text),
				MessageType.CHAT, Util.NIL_UUID);
		Cooldowns.mark(player, Permissions.BROADCAST);
		RandomBlocks.LOGGER.info("Broadcast by {}: {}", player.getEntityName(), text);
		return 1;
	}

	private static int lightning(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		HitResult hit = player.raycast(100.0D, 1.0F, false);
		Vec3d pos = hit.getType() == HitResult.Type.MISS
				? player.getCameraPosVec(1.0F).add(player.getRotationVec(1.0F).multiply(100.0D))
				: hit.getPos();
		BlockPos blockPos = new BlockPos(pos.x, pos.y, pos.z);
		ServerWorld world = player.getServerWorld();
		EntityType.LIGHTNING_BOLT.spawn(world, null, null, null, blockPos, SpawnReason.TRIGGERED, false, false);
		Cooldowns.mark(player, Permissions.LIGHTNING);
		ok(player, "молния ударила: §e" + blockPos.getX() + " " + blockPos.getY() + " " + blockPos.getZ()
				+ Cooldowns.note(player, Permissions.LIGHTNING));
		return 1;
	}

	private static int rtpNear(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		if (!RandomTeleport.nearPlayer(player)) {
			return 0;
		}
		Cooldowns.mark(player, Permissions.RTP_NEAR);
		return 1;
	}

	// ------------------------------------------------------------------
	//  DRAGON: /fly, /grant, погода и время
	// ------------------------------------------------------------------

	private static int fly(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		if (player.isCreative() || player.isSpectator()) {
			ok(player, "§cв творческом режиме полёт и так есть.");
			return 0;
		}
		PlayerAbilities abilities = player.abilities;
		abilities.allowFlying = !abilities.allowFlying;
		if (!abilities.allowFlying) {
			abilities.flying = false;
		}
		player.sendAbilitiesUpdate();
		ok(player, abilities.allowFlying
				? "полёт §aвключён§r: нажми двойной прыжок, чтобы взлететь."
				: "полёт §cвыключен§r.");
		return 1;
	}

	private static int grant(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerCommandSource source = context.getSource();
		ServerPlayerEntity player = source.getPlayer();
		String name = StringArgumentType.getString(context, "ник");
		String rankName = StringArgumentType.getString(context, "привилегия");
		Rank rank = Rank.byName(rankName);
		if (rank == null) {
			ok(player, "§cне знаю привилегию §e" + rankName + "§c. Можно: §ehero§c или §etitan§c.");
			return 0;
		}
		if (rank != Rank.HERO && rank != Rank.TITAN) {
			ok(player, "§cчерез /grant можно выдавать только §eHERO§c и §eTITAN§c.");
			return 0;
		}
		ServerPlayerEntity target = source.getMinecraftServer().getPlayerManager().getPlayer(name);
		if (target == null) {
			ok(player, "§cигрок §e" + name + "§c не в сети.");
			return 0;
		}
		if (target == player) {
			ok(player, "§cсебе выдавать нельзя.");
			return 0;
		}
		long left = RankManager.grantCooldownLeft(player.getUuid());
		if (left > 0) {
			ok(player, "§cты уже выдавал донат — следующий через §e" + Cooldowns.format(left) + "§c.");
			return 0;
		}
		Rank previous = RankManager.setRank(target.getUuid(), target.getEntityName(), rank);
		RankManager.markGrant(player.getUuid());
		RankManager.applySafe(target, rank);
		ok(player, "выдал привилегию §e" + rank.name + "§r игроку §e" + target.getEntityName()
				+ "§r §7(было: " + previous.name + "). Следующий донат — через 5 дней.");
		ok(target, "тебе выдана привилегия §e" + rank.name + "§r игроком §e" + player.getEntityName() + "§r!");
		source.getMinecraftServer().getPlayerManager().broadcastChatMessage(
				new LiteralText("§6[Привилегии]§r §e" + player.getEntityName() + "§r выдал привилегию §e"
						+ rank.name + "§r игроку §e" + target.getEntityName() + "§r."),
				MessageType.CHAT, Util.NIL_UUID);
		return 1;
	}

	private static int weather(CommandContext<ServerCommandSource> context, boolean rain) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		ServerWorld world = player.getServerWorld();
		if (rain) {
			world.setWeather(0, 6000, true, false);
			ok(player, "в мире §e" + world.getRegistryKey().getValue().getPath() + "§r пошёл дождь.");
		} else {
			world.setWeather(6000, 0, false, false);
			ok(player, "в мире §e" + world.getRegistryKey().getValue().getPath() + "§r ясная погода.");
		}
		return 1;
	}

	private static int time(CommandContext<ServerCommandSource> context, boolean day) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		ServerWorld world = player.getServerWorld();
		world.setTimeOfDay(day ? 1000L : 13000L);
		ok(player, "в мире §e" + world.getRegistryKey().getValue().getPath() + "§r теперь "
				+ (day ? "день" : "ночь") + ".");
		return 1;
	}

	// ------------------------------------------------------------------

	private static final SuggestionProvider<ServerCommandSource> NICKS = (context, builder) -> {
		for (String name : context.getSource().getMinecraftServer().getPlayerManager().getPlayerNames()) {
			builder.suggest(name);
		}
		return builder.buildFuture();
	};

	/** Убираем ванильную /clear, чтобы наша версия (свой инвентарь без аргументов) была видна игрокам. */
	public static void dropVanillaClear(CommandDispatcher<ServerCommandSource> dispatcher) {
		dropVanilla(dispatcher, "clear");
	}

	/**
	 * Убрать ванильную команду с таким именем из дерева Brigadier: иначе наша версия (например,
	 * /tp или /ban для OWNER) не видна обычным игрокам — Brigadier оставляет чужое требование OP.
	 */
	public static void dropVanilla(CommandDispatcher<ServerCommandSource> dispatcher, String name) {
		try {
			for (String mapName : new String[]{"children", "literals", "arguments"}) {
				Field mapField = com.mojang.brigadier.tree.CommandNode.class.getDeclaredField(mapName);
				mapField.setAccessible(true);
				Object value = mapField.get(dispatcher.getRoot());
				if (value instanceof Map) {
					((Map<?, ?>) value).remove(name);
				}
			}
			RandomBlocks.LOGGER.info("Vanilla /{} replaced by the mod version", name);
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("Could not replace vanilla /{}: {}", name, t.toString());
		}
	}
}
