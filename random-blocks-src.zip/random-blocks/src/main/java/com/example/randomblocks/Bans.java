package com.example.randomblocks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.ClientConnection;
import net.minecraft.text.LiteralText;

import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Блокировки игроков (1.13.0): {@code /ban <ник> [время] [причина]}.
 *
 * <p>Бан по нику. Время — как везде в моде ({@code 10s}, {@code 30m}, {@code 2h}, {@code 7d};
 * пусто или {@code forever} — навсегда). Хранится в {@code config/randomblocks-bans.json}.
 * Про баны знают только владельцы: обычным игрокам мод про них ничего не пишет.</p>
 */
public final class Bans {

	public static final class Entry {
		public String name = "";
		public String reason = "";
		public String by = "";
		public long until;              // 0 — навсегда, иначе — время окончания в мс
	}

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Type TYPE = new TypeToken<LinkedHashMap<String, Entry>>() { }.getType();

	private static final Map<String, Entry> BANS = new LinkedHashMap<>();

	private Bans() {
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("randomblocks-bans.json");
	}

	public static synchronized void load() {
		BANS.clear();
		Path path = file();
		if (!Files.exists(path)) {
			return;
		}
		try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
			Map<String, Entry> raw = GSON.fromJson(reader, TYPE);
			if (raw != null) {
				BANS.putAll(raw);
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("bans file not read: {}", t.toString());
		}
	}

	public static synchronized void save() {
		try (Writer writer = Files.newBufferedWriter(file(), StandardCharsets.UTF_8)) {
			GSON.toJson(BANS, writer);
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("bans file not saved: {}", t.toString());
		}
	}

	private static String key(String name) {
		return name == null ? "" : name.toLowerCase(Locale.ROOT);
	}

	/** Забанен ли игрок с таким ником прямо сейчас. */
	public static synchronized Entry active(String name) {
		Entry entry = BANS.get(key(name));
		if (entry == null) {
			return null;
		}
		if (entry.until > 0 && entry.until < System.currentTimeMillis()) {
			return null;                    // срок вышел — бан больше не действует
		}
		return entry;
	}

	public static synchronized void ban(String name, String reason, String by, long untilMs) {
		Entry entry = new Entry();
		entry.name = name;
		entry.reason = reason == null || reason.isEmpty() ? "без причины" : reason;
		entry.by = by == null ? "" : by;
		entry.until = untilMs;
		BANS.put(key(name), entry);
		save();
	}

	public static synchronized boolean unban(String name) {
		if (BANS.remove(key(name)) == null) {
			return false;
		}
		save();
		return true;
	}

	public static synchronized List<Entry> all() {
		List<Entry> list = new ArrayList<>();
		long now = System.currentTimeMillis();
		for (Entry entry : BANS.values()) {
			if (entry.until == 0 || entry.until > now) {
				list.add(entry);
			}
		}
		return list;
	}

	/** «2 дн 3 ч» — сколько осталось; для бессрочного — «навсегда». */
	public static String left(Entry entry) {
		if (entry == null) {
			return "—";
		}
		if (entry.until <= 0) {
			return "навсегда";
		}
		long seconds = Math.max(0L, (entry.until - System.currentTimeMillis()) / 1000L);
		long days = seconds / 86400L;
		long hours = (seconds % 86400L) / 3600L;
		long minutes = (seconds % 3600L) / 60L;
		if (days > 0) {
			return days + " дн " + hours + " ч";
		}
		if (hours > 0) {
			return hours + " ч " + minutes + " мин";
		}
		if (minutes > 0) {
			return minutes + " мин " + (seconds % 60L) + " с";
		}
		return seconds + " с";
	}

	/** Кик при входе: сообщение видит только сам забаненный (и владельцы в логе). */
	public static void kickIfBanned(ClientConnection connection, String name) {
		Entry entry = active(name);
		if (entry == null) {
			return;
		}
		String left = left(entry);
		connection.disconnect(new LiteralText("§cТы забанен на этом сервере.\n§7Причина: §f"
				+ entry.reason + "\n§7Осталось: §f" + left));
		RandomBlocks.LOGGER.info("Banned player {} tried to join (reason: {}, left: {})",
				name, entry.reason, left);
	}
}
