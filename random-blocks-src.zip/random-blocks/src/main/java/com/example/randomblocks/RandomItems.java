package com.example.randomblocks;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Вторая половина мода: случайные предметы.
 *
 * Пул — все предметы игры, кроме творческих/отладочных (список itemBlacklist в конфиге).
 * Зачарование накладывается только на то, что игра сама считает чаруемым
 * ({@link Item#isEnchantable(ItemStack)}) — то есть на кирки, мечи, броню, удочки, книги и т.п.
 * На камень, землю, еду, блоки и прочее чары не ложатся — там их и в столе чар не бывает.
 *
 * Сами чары подбирает ванильный {@link EnchantmentHelper#enchant}: он учитывает тип предмета,
 * поэтому у кирки будет «Эффективность/Прочность», у меча «Острота», у брони «Защита» и никакой отсебятины.
 */
public final class RandomItems {

	private static List<Item> pool;
	private static int poolStamp = Integer.MIN_VALUE;
	/** Что выдали в прошлый раз — это видно в нижней плашке таймера («прошлый: …»). */
	private static String lastGiven = "";

	private RandomItems() {
	}

	/** Список предметов, которые могут выпасть (кэшируется; пересобирается при смене блэклиста). */
	public static List<Item> pool(ModConfig cfg) {
		int stamp = cfg.itemBlacklist == null ? 0 : cfg.itemBlacklist.hashCode();
		if (pool != null && stamp == poolStamp) {
			return pool;
		}
		List<Item> items = new ArrayList<>();
		for (Identifier id : Registry.ITEM.getIds()) {
			if (id.getPath().equals("air")) {
				continue;
			}
			Item item = Registry.ITEM.get(id);
			if (item == null || item.getMaxCount() <= 0) {
				continue;
			}
			if (cfg.isItemBlacklisted(item)) {
				continue;
			}
			items.add(item);
		}
		pool = items;
		poolStamp = stamp;
		RandomBlocks.LOGGER.info("Item pool built: {} items can be given", items.size());
		return pool;
	}

	public static void invalidatePool() {
		pool = null;
		poolStamp = Integer.MIN_VALUE;
	}

	/**
	 * Случайный предмет: обычно 1 штука, с шансом {@code itemMultiDropChance} — сразу пачка.
	 *
	 * Про пачку решаем ДО выбора предмета: так «15%» — это честные 15% всех выдач,
	 * а не 15% от тех предметов, которые вообще умеют стакаться. Если пачка выпала,
	 * а предмет не стакается (кирка, броня, зелье) — берём другой, стакающийся.
	 */
	public static ItemStack createRandom(ServerWorld world, ModConfig cfg) {
		List<Item> items = pool(cfg);
		if (items.isEmpty()) {
			return ItemStack.EMPTY;
		}
		boolean batch = cfg.itemMultiDropChance > 0.0D
				&& world.random.nextDouble() < cfg.itemMultiDropChance;
		Item item = pickItem(world, cfg, batch);
		ItemStack stack = new ItemStack(item, 1);

		boolean enchantable = item.isEnchantable(stack) || item == Items.BOOK;
		boolean enchanted = false;
		// Пачку не зачаровываем: чары выдаём по одной штуке.
		if (!batch && enchantable && cfg.itemEnchantChance > 0.0D
				&& world.random.nextDouble() < cfg.itemEnchantChance) {
			int level = cfg.itemEnchantMinLevel;
			if (cfg.itemEnchantMaxLevel > cfg.itemEnchantMinLevel) {
				level += world.random.nextInt(cfg.itemEnchantMaxLevel - cfg.itemEnchantMinLevel + 1);
			}
			stack = EnchantmentHelper.enchant(world.random, stack, level, true);
			enchanted = true;
		}
		stack.setCount(rollAmount(world.random, item, cfg, batch));
		return stack;
	}

	/** Выбираем предмет; при необходимости — только такой, который умеет стакаться. */
	private static Item pickItem(ServerWorld world, ModConfig cfg, boolean stackableNeeded) {
		List<Item> items = pool(cfg);
		Item item = items.get(world.random.nextInt(items.size()));
		if (!stackableNeeded || item.getMaxCount() > 1) {
			return item;
		}
		for (int i = 0; i < 32; i++) {
			Item candidate = items.get(world.random.nextInt(items.size()));
			if (candidate.getMaxCount() > 1) {
				return candidate;
			}
		}
		return item;
	}


	/**
	 * Сколько предметов выдавать.
	 *
	 * Пачка (по умолчанию 2…16 штук) выдаётся, когда розыгрыш пачки уже выиграл ({@code batch}),
	 * и только для стакающихся предметов: «16 кирок» — это сломанный предмет.
	 * Отдельная настройка {@code itemAmountMax} умеет выдавать по несколько штук всегда.
	 */
	private static int rollAmount(java.util.Random random, Item item, ModConfig cfg, boolean batch) {
		if (item.getMaxCount() <= 1) {
			return 1;
		}
		if (batch) {
			int min = Math.max(2, cfg.itemMultiDropMin);
			int max = Math.max(min, cfg.itemMultiDropMax);
			return Math.max(1, Math.min(min + random.nextInt(max - min + 1), item.getMaxCount()));
		}
		if (cfg.itemAmountMax > 1) {
			return Math.max(1, Math.min(1 + random.nextInt(cfg.itemAmountMax), item.getMaxCount()));
		}
		return 1;
	}

	/** Название последнего выданного предмета (для плашки таймера). */
	public static String lastGiven() {
		return lastGiven == null ? "" : lastGiven;
	}

	/** Выдаёт по случайному предмету каждому игроку в сети. */
	public static void giveToAll(MinecraftServer server, ModConfig cfg) {
		ServerWorld world = server.getOverworld();
		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			if (cfg.skipSpectator && player.isSpectator()) {
				continue;
			}
			ItemStack stack = createRandom(world, cfg);
			if (stack.isEmpty()) {
				continue;
			}
			// Текст готовим ДО выдачи: giveItemStack при успехе обнуляет переданный стек
			// (он становится «пустым»), и имя предмета после выдачи уже не прочитать.
			Text message = itemMessage(stack);
			String name = describe(stack);
			if (!player.giveItemStack(stack) && !stack.isEmpty()) {
				// Инвентарь полон — роняем предмет под ноги, чтобы он не пропал.
				player.dropItem(stack, false);
			}
			player.sendMessage(message, false);
			lastGiven = name;
			RandomBlocks.LOGGER.info("Random item given to {}: {}", player.getEntityName(), name);
		}
	}

	/**
	 * Сообщение игроку. Название предмета и чары отправляются как переводимый текст,
	 * поэтому в русском клиенте будет «Розовый тюльпан», «Эффективность III», а не английские имена.
	 */
	public static Text itemMessage(ItemStack stack) {
		MutableText text = new LiteralText("§6[Random Blocks]§r выдан случайный предмет: §e").append(stack.getName());
		if (stack.getCount() > 1) {
			text.append(new LiteralText(" x" + stack.getCount()));
		}
		Map<Enchantment, Integer> enchantments = EnchantmentHelper.get(stack);
		if (!enchantments.isEmpty()) {
			text.append(new LiteralText(" §b["));
			boolean first = true;
			for (Map.Entry<Enchantment, Integer> entry : enchantments.entrySet()) {
				if (!first) {
					text.append(new LiteralText(", "));
				}
				first = false;
				text.append(entry.getKey().getName(entry.getValue()));
			}
			text.append(new LiteralText("]"));
		}
		return text;
	}

	/** «Diamond Pickaxe x2 [Efficiency III]» — для лога и подсказок серверу. */
	public static String describe(ItemStack stack) {
		StringBuilder sb = new StringBuilder(stack.getName().getString());
		if (stack.getCount() > 1) {
			sb.append(" x").append(stack.getCount());
		}
		Map<Enchantment, Integer> enchantments = EnchantmentHelper.get(stack);
		if (!enchantments.isEmpty()) {
			sb.append(" §b[");
			boolean first = true;
			for (Map.Entry<Enchantment, Integer> entry : enchantments.entrySet()) {
				if (!first) {
					sb.append(", ");
				}
				first = false;
				sb.append(entry.getKey().getName(entry.getValue()).getString());
			}
			sb.append("]§e");
		}
		return sb.toString();
	}
}
