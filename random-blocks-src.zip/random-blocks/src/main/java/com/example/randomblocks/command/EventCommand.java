package com.example.randomblocks.command;

import com.example.randomblocks.EventDefs;
import com.example.randomblocks.EventManager;
import com.example.randomblocks.ItemTimerManager;
import com.example.randomblocks.ModConfig;
import com.example.randomblocks.RandomBlocks;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;

/**
 * Третий «мод»: /randomevent — случайные события. По умолчанию они случаются сами,
 * без голосования (режим голосования остался как необязательный: /randomevent mode vote).
 *
 *   /randomevent                      — статус (доступно всем)
 *   /randomevent start | stop         — запустить / остановить таймер голосований (OP)
 *   /randomevent time <время>         — интервал между голосованиями: 30s / 10m / 1h / 1h30m (OP)
 *   /randomevent now                  — начать голосование прямо сейчас (OP)
 *   /randomevent fire <id события>    — запустить событие немедленно, без голосования (OP)
 *   /randomevent list                 — список всех событий с их id (доступно всем)
 *   /randomevent vote <1–4>           — проголосовать (доступно всем, на это и кликают в чате)
 */
public final class EventCommand {

	private EventCommand() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> dispatcher.register(
				CommandManager.literal("randomevent")
						.executes(EventCommand::status)
						.then(CommandManager.literal("vote")
								.then(CommandManager.argument("number", IntegerArgumentType.integer(1, 9))
										.executes(EventCommand::vote)))
						.then(CommandManager.literal("list")
								.executes(EventCommand::list))
						.then(CommandManager.literal("start")
								.requires(source -> source.hasPermissionLevel(2))
								.executes(EventCommand::start))
						.then(CommandManager.literal("stop")
								.requires(source -> source.hasPermissionLevel(2))
								.executes(EventCommand::stop))
						.then(CommandManager.literal("now")
								.requires(source -> source.hasPermissionLevel(2))
								.executes(EventCommand::now))
						.then(CommandManager.literal("mode")
								.requires(source -> source.hasPermissionLevel(2))
								.then(CommandManager.literal("random")
										.executes(ctx -> mode(ctx, false)))
								.then(CommandManager.literal("vote")
										.executes(ctx -> mode(ctx, true))))
						.then(CommandManager.literal("time")
								.requires(source -> source.hasPermissionLevel(2))
								.then(CommandManager.argument("time", StringArgumentType.greedyString())
										.executes(EventCommand::time)))
						.then(CommandManager.literal("fire")
								.requires(source -> source.hasPermissionLevel(2))
								.then(CommandManager.argument("event", StringArgumentType.greedyString())
										.executes(EventCommand::fire)))
		));
	}

	private static String onOff(boolean value) {
		return value ? "§aзапущены" : "§cостановлены";
	}

	// ------------------------------------------------------------------

	private static int status(CommandContext<ServerCommandSource> context) {
		ModConfig cfg = RandomBlocks.getConfig();
		ServerCommandSource source = context.getSource();
		source.sendFeedback(new LiteralText("§6[Random Event]§r v" + RandomBlocks.version()
				+ " §7· автор: Дмитрий§r — события: " + onOff(cfg.eventTimerEnabled)), false);
		source.sendFeedback(new LiteralText("  режим: §e" + (cfg.eventVotingEnabled
				? "голосование (игроки выбирают из " + cfg.eventOptionsCount + " вариантов)"
				: "случайные события (сами, без голосования)")
				+ (cfg.eventVotingEnabled ? "" : " — переключить: §e/randomevent mode vote")), false);
		source.sendFeedback(new LiteralText(String.format(
				"  интервал: §e%s§r (%s), отрицательные: §e%s§r, шанс плохого события: §e%.0f%%§r",
				ItemTimerManager.describeInterval(cfg.eventIntervalSeconds),
				ItemTimerManager.formatTime(cfg.eventIntervalSeconds),
				cfg.eventAllowNegative ? "да" : "нет",
				cfg.eventNegativeChance * 100.0D)), false);
		if (cfg.eventVotingEnabled) {
			source.sendFeedback(new LiteralText("  голосование: длительность §e" + cfg.eventVoteDurationSeconds
					+ " сек§r, вариантов: §e" + cfg.eventOptionsCount), false);
		}
		if (EventManager.isActive()) {
			source.sendFeedback(new LiteralText("  §eидёт голосование§r, осталось §e"
					+ EventManager.voteSecondsLeft() + " сек§r, проголосовало: §e"
					+ EventManager.voteCount()), false);
		} else if (cfg.eventTimerEnabled) {
			source.sendFeedback(new LiteralText("  следующее событие через §e"
					+ ItemTimerManager.formatTime(EventManager.secondsToNextVote())), false);
		}
		source.sendFeedback(new LiteralText("  всего событий: §e" + EventDefs.all().size()
				+ "§r (список — §e/randomevent list§r), таймер на экране: §e"
				+ (cfg.eventOverlayEnabled ? "да" : "нет") + "§r (§7eventOverlayEnabled§r)"), false);
		return 1;
	}

	private static int list(CommandContext<ServerCommandSource> context) {
		ServerCommandSource source = context.getSource();
		source.sendFeedback(new LiteralText("§6[Random Event]§r всего событий: §e" + EventDefs.all().size()), false);
		for (EventDefs.Def def : EventDefs.all()) {
			source.sendFeedback(new LiteralText("  " + def.kind.tag + " §f" + def.name + "§r §7— "
					+ def.description + " §8(id: " + def.id + ")"), false);
		}
		return 1;
	}

	private static int vote(CommandContext<ServerCommandSource> context) {
		ServerCommandSource source = context.getSource();
		ServerPlayerEntity player;
		try {
			player = source.getPlayer();
		} catch (CommandSyntaxException e) {
			source.sendError(new LiteralText("§cГолосовать можно только от имени игрока"));
			return 0;
		}
		int number = IntegerArgumentType.getInteger(context, "number");
		if (!EventManager.vote(player, number)) {
			source.sendError(new LiteralText(EventManager.isActive()
					? "§cТакого варианта нет — выбери от 1 до " + EventManager.currentOptions().size()
					: "§cСейчас нет активного голосования"));
			return 0;
		}
		return 1;
	}

	private static int start(CommandContext<ServerCommandSource> context) {
		EventManager.start(context.getSource().getMinecraftServer(), RandomBlocks.getConfig());
		RandomBlocks.LOGGER.info("randomevent: started");
		return 1;
	}

	private static int stop(CommandContext<ServerCommandSource> context) {
		EventManager.stop(context.getSource().getMinecraftServer(), RandomBlocks.getConfig());
		RandomBlocks.LOGGER.info("randomevent: stopped");
		return 1;
	}

	private static int now(CommandContext<ServerCommandSource> context) {
		ModConfig cfg = RandomBlocks.getConfig();
		boolean started = EventManager.fireNow(context.getSource().getMinecraftServer(), cfg);
		if (!started) {
			context.getSource().sendError(new LiteralText(cfg.eventVotingEnabled
					? "§cНе получилось начать голосование (нет игроков или событий)"
					: "§cНе получилось запустить событие (нет игроков)"));
			return 0;
		}
		RandomBlocks.LOGGER.info("randomevent: now (voting={})", cfg.eventVotingEnabled);
		return 1;
	}

	private static int mode(CommandContext<ServerCommandSource> context, boolean voting) {
		EventManager.setVoting(context.getSource().getMinecraftServer(), RandomBlocks.getConfig(), voting);
		RandomBlocks.LOGGER.info("randomevent: mode set to {}", voting ? "vote" : "random");
		return 1;
	}

	private static int time(CommandContext<ServerCommandSource> context) {
		ModConfig cfg = RandomBlocks.getConfig();
		String raw = StringArgumentType.getString(context, "time");
		int seconds = ItemTimerManager.parseDurationSeconds(raw);
		if (seconds < 0) {
			context.getSource().sendError(new LiteralText("§cНе понял время «" + raw + "». Примеры: §e30s§c или §e30с§c — сек, "
					+ "§e10m§c или §e10м§c — мин, §e1h§c или §e1ч§c — часы, §e1h30m§c; просто число — это минуты (§e5§c)."));
			return 0;
		}
		if (seconds > 604800) {
			seconds = 604800;
		}
		if (seconds < 5) {
			seconds = 5;
		}
		cfg.eventIntervalSeconds = seconds;
		cfg.save();
		EventManager.reset(cfg);
		context.getSource().sendFeedback(new LiteralText("§6[Random Event]§r события каждые §e"
				+ ItemTimerManager.describeInterval(seconds) + "§r (" + ItemTimerManager.formatTime(seconds) + ")"
				+ (cfg.eventTimerEnabled ? ", отсчёт заново" : "")), false);
		RandomBlocks.LOGGER.info("randomevent: interval set to {}s (command input \"{}\")", seconds, raw);
		return 1;
	}

	private static int fire(CommandContext<ServerCommandSource> context) {
		String raw = StringArgumentType.getString(context, "event");
		EventDefs.Def def = EventDefs.byId(raw);
		if (def == null) {
			context.getSource().sendError(new LiteralText("§cНеизвестное событие «" + raw
					+ "». Посмотреть список: §e/randomevent list"));
			return 0;
		}
		EventDefs.broadcast(context.getSource().getMinecraftServer(),
				"§6Событие: §f" + def.name + " §7— " + def.description);
		EventDefs.run(def, context.getSource().getMinecraftServer(), RandomBlocks.getConfig());
		RandomBlocks.LOGGER.info("randomevent: fired {} by command", def.id);
		return 1;
	}
}
