package com.example.randomblocks.command;

import com.example.randomblocks.BlockRandomizer;
import com.example.randomblocks.ItemTimerManager;
import com.example.randomblocks.ModConfig;
import com.example.randomblocks.RandomBlocks;
import com.example.randomblocks.RankManager;
import com.example.randomblocks.RandomItems;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;

/**
 * Команда /randomblock (нужен Fabric API; без него мод работает без команды).
 *
 *   /randomblock                    — статус: блоки и таймер предметов
 *   /randomblock start | stop       — включить/выключить случайные блоки под ногами
 *   /randomblock here               — превратить блок под собой прямо сейчас
 *   /randomblock item               — статус таймера предметов
 *   /randomblock item start | stop  — запустить/остановить выдачу случайных предметов
 *   /randomblock item time <время>  — свой интервал: 30s / 10m / 1h / 1h30m / 5 (минуты),
 *                                      понимает и русские буквы: 30с, 10м, 1ч
 *   /randomblock check <блок>       — проверка конкретного блока
 *   /randomblock reload             — перечитать config/randomblocks.json
 *
 * Все команды требуют уровень оператора 2.
 */
public final class RandomBlocksCommand {

	private RandomBlocksCommand() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> dispatcher.register(
				CommandManager.literal("randomblock")
						.requires(source -> source.hasPermissionLevel(2))
						.executes(RandomBlocksCommand::status)
						.then(CommandManager.literal("start")
								.executes(context -> setBlocks(context, true)))
						.then(CommandManager.literal("stop")
								.executes(context -> setBlocks(context, false)))
						.then(CommandManager.literal("here")
								.executes(RandomBlocksCommand::here))
						.then(CommandManager.literal("item")
								.executes(RandomBlocksCommand::itemStatus)
								.then(CommandManager.literal("start")
										.executes(RandomBlocksCommand::itemStart))
								.then(CommandManager.literal("stop")
										.executes(RandomBlocksCommand::itemStop))
								.then(CommandManager.literal("time")
										.then(CommandManager.argument("time", StringArgumentType.greedyString())
												.executes(RandomBlocksCommand::itemTime))))
						.then(CommandManager.literal("check")
								.then(CommandManager.argument("block", StringArgumentType.greedyString())
										.executes(context -> check(context, StringArgumentType.getString(context, "block")))))
						.then(CommandManager.literal("reload")
								.executes(RandomBlocksCommand::reload))
		));
	}

	/** да/нет — читабельнее, чем true/false. */
	private static String ru(boolean value) {
		return value ? "да" : "нет";
	}

	private static String onOff(boolean value) {
		return value ? "§aзапущен" : "§cостановлен";
	}

	// ------------------------------------------------------------------
	//  Часть 1: блоки
	// ------------------------------------------------------------------

	private static int status(CommandContext<ServerCommandSource> context) {
		ModConfig cfg = RandomBlocks.getConfig();
		ServerCommandSource source = context.getSource();
		source.sendFeedback(new LiteralText("§6[Random Blocks]§r v" + RandomBlocks.version()
				+ " §7· автор: Дмитрий§r"), false);
		source.sendFeedback(new LiteralText(String.format(
				"§6[Random Blocks]§r случайные блоки: %s§r (шанс §e%.0f%%§r, пул §e%d§r блоков, только полные: §e%s§r)",
				onOff(cfg.enabled), cfg.transformChance * 100.0D,
				BlockRandomizer.pool(cfg).size(), ru(cfg.onlyFullBlocks))), false);
		String timer;
		if (cfg.itemTimerEnabled) {
			timer = "§aзапущен§r, следующий предмет через §e" + ItemTimerManager.formatTime(ItemTimerManager.secondsLeft());
		} else {
			timer = "§cостановлен";
		}
		source.sendFeedback(new LiteralText(String.format(
				"§6[Random Blocks]§r случайные предметы: %s§r (интервал §e%s§r (%s), шанс чар §e%.0f%%§r, предметов в пуле §e%d§r)",
				timer, ItemTimerManager.describeInterval(cfg.itemIntervalSeconds),
				ItemTimerManager.formatTime(cfg.itemIntervalSeconds),
				cfg.itemEnchantChance * 100.0D, RandomItems.pool(cfg).size())), false);
		source.sendFeedback(new LiteralText(String.format(
				"§6[Random Blocks]§r пачка вместо одной штуки: шанс §e%.0f%%§r, размер §e%d–%d§r (обычно приходит 1 предмет)",
				cfg.itemMultiDropChance * 100.0D, cfg.itemMultiDropMin, cfg.itemMultiDropMax)), false);
		RandomBlocks.LOGGER.info(
				"randomblock status: blocks={} (chance={}, pool={}), items={} (interval={}s, enchantChance={}, pool={})",
				cfg.enabled, cfg.transformChance, BlockRandomizer.pool(cfg).size(),
				cfg.itemTimerEnabled, cfg.itemIntervalSeconds, cfg.itemEnchantChance, RandomItems.pool(cfg).size());
		return 1;
	}

	private static int setBlocks(CommandContext<ServerCommandSource> context, boolean enabled) {
		ModConfig cfg = RandomBlocks.getConfig();
		cfg.enabled = enabled;
		cfg.save();
		BlockRandomizer.forgetLastBlocks();
		context.getSource().sendFeedback(new LiteralText(enabled
				? "§6[Random Blocks]§r случайные блоки под ногами: §aзапущены"
				: "§6[Random Blocks]§r случайные блоки под ногами: §cостановлены"), false);
		RandomBlocks.LOGGER.info("randomblock: blocks enabled={} (by command)", enabled);
		return 1;
	}

	private static int reload(CommandContext<ServerCommandSource> context) {
		RandomBlocks.reloadConfig();
		RankManager.load();            // перечитать и привилегии: правки в файле подхватываются сразу
		RankManager.onConfigReload(context.getSource().getMinecraftServer());
		context.getSource().sendFeedback(new LiteralText("§6[Random Blocks]§r конфиг перечитан из "
				+ ModConfig.configPath().getFileName()), true);
		RandomBlocks.LOGGER.info("randomblock config reloaded");
		return 1;
	}

	private static int here(CommandContext<ServerCommandSource> context) {
		ServerCommandSource source = context.getSource();
		ServerPlayerEntity player;
		try {
			player = source.getPlayer();
		} catch (CommandSyntaxException e) {
			source.sendError(new LiteralText("§cЭта команда работает только от имени игрока"));
			return 0;
		}
		ModConfig cfg = RandomBlocks.getConfig();
		BlockPos pos = BlockRandomizer.blockUnder(player);
		if (pos == null) {
			source.sendError(new LiteralText("§cПод игроком ничего подходящего (вода/лава?)"));
			return 0;
		}
		boolean changed = BlockRandomizer.transform(player.getServerWorld(), pos, cfg);
		if (changed) {
			source.sendFeedback(new LiteralText("§6[Random Blocks]§r блок " + pos.getX() + " " + pos.getY()
					+ " " + pos.getZ() + " превращён"), false);
			return 1;
		}
		source.sendError(new LiteralText("§cЭтот блок превратить нельзя (защищён, неполный или из блэклиста)"));
		return 0;
	}

	// ------------------------------------------------------------------
	//  Часть 2: предметы
	// ------------------------------------------------------------------

	private static int itemStatus(CommandContext<ServerCommandSource> context) {
		ModConfig cfg = RandomBlocks.getConfig();
		ServerCommandSource source = context.getSource();
		source.sendFeedback(new LiteralText("§6[Random Blocks]§r v" + RandomBlocks.version()
				+ " — таймер предметов: " + onOff(cfg.itemTimerEnabled)), false);
		source.sendFeedback(new LiteralText(String.format(
				"  интервал: §e%s§r (%s), шанс чар: §e%.0f%%§r, уровень чар: §e%d…%d§r, предметов в пуле: §e%d",
				ItemTimerManager.describeInterval(cfg.itemIntervalSeconds), ItemTimerManager.formatTime(cfg.itemIntervalSeconds), cfg.itemEnchantChance * 100.0D,
				cfg.itemEnchantMinLevel, cfg.itemEnchantMaxLevel, RandomItems.pool(cfg).size())), false);
		if (cfg.itemTimerEnabled) {
			source.sendFeedback(new LiteralText("  следующий предмет через §e"
					+ ItemTimerManager.formatTime(ItemTimerManager.secondsLeft())), false);
		}
		return 1;
	}

	private static int itemStart(CommandContext<ServerCommandSource> context) {
		ModConfig cfg = RandomBlocks.getConfig();
		MinecraftServer server = context.getSource().getMinecraftServer();
		ItemTimerManager.start(server, cfg);
		context.getSource().sendFeedback(new LiteralText(String.format(
				"§6[Random Blocks]§r выдача предметов §aзапущена§r: каждые §e%s§r (%s), отсчёт виден над инвентарём",
				ItemTimerManager.describeInterval(cfg.itemIntervalSeconds),
				ItemTimerManager.formatTime(cfg.itemIntervalSeconds))), false);
		RandomBlocks.LOGGER.info("randomblock: item timer enabled, interval={}s", cfg.itemIntervalSeconds);
		return 1;
	}

	private static int itemStop(CommandContext<ServerCommandSource> context) {
		ModConfig cfg = RandomBlocks.getConfig();
		ItemTimerManager.stop(context.getSource().getMinecraftServer(), cfg);
		context.getSource().sendFeedback(new LiteralText(
				"§6[Random Blocks]§r выдача предметов §cостановлена"), false);
		RandomBlocks.LOGGER.info("randomblock: item timer disabled");
		return 1;
	}

	private static int itemTime(CommandContext<ServerCommandSource> context) {
		ModConfig cfg = RandomBlocks.getConfig();
		String raw = StringArgumentType.getString(context, "time");
		int seconds = ItemTimerManager.parseDurationSeconds(raw);
		if (seconds < 0) {
			context.getSource().sendError(new LiteralText("§cНе понял время «" + raw + "». Примеры: §e30s§c или §e30с§c — сек, "
					+ "§e10m§c или §e10м§c — мин, §e1h§c или §e1ч§c — часы, §e1h30m§c — час тридцать; "
					+ "просто число — это минуты (§e5§c)."));
			return 0;
		}
		if (seconds > 604800) {
			seconds = 604800;                 // максимум — 7 суток
		}
		cfg.itemIntervalSeconds = seconds;
		cfg.save();
		if (cfg.itemTimerEnabled) {
			ItemTimerManager.start(context.getSource().getMinecraftServer(), cfg);
		}
		context.getSource().sendFeedback(new LiteralText("§6[Random Blocks]§r интервал выдачи предметов: §e"
				+ ItemTimerManager.describeInterval(seconds) + "§r (" + ItemTimerManager.formatTime(seconds) + ")"
				+ (cfg.itemTimerEnabled ? ", отсчёт начат заново" : "")), false);
		RandomBlocks.LOGGER.info("randomblock: item interval set to {}s (command input \"{}\")", seconds, raw);
		return 1;
	}

	// ------------------------------------------------------------------
	//  Проверка блока
	// ------------------------------------------------------------------

	private static int check(CommandContext<ServerCommandSource> context, String rawId) {
		ServerCommandSource source = context.getSource();
		Identifier id = Identifier.tryParse(rawId.trim());
		if (id == null || !Registry.BLOCK.getIds().contains(id)) {
			source.sendError(new LiteralText("§cНеизвестный блок: " + rawId + " (пример: minecraft:grass_block)"));
			return 0;
		}
		Block block = Registry.BLOCK.get(id);
		ModConfig cfg = RandomBlocks.getConfig();
		BlockState state = block.getDefaultState();
		boolean fullHeight = BlockRandomizer.isFullHeightCollision(source.getWorld(), BlockPos.ORIGIN, state);
		boolean canReplace = fullHeight && BlockRandomizer.canReplaceBlock(block, cfg);

		source.sendFeedback(new LiteralText("§6[Random Blocks]§r проверка §f" + id + "§r:"), false);
		source.sendFeedback(new LiteralText("  полный непрозрачный блок: §e" + ru(BlockRandomizer.isFullCubeBlock(state))), false);
		source.sendFeedback(new LiteralText("  коллизия ровно 1 блок в высоту (не сдвинет игрока): §e" + ru(fullHeight)), false);
		source.sendFeedback(new LiteralText("  есть инвентарь/block entity (защищён): §e"
				+ ru(block instanceof BlockEntityProvider)), false);
		source.sendFeedback(new LiteralText("  в списке protectBlocks: §e" + ru(cfg.isProtected(block))), false);
		source.sendFeedback(new LiteralText("  §l=> можно превратить: §r§e" + ru(canReplace)), false);
		source.sendFeedback(new LiteralText("  может выпасть как случайный блок: §e"
				+ ru(BlockRandomizer.pool(cfg).contains(block))), false);
		return 1;
	}
}
