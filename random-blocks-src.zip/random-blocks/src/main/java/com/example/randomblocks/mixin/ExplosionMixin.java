package com.example.randomblocks.mixin;

import com.example.randomblocks.RandomBlocks;
import com.example.randomblocks.SpawnZone;
import com.example.randomblocks.TeleportPoints;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.explosion.Explosion;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Спавн нельзя подорвать (1.13.0).
 *
 * <p>Взрыв (ТНТ, крипер, кровати, якоря) собирает список блоков, которые собирается снести.
 * Здесь мы выкидываем из этого списка всё, что попало в зону спавна — блоки остаются целыми,
 * как их ни подрывай.</p>
 */
@Mixin(Explosion.class)
public class ExplosionMixin {

	@Shadow
	@Final
	private List<BlockPos> affectedBlocks;

	@Inject(method = "collectBlocksAndDamageEntities()V", at = @At("TAIL"))
	private void randomblocks$protectSpawn(CallbackInfo ci) {
		try {
			if (!SpawnZone.active() || affectedBlocks == null || affectedBlocks.isEmpty()) {
				return;
			}
			TeleportPoints.Point spawn = TeleportPoints.spawn();
			if (spawn == null) {
				return;
			}
			double half = SpawnZone.half();
			int removed = affectedBlocks.size();
			affectedBlocks.removeIf(pos -> Math.abs(pos.getX() + 0.5D - spawn.x) <= half
					&& Math.abs(pos.getZ() + 0.5D - spawn.z) <= half);
			removed -= affectedBlocks.size();
			if (removed > 0 && RandomBlocks.getConfig().debugLog) {
				RandomBlocks.LOGGER.info("Explosion at spawn zone: {} blocks protected", removed);
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("spawn explosion protection failed: {}", t.toString());
		}
	}

	/** Заглушка для смежных версий: сущностям в зоне урон и так отменяет SpawnZone. */
	static boolean inZone(Entity entity) {
		return entity instanceof net.minecraft.server.network.ServerPlayerEntity
				&& SpawnZone.inside((net.minecraft.server.network.ServerPlayerEntity) entity);
	}
}
