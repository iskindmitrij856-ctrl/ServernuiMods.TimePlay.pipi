package com.example.randomblocks;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Менеджер случайных событий (третий «мод»).
 *
 * По умолчанию события срабатывают САМИ, без голосования: раз в N минут отсчитывает таймер,
 * и ровно в тот момент, когда на плашке загорается 0, событие происходит — без всяких
 * «дополнительных трёх секунд» (в 1.7.0 фаза предупреждения убрана совсем).
 * Голосование осталось как необязательный режим (eventVotingEnabled = true или
 * /randomevent mode vote) — тогда в чат приходит опрос на 4 варианта, игроки пишут цифру 1–4.
 */
public final class EventManager {

	/** Сколько тиков плашка показывает название только что сработавшего события. */
	private static final int FLASH_TICKS = 40;

	private static final Map<UUID, Integer> votes = new HashMap<>();
	private static final List<Scheduled> scheduled = new ArrayList<>();

	private static List<EventDefs.Def> options = new ArrayList<>();
	private static boolean active;                 // идёт голосование (только в режиме vote)
	private static int voteTicksLeft;
	private static int ticksToNext;
	private static int lastShownSecond = Integer.MIN_VALUE;
	private static int lastTick = Integer.MIN_VALUE;
	private static boolean overlayHidden = true;
	/** Тики, оставшиеся для показа «Событие: …» после срабатывания. */
	private static int flashTicks;
	private static String flashText = "";

	private EventManager() {
	}

	private static final class Scheduled {
		final int at;
		final Runnable task;

		Scheduled(int at, Runnable task) {
			this.at = at;
			this.task = task;
		}
	}

	// ------------------------------------------------------------------
	//  Жизненный цикл
	// ------------------------------------------------------------------

	public static void reset(ModConfig cfg) {
		active = false;
		votes.clear();
		options = new ArrayList<>();
		scheduled.clear();
		ticksToNext = Math.max(20, cfg.eventIntervalSeconds * 20);
		lastShownSecond = Integer.MIN_VALUE;
		overlayHidden = true;
		flashTicks = 0;
		flashText = "";
	}

	public static void start(MinecraftServer server, ModConfig cfg) {
		cfg.eventTimerEnabled = true;
		cfg.save();
		reset(cfg);
		if (cfg.eventVotingEnabled) {
			broadcast(server, "§6[Random Event]§r события §aзапущены§r (режим: голосование): каждый опрос через §e"
					+ ItemTimerManager.describeInterval(cfg.eventIntervalSeconds) + "§r, первый — через §e"
					+ ItemTimerManager.formatTime(secondsToNextVote()) + "§r.");
		} else {
			broadcast(server, "§6[Random Event]§r события §aзапущены§r (режим: случайные события, без голосования): "
					+ "раз в §e" + ItemTimerManager.describeInterval(cfg.eventIntervalSeconds)
					+ "§r само случается одно из §e" + EventDefs.all().size() + "§r событий. Первое — через §e"
					+ ItemTimerManager.formatTime(secondsToNextVote()) + "§r.");
		}
	}

	public static void stop(MinecraftServer server, ModConfig cfg) {
		cfg.eventTimerEnabled = false;
		cfg.save();
		boolean wasVoting = active;
		active = false;
		votes.clear();
		options = new ArrayList<>();
		scheduled.clear();
		flashTicks = 0;
		clearActionBar(server);
		OverlayServer.hide(server);
		broadcast(server, "§6[Random Event]§r события §cостановлены§r"
				+ (wasVoting ? " (текущее голосование отменено)" : "") + ".");
	}

	public static void setVoting(MinecraftServer server, ModConfig cfg, boolean voting) {
		cfg.eventVotingEnabled = voting;
		cfg.save();
		reset(cfg);
		broadcast(server, "§6[Random Event]§r режим: §e" + (voting
				? "голосование (игроки выбирают из 4 вариантов)"
				: "случайные события (без голосования)") + "§r.");
	}

	// ------------------------------------------------------------------
	//  Тик
	// ------------------------------------------------------------------

	public static void tick(ServerPlayerEntity anyPlayer, ModConfig cfg) {
		MinecraftServer server = anyPlayer.getServer();
		if (server == null) {
			return;
		}
		int time = server.getTicks();
		if (time == lastTick) {
			return;
		}
		lastTick = time;

		runScheduled(time);

		if (flashTicks > 0) {
			flashTicks--;
		}

		overlayTick(server, cfg);

		if (cfg.eventVotingEnabled) {
			if (active) {
				tickVote(server, cfg);
				return;
			}
			if (!cfg.eventTimerEnabled) {
				return;
			}
			if (--ticksToNext <= 0) {
				startVote(server, cfg);
			}
			return;
		}

		// режим «случайные события»: тихо отсчитываем и запускаем ровно на нуле, ничего не объявляя заранее
		if (!cfg.eventTimerEnabled) {
			return;
		}
		if (--ticksToNext <= 0) {
			fireRandomNow(server, cfg);
		}
	}

	/** Выполнить отложенные задачи (их используют события вроде «инверсии управления»). */
	private static void runScheduled(int time) {
		if (scheduled.isEmpty()) {
			return;
		}
		List<Runnable> due = new ArrayList<>();
		Iterator<Scheduled> it = scheduled.iterator();
		while (it.hasNext()) {
			Scheduled s = it.next();
			if (time >= s.at) {
				due.add(s.task);
				it.remove();
			}
		}
		for (Runnable task : due) {
			task.run();
		}
	}

	/** Отложить задачу на N тиков (20 тиков = 1 секунда). */
	public static void schedule(MinecraftServer server, int delayTicks, Runnable task) {
		scheduled.add(new Scheduled(server.getTicks() + Math.max(1, delayTicks), task));
	}

	// ------------------------------------------------------------------
	//  Режим «случайные события»
	// ------------------------------------------------------------------

	/**
	 * Случайное событие прямо сейчас: выбор по весам (по умолчанию 60% плохих, 40% хороших)
	 * и мгновенное срабатывание. Никаких сообщений в чат заранее — только плашка таймера.
	 */
	public static boolean beginRandom(MinecraftServer server, ModConfig cfg) {
		List<ServerPlayerEntity> players = server.getPlayerManager().getPlayerList();
		if (players.isEmpty()) {
			ticksToNext = 20;              // никого нет — проверим ещё раз через секунду
			return false;
		}
		EventDefs.Def chosen = EventDefs.randomWeighted(server.getOverworld().random, cfg);
		if (chosen == null) {
			return false;
		}
		fire(chosen, server, cfg);
		ticksToNext = Math.max(20, cfg.eventIntervalSeconds * 20);
		return true;
	}

	/** Событие сработало: сообщение в чат, вспышка на плашке, запуск самого события. */
	private static void fire(EventDefs.Def def, MinecraftServer server, ModConfig cfg) {
		clearActionBar(server);
		broadcast(server, "§6Событие: §f" + def.name + " §7— " + def.description);
		RandomBlocks.LOGGER.info("Random event fired: {}", def.id);
		flashText = "§c§l➤ СОБЫТИЕ!  §r§f" + def.name;
		flashTicks = FLASH_TICKS;
		lastShownSecond = Integer.MIN_VALUE;
		OverlayServer.flash(server, def.name);      // показываем сразу, не дожидаясь следующей секунды
		EventDefs.run(def, server, cfg);
	}

	/** Событие вместо таймера: то, что вызывается, когда отсчёт дошёл до нуля. */
	private static void fireRandomNow(MinecraftServer server, ModConfig cfg) {
		if (!beginRandom(server, cfg)) {
			ticksToNext = 20;
		}
	}

	/** Немедленно запустить событие сейчас (команда /randomevent now и /randomevent fire). */
	public static boolean fireNow(MinecraftServer server, ModConfig cfg) {
		if (cfg.eventVotingEnabled) {
			return startVote(server, cfg);
		}
		return beginRandom(server, cfg);
	}

	// ------------------------------------------------------------------
	//  Режим «голосование»
	// ------------------------------------------------------------------

	public static boolean startVote(MinecraftServer server, ModConfig cfg) {
		List<ServerPlayerEntity> players = server.getPlayerManager().getPlayerList();
		if (players.isEmpty()) {
			ticksToNext = 20;
			return false;
		}
		options = EventDefs.randomOptions(cfg.eventOptionsCount, server.getOverworld().random, cfg);
		if (options.isEmpty()) {
			return false;
		}
		votes.clear();
		active = true;
		voteTicksLeft = Math.max(20, cfg.eventVoteDurationSeconds * 20);
		lastShownSecond = Integer.MIN_VALUE;
		announce(server, cfg);
		return true;
	}

	private static void announce(MinecraftServer server, ModConfig cfg) {
		broadcast(server, "§6§l=== ГОЛОСОВАНИЕ ===§r Напиши цифру §e1–" + options.size()
				+ "§r в чат или кликни по варианту. Время: §e" + cfg.eventVoteDurationSeconds + " сек§r.");
		for (int i = 0; i < options.size(); i++) {
			EventDefs.Def def = options.get(i);
			int number = i + 1;

			MutableText line = new LiteralText("");
			LiteralText option = new LiteralText(" §e[" + number + "]§r ");
			option.setStyle(option.getStyle()
					.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/randomevent vote " + number))
					.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
							new LiteralText("Нажми, чтобы проголосовать за «" + def.name + "»"))));
			line.append(option);
			line.append(new LiteralText(def.kind.tag + " §f" + def.name + "§r §7— " + def.description));
			broadcast(server, line);
		}
	}

	private static void tickVote(MinecraftServer server, ModConfig cfg) {
		voteTicksLeft--;
		int seconds = voteSecondsLeft();
		if (seconds != lastShownSecond) {
			lastShownSecond = seconds;
			actionBar(server, "§6Голосование: §e" + seconds + " с §7(проголосовало: " + votes.size() + ")");
		}
		if (voteTicksLeft <= 0) {
			finish(server, cfg);
		}
	}

	private static void finish(MinecraftServer server, ModConfig cfg) {
		active = false;
		clearActionBar(server);

		int size = options.size();
		int[] counts = new int[size];
		for (Integer choice : votes.values()) {
			if (choice != null && choice >= 0 && choice < size) {
				counts[choice]++;
			}
		}
		int best = 0;
		List<Integer> leaders = new ArrayList<>();
		for (int i = 0; i < size; i++) {
			if (counts[i] > best) {
				best = counts[i];
				leaders.clear();
				leaders.add(i);
			} else if (counts[i] == best && best > 0) {
				leaders.add(i);
			}
		}

		Random random = server.getOverworld().random;
		int winner;
		boolean noVotes = best == 0;
		if (noVotes) {
			winner = random.nextInt(size);
		} else {
			winner = leaders.get(random.nextInt(leaders.size()));
		}
		EventDefs.Def def = options.get(winner);

		if (noVotes) {
			broadcast(server, "§6Голосование окончено: §rникто не голосовал — случайно выбрано: §e"
					+ def.name + "§r.");
		} else if (leaders.size() > 1) {
			broadcast(server, "§6Голосование окончено: §rравенство голосов (по §f" + best
					+ "§r) — случайно выбран один из лидеров: §e" + def.name + "§r.");
		} else {
			broadcast(server, "§6Голосование окончено: §rпобедило §e" + def.name + "§r (голосов: §f" + best
					+ " §rиз §f" + votes.size() + "§r).");
		}
		RandomBlocks.LOGGER.info("Vote finished: winner={} ({}), votes={}, options={}",
				def.id, def.name, votes.size(), size);
		fire(def, server, cfg);

		options = new ArrayList<>();
		votes.clear();
		lastShownSecond = Integer.MIN_VALUE;
		ticksToNext = Math.max(20, cfg.eventIntervalSeconds * 20);
	}

	/** Разбирает сообщение чата: «1», «2)», «3.» → номер варианта; иначе -1. */
	public static int parseVote(String message) {
		if (message == null) {
			return -1;
		}
		String text = message.trim();
		while (text.endsWith(")") || text.endsWith(".") || text.endsWith("!") || text.endsWith("№")) {
			text = text.substring(0, text.length() - 1).trim();
		}
		if (text.startsWith("№")) {
			text = text.substring(1).trim();
		}
		if (text.isEmpty() || text.length() > 2) {
			return -1;
		}
		for (int i = 0; i < text.length(); i++) {
			if (!Character.isDigit(text.charAt(i))) {
				return -1;
			}
		}
		try {
			int number = Integer.parseInt(text);
			return (number >= 1 && number <= 9) ? number : -1;
		} catch (NumberFormatException e) {
			return -1;
		}
	}

	/** Голос игрока. @return true, если голос принят (и сообщение можно не пускать в чат). */
	public static boolean vote(ServerPlayerEntity player, int number) {
		if (!active || number < 1 || number > options.size()) {
			return false;
		}
		EventDefs.Def def = options.get(number - 1);
		votes.put(player.getUuid(), number - 1);
		player.sendMessage(new LiteralText("§6[Random Event]§r твой голос: §e" + number + ") " + def.name
				+ "§r §7(" + votes.size() + " из " + player.getServer().getPlayerManager().getPlayerList().size()
				+ " проголосовало)"), false);
		return true;
	}

	// ------------------------------------------------------------------
	//  Состояние (для команд)
	// ------------------------------------------------------------------

	public static boolean isActive() {
		return active;
	}

	public static int voteSecondsLeft() {
		return Math.max(0, (voteTicksLeft + 19) / 20);
	}

	public static int secondsToNextVote() {
		return Math.max(0, (ticksToNext + 19) / 20);
	}

	/** Сколько секунд осталось до момента, когда сработает следующее событие. */
	public static int secondsUntilFire() {
		return secondsToNextVote();
	}

	/**
	 * Раз в секунду отправляем клиентам состояние кастомной плашки с таймером
	 * (или команду «убрать её»). Никакого скорборда — рисует клиентская часть мода.
	 */
	private static void overlayTick(MinecraftServer server, ModConfig cfg) {
		if (server.getTicks() % 20 != 0) {
			return;
		}
		if (!cfg.eventTimerEnabled || !cfg.eventOverlayEnabled) {
			if (!overlayHidden) {
				OverlayServer.hide(server);
				overlayHidden = true;
			}
			return;
		}
		overlayHidden = false;
		if (flashTicks > 0) {
			OverlayServer.flashText(server, flashText);
			return;
		}
		if (cfg.eventVotingEnabled && active) {
			OverlayServer.vote(server, voteSecondsLeft(), cfg.eventVoteDurationSeconds, votes.size());
		} else {
			OverlayServer.timer(server, secondsUntilFire(), cfg.eventIntervalSeconds, "");
		}
	}

	public static int voteCount() {
		return votes.size();
	}

	public static List<EventDefs.Def> currentOptions() {
		return options;
	}

	// ------------------------------------------------------------------

	private static void broadcast(MinecraftServer server, String text) {
		EventDefs.broadcast(server, text);
	}

	private static void broadcast(MinecraftServer server, Text text) {
		EventDefs.broadcast(server, text);
	}

	private static void actionBar(MinecraftServer server, String text) {
		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			player.sendMessage(new LiteralText(text), true);
		}
	}

	private static void clearActionBar(MinecraftServer server) {
		actionBar(server, "");
	}
}
