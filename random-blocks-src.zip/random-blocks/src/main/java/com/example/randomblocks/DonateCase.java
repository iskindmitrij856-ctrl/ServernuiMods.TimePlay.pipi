package com.example.randomblocks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Донат-кейсы (1.13.0).
 *
 * <p>Владелец ставит любой блок (сундук, шалкер, эндер-сундук — что угодно), смотрит на него и
 * пишет {@code /dk create} — блок становится донат-кейсом. Открыть его можно только ключом:
 * у игрока без ключей кейс не откроется. Ключи выдаются командой {@code /dk give|set|remove}.</p>
 *
 * <p><b>Колесо фортуны.</b> При открытии кейса крутится колесо (полоска бегущих привилегий внизу
 * экрана) и выпадает привилегия. Шансы (размеры секторов колеса): HERO 50, TITAN 40, AVENDER 30,
 * OVERLORD 20, MAGISTER 10, IMPERATOR 5, DRAGON 1 — чем больше число, тем чаще выпадает. Если
 * выпавшая привилегия ниже той, что у игрока уже есть, остаётся самая высокая (понижения нет).</p>
 */
public final class DonateCase {

	/** Что может выпасть и с каким «весом» (шансом). */
	public static final Rank[] PRIZES = {
			Rank.HERO, Rank.TITAN, Rank.AVENDER, Rank.OVERLORD, Rank.MAGISTER, Rank.IMPERATOR, Rank.DRAGON
	};

	public static final int[] CHANCES = {70, 50, 40, 25, 15, 5, 1};

	/** Готовые кейсы: где стоят. */
	public static final class CasePoint {
		public String world = "minecraft:overworld";
		public double x;
		public double y;
		public double z;
	}

	/** Ключи игрока. */
	public static final class KeyEntry {
		public String name = "";
		public int keys;
	}

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Type CASE_TYPE = new TypeToken<LinkedHashMap<String, CasePoint>>() { }.getType();
	private static final Type KEY_TYPE = new TypeToken<LinkedHashMap<String, KeyEntry>>() { }.getType();

	private static final List<CasePoint> CASES = new ArrayList<>();
	private static final Map<UUID, KeyEntry> KEYS = new HashMap<>();

	private static final class Spin {
		ServerPlayerEntity player;
		Rank prize;
		List<Rank> frames = new ArrayList<>();
		int frame;
		int ticksLeft;
		int interval;
		/** Где стоит кейс: кейс занят, пока крутится (другие открыть не могут). */
		String caseKey = "";
		BlockPos casePos;
		/** Предмет, который «выпрыгивает» из сундука на текущем кадре. */
		net.minecraft.entity.Entity visual;
		int holdTicks;
	}

	/** Метки голограммы и предметов кейса — по ним их и находим, и убираем. */
	public static final String HOLOGRAM_TAG = "rb_dcase";
	public static final String ITEM_TAG = "rb_dcase_item";

	private static final List<Spin> SPINS = new ArrayList<>();
	private static final Random RANDOM = new Random();
	private static long lastHologramCheck;

	private DonateCase() {
	}

	private static Path casesPath() {
		return FabricLoader.getInstance().getConfigDir().resolve("randomblocks-cases.json");
	}

	private static Path keysPath() {
		return FabricLoader.getInstance().getConfigDir().resolve("randomblocks-keys.json");
	}

	// ------------------------------------------------------------------
	//  Файлы
	// ------------------------------------------------------------------

	public static synchronized void load() {
		CASES.clear();
		KEYS.clear();
		try {
			Path cases = casesPath();
			if (Files.exists(cases)) {
				try (Reader reader = Files.newBufferedReader(cases, StandardCharsets.UTF_8)) {
					Map<String, CasePoint> raw = GSON.fromJson(reader, CASE_TYPE);
					if (raw != null) {
						CASES.addAll(raw.values());
					}
				}
			}
			Path keys = keysPath();
			if (Files.exists(keys)) {
				try (Reader reader = Files.newBufferedReader(keys, StandardCharsets.UTF_8)) {
					Map<String, KeyEntry> raw = GSON.fromJson(reader, KEY_TYPE);
					if (raw != null) {
						raw.forEach((uuid, entry) -> {
							try {
								if (entry != null) {
									if (entry.name == null) {
										entry.name = "";
									}
									KEYS.put(UUID.fromString(uuid), entry);
								}
							} catch (IllegalArgumentException ignored) {
								// битая запись
							}
						});
					}
				}
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("donate case files not read: {}", t.toString());
		}
	}

	public static synchronized void save() {
		try {
			Map<String, CasePoint> raw = new LinkedHashMap<>();
			int index = 0;
			for (CasePoint point : CASES) {
				raw.put("case" + (++index), point);
			}
			try (Writer writer = Files.newBufferedWriter(casesPath(), StandardCharsets.UTF_8)) {
				GSON.toJson(raw, writer);
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("donate cases not saved: {}", t.toString());
		}
		saveKeys();
	}

	public static synchronized void saveKeys() {
		try {
			Map<String, KeyEntry> raw = new LinkedHashMap<>();
			KEYS.forEach((uuid, entry) -> raw.put(uuid.toString(), entry));
			try (Writer writer = Files.newBufferedWriter(keysPath(), StandardCharsets.UTF_8)) {
				GSON.toJson(raw, writer);
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("donate keys not saved: {}", t.toString());
		}
	}

	// ------------------------------------------------------------------
	//  Кейсы
	// ------------------------------------------------------------------

	public static String key(World world, BlockPos pos) {
		String name = world.getRegistryKey().getValue().toString();
		return name + ":" + pos.getX() + ":" + pos.getY() + ":" + pos.getZ();
	}

	public static synchronized boolean isCase(World world, BlockPos pos) {
		String wanted = key(world, pos);
		for (CasePoint point : CASES) {
			if (key(point).equals(wanted)) {
				return true;
			}
		}
		return false;
	}

	private static String key(CasePoint point) {
		return point.world + ":" + (int) point.x + ":" + (int) point.y + ":" + (int) point.z;
	}

	public static synchronized boolean addCase(World world, BlockPos pos) {
		if (isCase(world, pos)) {
			return false;
		}
		CasePoint point = new CasePoint();
		point.world = world.getRegistryKey().getValue().toString();
		point.x = pos.getX();
		point.y = pos.getY();
		point.z = pos.getZ();
		CASES.add(point);
		save();
		spawnHologram(world, pos);
		return true;
	}

	public static synchronized boolean removeCase(World world, BlockPos pos) {
		String wanted = key(world, pos);
		for (int i = 0; i < CASES.size(); i++) {
			if (key(CASES.get(i)).equals(wanted)) {
				CASES.remove(i);
				save();
				removeHologram(world, pos);
				return true;
			}
		}
		return false;
	}

	public static synchronized List<CasePoint> cases() {
		return new ArrayList<>(CASES);
	}

	// ------------------------------------------------------------------
	//  Ключи
	// ------------------------------------------------------------------

	public static synchronized int keys(UUID uuid) {
		KeyEntry entry = KEYS.get(uuid);
		return entry == null ? 0 : entry.keys;
	}

	public static synchronized void setKeys(UUID uuid, String name, int value) {
		KeyEntry entry = KEYS.computeIfAbsent(uuid, key -> new KeyEntry());
		if (name != null && !name.isEmpty()) {
			entry.name = name;
		}
		entry.keys = Math.max(0, value);
		saveKeys();
	}

	public static synchronized void addKeys(UUID uuid, String name, int delta) {
		setKeys(uuid, name, keys(uuid) + delta);
	}

	public static synchronized String nameOf(UUID uuid) {
		KeyEntry entry = KEYS.get(uuid);
		return entry == null ? "" : entry.name;
	}

	// ------------------------------------------------------------------
	//  Открытие
	// ------------------------------------------------------------------

	/** Игрок щёлкнул по кейсу: нужен ключ, потом крутится колесо. */
	public static void open(ServerPlayerEntity player, BlockPos pos) {
		String wanted = key(player.world, pos);
		synchronized (SPINS) {
			for (Spin active : SPINS) {
				if (active.player.getUuid().equals(player.getUuid())) {
					player.sendMessage(new LiteralText("§c[Донат-кейс]§r твоя прокрутка ещё идёт — подожди."), false);
					return;
				}
				if (active.caseKey.equals(wanted)) {
					player.sendMessage(new LiteralText("§c[Донат-кейс]§r этот кейс уже крутится — дождись конца прокрутки."), false);
					play(player, SoundEvents.BLOCK_CHEST_LOCKED, 0.6F, 0.6F);
					return;
				}
			}
		}
		int keys = keys(player.getUuid());
		if (keys <= 0) {
			player.sendMessage(new LiteralText("§c[Донат-кейс]§r нужен ключ! Купить/получить ключи можно у владельца."), false);
			play(player, SoundEvents.BLOCK_CHEST_LOCKED, 0.7F, 0.8F);
			return;
		}
		setKeys(player.getUuid(), player.getEntityName(), keys - 1);
		player.sendMessage(new LiteralText("§6[Донат-кейс]§r ключ использован. Осталось ключей: §e"
				+ keys(player.getUuid())), false);
		play(player, SoundEvents.BLOCK_ENDER_CHEST_OPEN, 0.8F, 1.0F);
		startSpin(player, pos);
	}

	private static Rank roll() {
		int total = 0;
		for (int chance : CHANCES) {
			total += chance;
		}
		int ticket = RANDOM.nextInt(Math.max(1, total));
		for (int i = 0; i < CHANCES.length; i++) {
			ticket -= CHANCES[i];
			if (ticket < 0) {
				return PRIZES[i];
			}
		}
		return PRIZES[0];
	}

	/** Колесо: сначала быстро, к концу всё медленнее — как настоящая рулетка. */
	private static void startSpin(ServerPlayerEntity player, BlockPos pos) {
		Spin spin = new Spin();
		spin.player = player;
		spin.prize = roll();
		spin.casePos = pos.toImmutable();
		spin.caseKey = key(player.world, pos);
		// 20 кадров по 4 интервала (2, 4, 6, 8 тиков) = ровно 100 тиков = 5 секунд.
		for (int i = 0; i < 19; i++) {
			spin.frames.add(PRIZES[RANDOM.nextInt(PRIZES.length)]);
		}
		spin.frames.add(spin.prize);
		spin.frame = 0;
		spin.interval = 2;
		spin.ticksLeft = spin.interval;
		synchronized (SPINS) {
			SPINS.add(spin);
		}
	}

	/** Тик колеса (зовётся каждый тик сервера). */
	public static void tick(MinecraftServer server) {
		// Голограммы над кейсами: проверяем раз в 5 секунд (дешёво и переживает перезапуск).
		if (System.currentTimeMillis() - lastHologramCheck > 5000L) {
			lastHologramCheck = System.currentTimeMillis();
			ensureHologram(server);
		}
		List<Spin> done = new ArrayList<>();
		synchronized (SPINS) {
			if (SPINS.isEmpty()) {
				return;
			}
			for (Spin spin : new ArrayList<>(SPINS)) {
				if (spin.holdTicks > 0) {
					if (--spin.holdTicks <= 0) {
						kill(spin.visual);
						spin.visual = null;
						done.add(spin);
					}
					continue;
				}
				if (--spin.ticksLeft > 0) {
					continue;
				}
				// Игрок вышел — колесо просто исчезает вместе с ним.
				MinecraftServer current = spin.player.getServer();
				if (current == null || current.getPlayerManager().getPlayer(spin.player.getUuid()) == null) {
					done.add(spin);
					continue;
				}
				Rank shown = spin.frames.get(spin.frame);
				spin.player.sendMessage(new LiteralText("§8[§6КОЛЕСО§8] §7» ").append(RankBadges.prefix(shown))
						.append(new LiteralText(" §7«")), true);
				// Из сундука «выпрыгивает» блок привилегии с фото-бейджем над ним.
				kill(spin.visual);
				spin.visual = popItem(spin, shown);
				play(spin.player, SoundEvents.UI_BUTTON_CLICK, 0.5F, 1.4F);
				spin.frame++;
				if (spin.frame >= spin.frames.size()) {
					finish(spin);
					spin.holdTicks = 40;              // выигрышный блок висит ещё 2 секунды
					continue;
				}
				// замедление: каждые 5 кадров интервал растёт (2 → 4 → 6 → 8)
				if (spin.frame % 5 == 0) {
					spin.interval = Math.min(8, spin.interval + 2);
				}
				spin.ticksLeft = spin.interval;
			}
			SPINS.removeAll(done);
		}
	}

	/** Блок-иконка привилегии (те же цвета, что и в /donate). */
	private static net.minecraft.item.Item icon(Rank rank) {
		switch (rank) {
			case HERO: return net.minecraft.item.Items.BLUE_SHULKER_BOX;
			case TITAN: return net.minecraft.item.Items.YELLOW_SHULKER_BOX;
			case AVENDER: return net.minecraft.item.Items.PURPLE_SHULKER_BOX;
			case OVERLORD: return net.minecraft.item.Items.GREEN_SHULKER_BOX;
			case MAGISTER: return net.minecraft.item.Items.ORANGE_SHULKER_BOX;
			case IMPERATOR: return net.minecraft.item.Items.RED_SHULKER_BOX;
			default: return net.minecraft.item.Items.MAGENTA_SHULKER_BOX;
		}
	}

	/** Блок, который вылетает из сундука: цвет привилегии и фото-бейдж в имени. */
	private static net.minecraft.entity.Entity popItem(Spin spin, Rank rank) {
		try {
			if (spin.casePos == null || spin.player.getServer() == null) {
				return null;
			}
			net.minecraft.world.World world = spin.player.world;
			net.minecraft.item.ItemStack stack = new net.minecraft.item.ItemStack(icon(rank));
			net.minecraft.text.MutableText name = RankBadges.prefix(rank);
			name.append(new net.minecraft.text.LiteralText("§f" + rank.name));
			stack.setCustomName(name);
			double x = spin.casePos.getX() + 0.5D + (RANDOM.nextDouble() - 0.5D) * 0.5D;
			double y = spin.casePos.getY() + 1.1D;
			double z = spin.casePos.getZ() + 0.5D + (RANDOM.nextDouble() - 0.5D) * 0.5D;
			net.minecraft.entity.ItemEntity item = new net.minecraft.entity.ItemEntity(world, x, y, z, stack);
			item.setPickupDelay(32767);
			item.setVelocity((RANDOM.nextDouble() - 0.5D) * 0.12D, 0.32D, (RANDOM.nextDouble() - 0.5D) * 0.12D);
			item.addScoreboardTag(ITEM_TAG);
			world.spawnEntity(item);
			return item;
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("case item failed: {}", t.toString());
			return null;
		}
	}

	private static void kill(net.minecraft.entity.Entity entity) {
		try {
			if (entity != null && !entity.removed) {
				entity.remove();
			}
		} catch (Throwable ignored) {
			// предмет уже мог исчезнуть сам
		}
	}

	/**
	 * Голограмма над кейсом: невидимая стойка для брони с именем «Донат-Кейс».
	 * Появляется при создании кейса и заново, если пропала (например, после перезапуска сервера).
	 */
	public static void ensureHologram(net.minecraft.server.MinecraftServer server) {
		for (CasePoint point : cases()) {
			try {
				net.minecraft.server.world.ServerWorld world = server.getWorld(
						net.minecraft.util.registry.RegistryKey.of(net.minecraft.util.registry.Registry.WORLD_KEY,
								new net.minecraft.util.Identifier(point.world)));
				if (world == null) {
					continue;
				}
				BlockPos pos = new BlockPos((int) Math.floor(point.x), (int) point.y, (int) Math.floor(point.z));
				net.minecraft.util.math.Box box = new net.minecraft.util.math.Box(pos).expand(2.0D);
				boolean found = !world.getEntitiesByClass(net.minecraft.entity.decoration.ArmorStandEntity.class, box,
						stand -> stand.getScoreboardTags().contains(HOLOGRAM_TAG)).isEmpty();
				if (!found) {
					spawnHologram(world, pos);
				}
			} catch (Throwable t) {
				RandomBlocks.LOGGER.warn("hologram failed: {}", t.toString());
			}
		}
	}

	private static void spawnHologram(net.minecraft.world.World world, BlockPos pos) {
		net.minecraft.entity.decoration.ArmorStandEntity stand = new net.minecraft.entity.decoration.ArmorStandEntity(
				world, pos.getX() + 0.5D, pos.getY() + 1.35D, pos.getZ() + 0.5D);
		stand.setInvisible(true);
		stand.setInvulnerable(true);
		stand.setNoGravity(true);
		stand.setCustomName(new net.minecraft.text.LiteralText("§6§lДонат-Кейс"));
		stand.setCustomNameVisible(true);
		stand.addScoreboardTag(HOLOGRAM_TAG);
		world.spawnEntity(stand);
	}

	private static void removeHologram(net.minecraft.world.World world, BlockPos pos) {
		try {
			net.minecraft.util.math.Box box = new net.minecraft.util.math.Box(pos).expand(3.0D);
			for (net.minecraft.entity.decoration.ArmorStandEntity stand : world.getEntitiesByClass(
					net.minecraft.entity.decoration.ArmorStandEntity.class, box,
					entity -> entity.getScoreboardTags().contains(HOLOGRAM_TAG))) {
				stand.remove();
			}
		} catch (Throwable ignored) {
			// нечего убирать
		}
	}

	private static void finish(Spin spin) {
		ServerPlayerEntity player = spin.player;
		Rank prize = spin.prize;
		Rank current = RankManager.rankOf(player);
		String won = prize.prefix();
		player.sendMessage(new LiteralText("§6§l[Донат-кейс]§r тебе выпало: " + won + "§r!"), false);
		if (prize.weight > current.weight) {
			RankManager.setRank(player.getUuid(), player.getEntityName(), prize);
			RankManager.applySafe(player, prize);
			player.sendMessage(new LiteralText("§aПривилегия повышена: " + current.prefix() + " §a→ " + won
					+ "§a. Поздравляем!"), false);
			play(player, SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0F, 1.0F);
			announce(player, "§6[Донат-кейс]§r §e" + player.getEntityName()
					+ "§r выкрутил привилегию " + won + "§r!");
		} else {
			player.sendMessage(new LiteralText("§7У тебя уже есть привилегия выше (" + current.prefix()
					+ "§7) — остаётся самая высокая."), false);
			play(player, SoundEvents.BLOCK_NOTE_BLOCK_BELL, 1.0F, 1.2F);
			announce(player, "§6[Донат-кейс]§r §e" + player.getEntityName()
					+ "§r выкрутил " + won + "§r, но у него уже есть привилегия выше.");
		}
		RandomBlocks.LOGGER.info("Donate case: {} won {} (was {})", player.getEntityName(),
				prize.name, current.name);
	}

	/** Сообщение о выигрыше: сам игрок уже увидел, остальным — если включено в настройках. */
	private static void announce(ServerPlayerEntity player, String message) {
		if (!RandomBlocks.getConfig().donateCaseAnnounce) {
			return;
		}
		for (ServerPlayerEntity online : player.getServer().getPlayerManager().getPlayerList()) {
			if (online != player) {
				online.sendMessage(new LiteralText(message), false);
			}
		}
	}

	private static void play(ServerPlayerEntity player, net.minecraft.sound.SoundEvent sound, float volume, float pitch) {
		try {
			player.playSound(sound, SoundCategory.PLAYERS, volume, pitch);
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("case sound failed: {}", t.toString());
		}
	}
}
