package com.example.randomblocks;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.BlockPos;

/**
 * Зона вокруг точки {@code /setspawn}: квадрат 100×100 (настраивается опцией {@code spawnZoneSize}).
 *
 * <p>Внутри зоны нельзя ломать и ставить блоки (даже в креативе) и нельзя драться —
 * урона между игроками и от мобов там нет (никаких эффектов слабости, как просил владелец).
 * Кроме того, в зоне нельзя умереть: смерть отменяется, и игрок возвращается на спавн.</p>
 *
 * <p>OWNER здесь исключение — ему в зоне можно всё, как и во всём остальном моде.</p>
 */
public final class SpawnZone {

	/** Кому нужно вернуться на спавн на следующем тике (см. {@link #scheduleSendToSpawn}). */
	private static final java.util.Set<java.util.UUID> PENDING = new java.util.HashSet<>();

	private SpawnZone() {
	}

	/**
	 * Отложить возврат на спавн на следующий тик.
	 *
	 * <p>Внутри {@code onDeath} телепорт не срабатывает — клиент откатывает его вместе с
	 * «смертью», поэтому смерть отменяется сразу, а возврат делается на следующем тике.</p>
	 */
	public static void scheduleSendToSpawn(ServerPlayerEntity player) {
		PENDING.add(player.getUuid());
	}

	/** Каждый тик игрока: выполняет отложенный возврат на спавн. */
	public static void tick(ServerPlayerEntity player) {
		if (PENDING.remove(player.getUuid())) {
			sendToSpawn(player);
			player.sendMessage(new net.minecraft.text.LiteralText(
					"§6[Привилегии]§r ты возвращён на спавн — в зоне спавна смерть не работает."), false);
		}
	}

	/** Сколько блоков от спавна считается зоной (половина стороны квадрата). */
	public static double half() {
		int size = RandomBlocks.getConfig().spawnZoneSize;
		if (size < 2) {
			size = 2;
		}
		return size / 2.0D;
	}

	/** Включена ли защита (и поставлен ли вообще спавн). */
	public static boolean active() {
		return RandomBlocks.getConfig().spawnZoneEnabled && TeleportPoints.spawn() != null;
	}

	/** Координаты точки в этом мире? */
	public static boolean inSpawnWorld(ServerPlayerEntity player) {
		TeleportPoints.Point spawn = TeleportPoints.spawn();
		if (spawn == null || player == null) {
			return false;
		}
		String world = player.getServerWorld().getRegistryKey().getValue().toString();
		return world.equals(spawn.world);
	}

	/** Игрок внутри зоны? */
	public static boolean inside(ServerPlayerEntity player) {
		if (!active() || player == null || !inSpawnWorld(player)) {
			return false;
		}
		TeleportPoints.Point spawn = TeleportPoints.spawn();
		return inside(spawn, player.getX(), player.getZ());
	}

	/** Точка (например, ломаемый блок) внутри зоны? */
	public static boolean inside(ServerPlayerEntity player, BlockPos pos) {
		if (!active() || player == null || pos == null || !inSpawnWorld(player)) {
			return false;
		}
		TeleportPoints.Point spawn = TeleportPoints.spawn();
		return inside(spawn, pos.getX() + 0.5D, pos.getZ() + 0.5D);
	}

	private static boolean inside(TeleportPoints.Point spawn, double x, double z) {
		double half = half();
		return Math.abs(x - spawn.x) <= half && Math.abs(z - spawn.z) <= half;
	}

	/**
	 * Нужно ли защищать этого игрока: он внутри зоны и он не OWNER.
	 * (OWNER — «можно там делать что угодно».)
	 */
	public static boolean protect(ServerPlayerEntity player) {
		return inside(player) && !Permissions.isOwner(player);
	}

	/** То же, но для конкретной точки (блок, который пытаются сломать или поставить). */
	public static boolean protect(ServerPlayerEntity player, BlockPos pos) {
		return inside(player, pos) && !Permissions.isOwner(player);
	}

	/** Вернуть игрока на спавн (после отменённой смерти или по просьбе). */
	public static void sendToSpawn(ServerPlayerEntity player) {
		TeleportPoints.Point spawn = TeleportPoints.spawn();
		if (spawn == null) {
			return;
		}
		MinecraftServer server = player.getServer();
		ServerWorld world = TeleportPoints.worldOf(server, spawn);
		if (world == null) {
			return;
		}
		player.teleport(world, spawn.x, spawn.y, spawn.z, player.yaw, player.pitch);
		player.stopRiding();
	}

	public static void tell(ServerPlayerEntity player, String message) {
		player.sendMessage(new LiteralText(message), false);
	}

	/** Половина стороны квадрата для сообщений: «в радиусе 50 блоков во все стороны». */
	public static String describe() {
		return ((int) half()) + "×" + ((int) half()) + " блоков";
	}
}
