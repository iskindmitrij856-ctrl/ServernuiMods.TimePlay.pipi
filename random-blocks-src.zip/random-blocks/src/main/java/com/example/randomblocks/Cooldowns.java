package com.example.randomblocks;

import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Перезарядки команд (как просил владелец: /feed — раз в 2 минуты, /heal — раз в минуту и так далее).
 *
 * <p>У OWNER перезарядок нет вообще. У гранаты «/grant» своя, долгая перезарядка — она хранится
 * прямо в файле привилегий (см. {@link RankManager}), чтобы 5 дней считались и после перезапуска.</p>
 */
public final class Cooldowns {

	/** Возможность → сколько секунд ждать. */
	private static final Map<String, Integer> SECONDS = new HashMap<>();

	private static final Map<String, Long> LAST = new HashMap<>();

	static {
		SECONDS.put(Permissions.FEED, 120);
		SECONDS.put(Permissions.RTP_FAR, 60);
		SECONDS.put(Permissions.EXTINGUISH, 60);
		SECONDS.put(Permissions.HEAL, 60);
		SECONDS.put(Permissions.BROADCAST, 300);
		SECONDS.put(Permissions.LIGHTNING, 300);
		SECONDS.put(Permissions.RTP_NEAR, 180);
	}

	private Cooldowns() {
	}

	/** Сколько секунд ещё ждать (0 — можно). */
	public static long remaining(ServerPlayerEntity player, String node) {
		if (Permissions.isOwner(player)) {
			return 0;                                   // OWNER — без перезарядок
		}
		Integer limit = SECONDS.get(node);
		if (limit == null) {
			return 0;
		}
		Long last = LAST.get(player.getUuid() + "|" + node);
		if (last == null) {
			return 0;
		}
		long passed = (System.currentTimeMillis() - last) / 1000L;
		return Math.max(0, limit - passed);
	}

	/** Подсказка «(следующий раз — через N)»; у OWNER перезарядок нет — пустая строка. */
	public static String note(ServerPlayerEntity player, String node) {
		Integer limit = SECONDS.get(node);
		if (limit == null || Permissions.isOwner(player)) {
			return "";
		}
		return "§7 (следующий раз — через " + format(limit) + ").";
	}

	public static boolean ready(ServerPlayerEntity player, String node) {
		return remaining(player, node) <= 0;
	}

	public static void mark(ServerPlayerEntity player, String node) {
		LAST.put(player.getUuid() + "|" + node, System.currentTimeMillis());
	}

	public static void forget(UUID uuid) {
		LAST.keySet().removeIf(key -> key.startsWith(uuid.toString()));
	}

	/** «1 мин 05 с» — чтобы было понятно, сколько ждать. */
	public static String format(long seconds) {
		if (seconds < 60) {
			return seconds + " с";
		}
		long minutes = seconds / 60;
		long rest = seconds % 60;
		if (minutes < 60) {
			return rest == 0 ? minutes + " мин" : minutes + " мин " + rest + " с";
		}
		long hours = minutes / 60;
		long minRest = minutes % 60;
		if (hours < 24) {
			return minRest == 0 ? hours + " ч" : hours + " ч " + minRest + " мин";
		}
		long days = hours / 24;
		long hourRest = hours % 24;
		return hourRest == 0 ? days + " дн" : days + " дн " + hourRest + " ч";
	}
}
