package com.example.randomblocks;

import net.minecraft.util.Formatting;

/**
 * Привилегии (ранги) сервера — от обычного игрока до владельца.
 *
 * <p>Порядок объявления = иерархия: чем выше {@link #weight}, тем выше игрок в табе,
 * тем «старше» его привилегия. Префикс показывается в чате, в табе и над головой
 * в виде «ПРИВИЛЕГИЯ Ник».</p>
 *
 * <p>Цвета подобраны так, как просил владелец сервера: PLAYER — серая, HERO — синяя,
 * TITAN — жёлтая, AVENDER — фиолетовая, OVERLORD — зелёная, MAGISTER — оранжевая,
 * IMPERATOR — красная, DRAGON — розовая, OWNER — тоже красная, но тёмная (чтобы отличать
 * от IMPERATOR), и все — жирным.</p>
 */
public enum Rank {

	/** Привилегия по умолчанию — есть у всех. */
	PLAYER(0, "PLAYER", "7", Formatting.GRAY, 1),
	HERO(1, "HERO", "9", Formatting.BLUE, 2),
	TITAN(2, "TITAN", "e", Formatting.YELLOW, 4),
	AVENDER(3, "AVENDER", "5", Formatting.DARK_PURPLE, 6),
	OVERLORD(4, "OVERLORD", "a", Formatting.GREEN, 12),
	MAGISTER(5, "MAGISTER", "6", Formatting.GOLD, 32),
	IMPERATOR(6, "IMPERATOR", "c", Formatting.RED, 48),
	DRAGON(7, "DRAGON", "d", Formatting.LIGHT_PURPLE, 100),
	/** Владелец: иерархия «∞» — выше всех, и точек дома тоже сколько угодно. */
	OWNER(100, "OWNER", "4", Formatting.DARK_RED, Integer.MAX_VALUE);

	/** Позиция в иерархии: больше — выше. */
	public final int weight;
	/** Как называется привилегия в командах и в префиксе. */
	public final String name;
	/** Цвет префикса и ника рядом с ним. */
	public final Formatting color;
	/** Код цвета для строк вида «§9§lHERO» (в 1.16.5 у Formatting нет геттера кода). */
	public final String code;
	/** Сколько точек дома можно поставить с этой привилегией (Integer.MAX_VALUE — без предела). */
	public final int homes;

	Rank(int weight, String name, String code, Formatting color, int homes) {
		this.weight = weight;
		this.name = name;
		this.code = code;
		this.color = color;
		this.homes = homes;
	}

	/** «§9§lHERO» — префикс для чата, таба и таблички над головой. */
	public String prefix() {
		return "§" + code + "§l" + name;
	}

	/** «§9§lHERO §fНик» — привилегия цветная, а сам ник всегда обычный, белый. */
	public String decorate(String playerName) {
		return prefix() + " §f" + playerName;
	}

	/** Лимит точек дома для сообщений: у OWNER — «∞». */
	public String homesText() {
		return homes == Integer.MAX_VALUE ? "∞" : Integer.toString(homes);
	}

	/** Название без цветов — по нему клиент сортирует таб. */
	public String plain() {
		return name;
	}

	/** Следующая привилегия вверх (PLAYER → HERO → … → OWNER), OWNER остаётся собой. */
	public Rank next() {
		Rank best = this;
		for (Rank rank : values()) {
			if (rank.weight > best.weight) {
				best = rank;
			}
		}
		if (best == this) {
			return this;
		}
		Rank candidate = null;
		for (Rank rank : values()) {
			if (rank.weight > this.weight && (candidate == null || rank.weight < candidate.weight)) {
				candidate = rank;
			}
		}
		return candidate == null ? this : candidate;
	}

	/**
	 * Разбор названия привилегии из команды: «hero», «HERO», «1» и даже «∞» (owner).
	 * Возвращает null, если такого названия нет.
	 */
	public static Rank byName(String input) {
		if (input == null) {
			return null;
		}
		String value = input.trim().toUpperCase(java.util.Locale.ROOT);
		if (value.equals("∞") || value.equals("INF") || value.equals("INFINITY")) {
			return OWNER;
		}
		for (Rank rank : values()) {
			if (rank.name.equals(value)) {
				return rank;
			}
		}
		try {
			int number = Integer.parseInt(value);
			for (Rank rank : values()) {
				if (rank.weight == number) {
					return rank;
				}
			}
		} catch (NumberFormatException ignored) {
			// не число — значит просто неизвестное название
		}
		return null;
	}

	/** Первое слово из текста таба («HERO Ник» → HERO); если не ранг — PLAYER. */
	public static Rank byTabName(String displayText) {
		if (displayText == null || displayText.isEmpty()) {
			return PLAYER;
		}
		int space = displayText.indexOf(' ');
		String first = (space < 0 ? displayText : displayText.substring(0, space)).trim();
		Rank rank = byName(first);
		return rank == null ? PLAYER : rank;
	}
}
