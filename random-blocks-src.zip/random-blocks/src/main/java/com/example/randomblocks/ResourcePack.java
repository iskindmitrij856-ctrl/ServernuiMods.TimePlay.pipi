package com.example.randomblocks;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.codec.http.HttpUtil;
import io.netty.handler.codec.http.HttpVersion;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.packet.s2c.play.ResourcePackSendS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Ресурспак с фото-бейджами привилегий (1.13.0).
 *
 * <p>Сам мод — это ресурспак: клиенты, у которых он стоит, видят фото-бейджи. А друзьям, у которых
 * мода нет, сервер отдаёт маленький ресурспак из одного шрифта — при входе игра сама предложит его
 * принять, и фото привилегий появится у всех. Пак собирается прямо из файлов мода, поэтому
 * обновлять его руками не нужно: поменяли картинки — пак пересобрался при запуске сервера.</p>
 *
 * <p>Как это работает: мод открывает крошечный HTTP-сервер (пакет по умолчанию на порту сервера
 * или на следующем свободном) и в {@code onPlayerConnect} отправляет игроку обычный ванильный
 * запрос на скачивание. Настройки — {@code resourcePackEnabled}, {@code resourcePackHost},
 * {@code resourcePackUrl}, {@code resourcePackServePort} в config/randomblocks.json.</p>
 */
public final class ResourcePack {

	public static final String NAME = "randomblocks-badges.zip";

	private static byte[] bytes;
	private static String sha1 = "";
	private static int boundPort;
	private static Channel channel;
	private static NioEventLoopGroup bossGroup;
	private static boolean warned;

	private ResourcePack() {
	}

	/** Собрать пак и поднять HTTP-раздачу (вызывается один раз при старте сервера). */
	public static synchronized void setup() {
		ModConfig config = RandomBlocks.getConfig();
		if (config == null || !config.resourcePackEnabled) {
			return;
		}
		try {
			bytes = build();
			sha1 = sha1(bytes);
			startServer(config);
			RandomBlocks.LOGGER.info("Resource pack ready: {} ({} bytes, sha1={})",
					url(), bytes.length, sha1.substring(0, 8) + "…");
		} catch (Throwable t) {
			warned = true;
			RandomBlocks.LOGGER.warn("Resource pack is unavailable: {}", t.toString());
		}
	}

	/** Собрать zip: pack.mcmeta + шрифт бейджей прямо из jar мода. */
	private static byte[] build() throws Exception {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		try (ZipOutputStream zip = new ZipOutputStream(out)) {
			zip.putNextEntry(new ZipEntry("pack.mcmeta"));
			zip.write(("{\"pack\":{\"pack_format\":6,\"description\":\"Random Blocks: фото привилегий\"}}")
					.getBytes(StandardCharsets.UTF_8));
			zip.closeEntry();
			for (String resource : new String[]{
					"assets/randomblocks/font/badges.json",
					"assets/randomblocks/textures/font/rank_badges.png",
					"assets/randomblocks/rank_badges.txt"}) {
				Path path = FabricLoader.getInstance().getModContainer(RandomBlocks.MOD_ID)
						.flatMap(container -> container.findPath(resource))
						.orElse(null);
				if (path == null) {
					continue;
				}
				zip.putNextEntry(new ZipEntry(resource));
				zip.write(Files.readAllBytes(path));
				zip.closeEntry();
			}
		}
		return out.toByteArray();
	}

	private static String sha1(byte[] data) throws Exception {
		MessageDigest digest = MessageDigest.getInstance("SHA-1");
		byte[] hash = digest.digest(data);
		StringBuilder builder = new StringBuilder();
		for (byte value : hash) {
			builder.append(String.format(Locale.ROOT, "%02x", value));
		}
		return builder.toString();
	}

	/** Порт, на котором отдаём пак. Если сервер занимает свой порт — берём следующий свободный. */
	private static void startServer(ModConfig config) {
		if (channel != null) {
			return;
		}
		int first = config.resourcePackServePort > 0 ? config.resourcePackServePort : serverPort();
		Exception last = null;
		for (int port = first; port < first + 10; port++) {
			try {
				bossGroup = new NioEventLoopGroup(1);
				ServerBootstrap bootstrap = new ServerBootstrap()
						.group(bossGroup)
						.channel(NioServerSocketChannel.class)
						.childHandler(new ChannelInitializer<SocketChannel>() {
							@Override
							protected void initChannel(SocketChannel socket) {
								socket.pipeline().addLast(new HttpServerCodec());
								socket.pipeline().addLast(new HttpObjectAggregator(8192));
								socket.pipeline().addLast(new Handler());
							}
						});
				channel = bootstrap.bind(port).sync().channel();
				boundPort = port;
				return;
			} catch (Exception e) {
				last = e;
				stopServer();
			}
		}
		throw new IllegalStateException("no free port for the resource pack: "
				+ (last == null ? "?" : last.getMessage()));
	}

	private static void stopServer() {
		try {
			if (channel != null) {
				channel.close();
			}
		} catch (Throwable ignored) {
			// закрываем как получится
		}
		channel = null;
		if (bossGroup != null) {
			try {
				bossGroup.shutdownGracefully();
			} catch (Throwable ignored) {
				// пусто
			}
			bossGroup = null;
		}
	}

	/** Порт из server.properties (там же, где стоит сервер). */
	private static int serverPort() {
		try {
			Path path = FabricLoader.getInstance().getGameDir().resolve("server.properties");
			if (Files.exists(path)) {
				for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
					if (line.startsWith("server-port=")) {
						return Integer.parseInt(line.substring("server-port=".length()).trim());
					}
				}
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("Could not read server-port: {}", t.toString());
		}
		return 25565;
	}

	/** Ссылка на пак, которую получают игроки. */
	public static String url() {
		ModConfig config = RandomBlocks.getConfig();
		if (config != null && config.resourcePackUrl != null && !config.resourcePackUrl.trim().isEmpty()) {
			return config.resourcePackUrl.trim();
		}
		String host = config != null && config.resourcePackHost != null && !config.resourcePackHost.trim().isEmpty()
				? config.resourcePackHost.trim()
				: localAddress();
		return "http://" + host + ":" + boundPort + "/" + NAME;
	}

	/**
	 * Адрес, по которому игру видят друзья: первый «настоящий» адрес этого компьютера в домашней
	 * сети (192.168.x.x и подобные). Именно по нему друзья и подключаются к серверу — значит, по
	 * нему же они смогут скачать и ресурспак. Если адрес не нашёлся, остаётся 127.0.0.1: пак
	 * скачает только тот, кто играет на этом же компьютере.
	 */
	private static String localAddress() {
		String fallback = null;
		try {
			for (java.net.NetworkInterface network : java.util.Collections.list(
					java.net.NetworkInterface.getNetworkInterfaces())) {
				if (!network.isUp() || network.isLoopback() || network.isVirtual()) {
					continue;
				}
				for (java.net.InetAddress address : java.util.Collections.list(network.getInetAddresses())) {
					if (address instanceof java.net.Inet4Address && !address.isLoopbackAddress()
							&& address.isSiteLocalAddress()) {
						return address.getHostAddress();
					}
				}
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("Could not detect the local address: {}", t.toString());
		}
		if (fallback != null) {
			return fallback;
		}
		return "127.0.0.1";
	}

	/** Отправить игроку предложение скачать пак (ванильный механизм, работает без мода у клиента). */
	public static void send(ServerPlayerEntity player) {
		ModConfig config = RandomBlocks.getConfig();
		if (config == null || !config.resourcePackEnabled || bytes == null) {
			if (!warned && config != null && config.resourcePackEnabled) {
				RandomBlocks.LOGGER.warn("Resource pack was not sent to {}: it is not built", player.getEntityName());
			}
			return;
		}
		try {
			player.networkHandler.sendPacket(new ResourcePackSendS2CPacket(url(), sha1));
			RandomBlocks.LOGGER.info("Resource pack offered to {} ({}): {}", player.getEntityName(),
					config.resourcePackRequired ? "обязательный" : "по желанию", url());
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("Resource pack not sent to {}: {}", player.getEntityName(), t.toString());
		}
	}

	/** Раздача файла: отдаём только наш zip, всё остальное — 404. */
	private static final class Handler extends SimpleChannelInboundHandler<FullHttpRequest> {

		@Override
		protected void channelRead0(ChannelHandlerContext context, FullHttpRequest request) {
			boolean wanted = request.method() == HttpMethod.GET
					&& request.uri() != null
					&& request.uri().split("\\?")[0].endsWith(NAME);
			FullHttpResponse response;
			if (wanted) {
				response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK,
						Unpooled.wrappedBuffer(bytes));
				response.headers().set(HttpHeaderNames.CONTENT_TYPE, "application/zip");
				response.headers().set(HttpHeaderNames.CONTENT_LENGTH, bytes.length);
				RandomBlocks.LOGGER.info("Resource pack downloaded by {}", context.channel().remoteAddress());
			} else {
				byte[] text = "Random Blocks resource pack".getBytes(StandardCharsets.UTF_8);
				response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.NOT_FOUND,
						Unpooled.wrappedBuffer(text));
				response.headers().set(HttpHeaderNames.CONTENT_TYPE, "text/plain; charset=utf-8");
				response.headers().set(HttpHeaderNames.CONTENT_LENGTH, text.length);
			}
			HttpUtil.setKeepAlive(response, false);
			context.writeAndFlush(response).addListener(future -> context.close());
		}

		@Override
		public void exceptionCaught(ChannelHandlerContext context, Throwable cause) {
			context.close();
		}
	}

	@SuppressWarnings("unused")
	private static void copy(InputStream in, OutputStream out) {
		// заготовка на будущее: если понадобится стримить файл с диска
	}
}
