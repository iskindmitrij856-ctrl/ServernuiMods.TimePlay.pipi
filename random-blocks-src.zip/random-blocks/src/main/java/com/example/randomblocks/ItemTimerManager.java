package com.example.randomblocks;

import net.minecraft.server.MinecraftServer;
import java.util.Locale;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Таймер выдачи случайных предметов.
 *
 * Пока таймер запущен, у игроков с модом внизу экрана (прямо над хотбаром) висит кастомная
 * плашка «Случайные предметы | Следующий через 4:59» с полоской прогресса и строчкой
 * «прошлый: …». Тем, у кого мода нет, мод по-прежнему пишет отсчёт в строку над инвентарём.
 * Когда время выходит — каждому игроку выдаётся случайный предмет, в чат приходит сообщение,
 * и отсчёт начинается заново.
 *
 * Тикает из тика игрока, но с дедупликацией по времени мира: за один тик сервера счётчик
 * уменьшается ровно один раз, сколько бы игроков ни было онлайн.
 */
public final class ItemTimerManager {

	private static int lastTickTime = Integer.MIN_VALUE;
	private static int ticksLeft = 0;
	private static int lastShownSecond = Integer.MIN_VALUE;

	private ItemTimerManager() {
	}

	/** Запустить таймер (состояние сохраняется в конфиг). */
	public static void start(MinecraftServer server, ModConfig cfg) {
		cfg.itemTimerEnabled = true;
		cfg.save();
		reset(cfg);
		tick(server, cfg);
	}

	/** Остановить таймер и убрать отсчёт из интерфейса. */
	public static void stop(MinecraftServer server, ModConfig cfg) {
		cfg.itemTimerEnabled = false;
		cfg.save();
		ticksLeft = 0;
		lastShownSecond = Integer.MIN_VALUE;
		OverlayServer.hideItemTimer(server);
	}

	/** Начать отсчёт заново (после смены интервала, /reload или запуска таймера). */
	public static void reset(ModConfig cfg) {
		ticksLeft = Math.max(20, cfg.itemIntervalSeconds * 20);
		lastShownSecond = Integer.MIN_VALUE;
	}

	public static boolean isEnabled(ModConfig cfg) {
		return cfg.itemTimerEnabled;
	}

	public static int secondsLeft() {
		return Math.max(0, (ticksLeft + 19) / 20);
	}

	/** Один тик сервера (вызывается из тика игрока, дедупликация по счётчику тиков сервера). */
	public static void tick(ServerPlayerEntity player, ModConfig cfg) {
		if (!cfg.itemTimerEnabled) {
			return;
		}
		MinecraftServer server = player.getServer();
		if (server == null) {
			return;
		}
		int time = server.getTicks();
		if (time == lastTickTime) {
			return;
		}
		lastTickTime = time;
		tick(server, cfg);
	}

	private static void tick(MinecraftServer server, ModConfig cfg) {
		if (ticksLeft <= 0) {
			reset(cfg);
		}
		ticksLeft--;
		int seconds = secondsLeft();
		if (seconds != lastShownSecond) {
			lastShownSecond = seconds;
			showTimer(server, seconds, cfg);
		}
		if (ticksLeft <= 0) {
			RandomItems.giveToAll(server, cfg);
			reset(cfg);
			lastShownSecond = Integer.MIN_VALUE;
			if (cfg.debugLog) {
				RandomBlocks.LOGGER.info("Item timer: handed out items, next in {}s", cfg.itemIntervalSeconds);
			}
		}
	}

	/**
	 * Показать отсчёт: владельцам мода — красивая плашка над хотбаром (её рисует клиент),
	 * остальным — строка над инвентарём. Что кому, решает сам OverlayServer.
	 */
	private static void showTimer(MinecraftServer server, int seconds, ModConfig cfg) {
		if (!cfg.itemOverlayEnabled) {
			OverlayServer.hideItemTimer(server);
			return;
		}
		OverlayServer.itemTimer(server, seconds, cfg.itemIntervalSeconds, RandomItems.lastGiven());
	}

	public static String formatTime(int totalSeconds) {
		int hours = totalSeconds / 3600;
		int minutes = (totalSeconds % 3600) / 60;
		int seconds = totalSeconds % 60;
		if (hours > 0) {
			return hours + ":" + (minutes < 10 ? "0" : "") + minutes + ":" + (seconds < 10 ? "0" : "") + seconds;
		}
		return minutes + ":" + (seconds < 10 ? "0" : "") + seconds;
	}

	/** «30 с», «10 мин», «1 ч 30 мин» — чтобы в чате было понятно человеческим языком. */
	public static String describeInterval(int totalSeconds) {
		int hours = totalSeconds / 3600;
		int minutes = (totalSeconds % 3600) / 60;
		int seconds = totalSeconds % 60;
		StringBuilder sb = new StringBuilder();
		if (hours > 0) {
			sb.append(hours).append(" ч ");
		}
		if (minutes > 0) {
			sb.append(minutes).append(" мин ");
		}
		if (seconds > 0 || sb.length() == 0) {
			sb.append(seconds).append(" с");
		}
		return sb.toString().trim();
	}

	/**
	 * Разбирает время из строки:
	 * «10s» или «10с» — секунды, «10m» или «10м» — минуты, «10h» или «10ч» — часы,
	 * «1h30m» — составное, «5» без буквы — минуты (как было раньше), «1.5m» — полторы минуты.
	 *
	 * @return длительность в секундах или -1, если строку не понять.
	 */
	public static int parseDurationSeconds(String raw) {
		if (raw == null) {
			return -1;
		}
		String text = raw.trim().toLowerCase(Locale.ROOT).replace(" ", "");
		if (text.isEmpty()) {
			return -1;
		}
		double totalSeconds = 0.0D;
		int index = 0;
		boolean anyComponent = false;

		while (index < text.length()) {
			int numberStart = index;
			while (index < text.length() && (Character.isDigit(text.charAt(index))
					|| text.charAt(index) == '.' || text.charAt(index) == ',')) {
				index++;
			}
			if (numberStart == index) {
				return -1;                      // тут должно было быть число
			}
			double value;
			try {
				value = Double.parseDouble(text.substring(numberStart, index).replace(',', '.'));
			} catch (NumberFormatException e) {
				return -1;
			}

			int unitStart = index;
			while (index < text.length() && Character.isLetter(text.charAt(index))) {
				index++;
			}
			String unit = text.substring(unitStart, index);
			double multiplier;
			if (unit.isEmpty()) {
				// без буквы: одиночное число — это минуты (как было), а «1h30» — секунды
				multiplier = anyComponent ? 1.0D : 60.0D;
			} else if (unit.equals("s") || unit.equals("sec") || unit.equals("secs")
					|| unit.equals("second") || unit.equals("seconds")
					|| unit.equals("с") || unit.equals("сек") || unit.equals("секунд") || unit.equals("секунды")) {
				multiplier = 1.0D;
			} else if (unit.equals("m") || unit.equals("min") || unit.equals("mins")
					|| unit.equals("minute") || unit.equals("minutes")
					|| unit.equals("м") || unit.equals("мин") || unit.equals("минут") || unit.equals("минуты")) {
				multiplier = 60.0D;
			} else if (unit.equals("h") || unit.equals("hour") || unit.equals("hours")
					|| unit.equals("ч") || unit.equals("час") || unit.equals("часа") || unit.equals("часов")) {
				multiplier = 3600.0D;
			} else {
				return -1;                      // неизвестная единица измерения
			}
			totalSeconds += value * multiplier;
			anyComponent = true;
		}

		if (!anyComponent || totalSeconds <= 0.0D) {
			return -1;
		}
		return (int) Math.max(1L, Math.round(totalSeconds));
	}
}
