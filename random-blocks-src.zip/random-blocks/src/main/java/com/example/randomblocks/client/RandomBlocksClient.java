package com.example.randomblocks.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/**
 * Все кастомные меню мода на экране — клиентская половина.
 *
 * <ul>
 *     <li><b>сверху по центру, одним блоком</b> — два таймера уменьшенным шрифтом:
 *         строкой выше таймер событий («До события: 12 с») или отсчёт голосования,
 *         строкой ниже — таймер выдачи предметов («предмет через 4:59»);</li>
 *     <li>на пару секунд вместо верхней строки показывается вспышка «СОБЫТИЕ! <название>».</li>
 * </ul>
 *
 * <p>Раньше таймер событий рисовался большой плашкой с полоской, а таймер предметов — отдельной
 * строкой над хотбаром. С 1.12.0 у них один вид и одно место: обычные компактные строки друг под
 * другом (как просил владелец сервера).</p>
 *
 * Никакого ванильного скорборда: всё рисуется нашим кодом, поэтому вид и позиция — наши.
 * Если на сервере мода нет, плашки просто никогда не появляются.
 */
@Environment(EnvType.CLIENT)
public class RandomBlocksClient implements ClientModInitializer {

	private static final Identifier CHANNEL = new Identifier("randomblocks", "timer");

	/** 0 — скрыто, 1 — таймер события, 2 — голосование, 3 — вспышка события. */
	private static int topKind;
	private static String topText = "";
	private static String topSub = "";
	private static float topPercent;
	private static long topStamp;

	/** 5 — таймер предметов (внизу), 6 — скрыть нижнюю плашку. */
	private static int bottomKind;
	private static String bottomText = "";
	private static String bottomSub = "";
	private static float bottomPercent;
	private static long bottomStamp;

	/** Сколько миллисекунд держать плашку, если сервер перестал присылать обновления. */
	private static final long TTL_MS = 3500L;

	@Override
	public void onInitializeClient() {
		ClientPlayNetworking.registerGlobalReceiver(CHANNEL, (client, handler, buf, sender) -> {
			// Читаем пакет сразу, на сетевом потоке, а в игру переключаемся через client.execute.
			int newKind = buf.readInt();
			String newText = buf.readString(262144);
			String newSub = buf.readString(262144);
			float newPercent = buf.readFloat();
			client.execute(() -> apply(client, newKind, newText, newSub, newPercent));
		});
		HudRenderCallback.EVENT.register((matrices, tickDelta) -> render(matrices));
	}

	private static void apply(MinecraftClient client, int kind, String text, String sub, float percent) {
		String safeText = text == null ? "" : text;
		String safeSub = sub == null ? "" : sub;
		long now = System.currentTimeMillis();
		switch (kind) {
			case 0:                                 // убрать обе плашки
				topKind = 0;
				topText = "";
				bottomKind = 0;
				bottomText = "";
				break;
			case 1:
			case 2:
			case 3:
				topKind = kind;
				topText = safeText;
				topSub = safeSub;
				topPercent = percent;
				topStamp = now;
				break;
			case 5:
				bottomKind = kind;
				bottomText = safeText;
				bottomSub = safeSub;
				bottomPercent = percent;
				bottomStamp = now;
				break;
			case 6:                                 // убрать только нижнюю
				bottomKind = 0;
				bottomText = "";
				break;
			default:
				break;
		}
	}

	private static void render(MatrixStack matrices) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client == null || client.player == null || client.options == null || client.options.hudHidden) {
			return;
		}
		long now = System.currentTimeMillis();
		boolean eventsFresh = topKind != 0 && !topText.isEmpty() && now - topStamp <= TTL_MS;
		boolean itemsFresh = bottomKind != 0 && !bottomText.isEmpty() && now - bottomStamp <= TTL_MS;

		// Оба таймера — в одном месте, друг под другом: события выше, предметы ниже.
		float y = 6.0F;
		if (eventsFresh) {
			if (topKind == 3) {
				y = flash(client, matrices, y, topText);        // «СОБЫТИЕ!» — плашка на пару секунд
			} else {
				int color = topKind == 2 ? 0xFF62D98A : 0xFFE8C15A;
				y = row(client, matrices, y, topText, color);
			}
		}
		if (itemsFresh) {
			row(client, matrices, y, bottomText, 0xFFFFFFFF);
		}
	}

	/** Одна строка таймера: уменьшенный шрифт (как у таймера предметов), по центру. */
	private static float row(MinecraftClient client, MatrixStack matrices, float y, String text, int color) {
		TextRenderer fonts = client.textRenderer;
		int screenWidth = client.getWindow().getScaledWidth();
		float scale = 0.6F;
		float x = (screenWidth - fonts.getWidth(text) * scale) / 2.0F;
		matrices.push();
		matrices.translate(x, y, 0.0F);
		matrices.scale(scale, scale, 1.0F);
		fonts.drawWithShadow(matrices, text, 0.0F, 0.0F, color);
		matrices.pop();
		return y + 12.0F;                                       // следующая строка — чуть ниже
	}

	/** Вспышка «событие сработало»: та же плашка, что была, но строки таймеров сдвигаются ниже. */
	private static float flash(MinecraftClient client, MatrixStack matrices, float y, String text) {
		TextRenderer fonts = client.textRenderer;
		int screenWidth = client.getWindow().getScaledWidth();
		int width = fonts.getWidth(text);
		int left = (screenWidth - width) / 2;
		int top = (int) y;
		DrawableHelper.fill(matrices, left - 6, top - 4, left + width + 6, top + 11, 0x77000000);
		fonts.drawWithShadow(matrices, text, (float) left, (float) top, 0xFFE05C5C);
		return y + 20.0F;
	}

}
