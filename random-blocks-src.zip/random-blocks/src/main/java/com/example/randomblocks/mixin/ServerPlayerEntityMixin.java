package com.example.randomblocks.mixin;

import com.example.randomblocks.BlockRandomizer;
import com.example.randomblocks.EventManager;
import com.example.randomblocks.ItemTimerManager;
import com.example.randomblocks.ModConfig;
import com.example.randomblocks.Permissions;
import com.example.randomblocks.SpawnZone;
import com.example.randomblocks.Stats;
import com.example.randomblocks.CombatTag;
import com.example.randomblocks.RandomBlocks;
import com.example.randomblocks.RankManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Главный хук мода: каждый тик серверного игрока.
 *
 * <ul>
 *   <li>тикает таймер выдачи предметов (дедупликация по времени мира — внутри менеджера);</li>
 *   <li>тикает таймер событий;</li>
 *   <li>следит, чтобы у игрока был префикс привилегии в табе и над головой;</li>
 *   <li>если режим блоков запущен и игрок стоит на новом блоке — превращает этот блок в случайный;</li>
 *   <li>защищает зону спавна: там нет урона и нельзя умереть.</li>
 * </ul>
 *
 * Работает только на серверной стороне (ServerPlayerEntity есть и в одиночной игре),
 * поэтому в мультиплеере мод нужен только серверу.
 */
@Mixin(ServerPlayerEntity.class)
public abstract class ServerPlayerEntityMixin {

	/** Игроки, смерть которых уже обработана (в тике) — чтобы не насчитать дважды. */
	private static final java.util.Set<java.util.UUID> RBC_DEATHS_SEEN = java.util.concurrent.ConcurrentHashMap.newKeySet();

	@Unique
	private boolean randomblocks$wasOnGround = true;

	/** Игрок вышел — забываем применённое состояние, чтобы после возврата префикс применился заново. */
	@Inject(method = "onDisconnect()V", at = @At("HEAD"))
	private void randomblocks$onDisconnect(CallbackInfo ci) {
		RankManager.forget(((ServerPlayerEntity) (Object) this).getUuid());
	}

	/**
	 * В зоне спавна драться нельзя: урона нет ни между игроками, ни от мобов,
	 * если хотя бы одна из сторон внутри зоны. Эффектов слабости при этом никаких — просто нет урона.
	 */
	@Inject(method = "damage(Lnet/minecraft/entity/damage/DamageSource;F)Z", at = @At("HEAD"), cancellable = true)
	private void randomblocks$noFightInSpawnZone(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
		ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;
		if (!SpawnZone.active() || Permissions.isOwner(player)) {
			return;                                     // зона выключена или это OWNER — ему можно всё
		}
		Entity attacker = source.getAttacker();
		if (attacker == null) {
			return;                                     // падение, огонь, голод — это не драка
		}
		boolean attackerInZone = attacker instanceof ServerPlayerEntity
				&& SpawnZone.inside((ServerPlayerEntity) attacker);
		if (SpawnZone.inside(player) || attackerInZone) {
			cir.setReturnValue(false);
			player.sendMessage(new LiteralText("§cЗона спавна: тут драться нельзя."), true);
		}
	}

	/**
	 * В зоне спавна нельзя умереть: смерть отменяется, игрок возвращается на /setspawn
	 * и получает полное здоровье. (Пункт владельца: «когда игрок умирает — она разнится только там».)
	 */
	@Inject(method = "onDeath(Lnet/minecraft/entity/damage/DamageSource;)V", at = @At("HEAD"), cancellable = true)
	private void randomblocks$noDeathInSpawnZone(DamageSource source, CallbackInfo ci) {
		ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;
		if (!SpawnZone.protect(player)) {
			return;
		}
		ci.cancel();
		player.extinguish();
		player.setHealth(player.getMaxHealth());
		SpawnZone.scheduleSendToSpawn(player);          // возврат — на следующем тике
		player.sendMessage(new LiteralText("§6[Привилегии]§r §cв зоне спавна умереть нельзя."), false);
		RandomBlocks.LOGGER.info("{} died in the spawn zone - respawned at /setspawn point", player.getEntityName());
	}

	/**
	 * Учёт смертей и убийств.
	 *
	 * <p>Инъекция в {@code onDeath} на LivingEntity в рантайме не срабатывает (проверено: смерть
	 * игрока не логируется и не считается), поэтому считаем здесь, в рабочем хуке тика:
	 * как только у игрока здоровье падает до нуля — это смерть. Кто убил, берём из ванильного
	 * DamageTracker (им же пользуются ванильные сообщения о смерти), поэтому стрелы и любые
	 * снаряды учитываются так же, как удары рукой.</p>
	 *
	 * <p>В зоне спавна умирать нельзя: вместо смерти игрок оживает и возвращается на точку /setspawn.</p>
	 */
	@org.spongepowered.asm.mixin.Unique
	private void randomblocks$trackDeath(ServerPlayerEntity player) {
		try {
			if (player.getHealth() > 0.0F) {
				RBC_DEATHS_SEEN.remove(player.getUuid());
				return;
			}
			if (!RBC_DEATHS_SEEN.add(player.getUuid())) {
				return;                                  // уже обработали эту смерть
			}
			if (SpawnZone.protect(player)) {
				player.extinguish();
				player.setHealth(player.getMaxHealth());
				SpawnZone.scheduleSendToSpawn(player);
				player.sendMessage(new LiteralText("§6[Привилегии]§r §cв зоне спавна умереть нельзя."), false);
				RandomBlocks.LOGGER.info("{} died in the spawn zone - respawned at /setspawn point", player.getEntityName());
				return;
			}
			// Кто убил — из ванильного DamageTracker (им же пользуются ванильные сообщения о смерти),
			// поэтому лук/снаряды учитываются так же, как удар рукой.
			net.minecraft.entity.LivingEntity biggest = player.getDamageTracker().getBiggestAttacker();
			Entity attacker = biggest;
			// Кто «убил»: сначала трекер урона, а если он не про игрока — тот, кто ударил последним
			// (удары рукой, лук, зелья — всё это ставит метку боя). Так килл засчитывается надёжно.
			RandomBlocks.LOGGER.info("death: victim={} tracker={}", player.getEntityName(),
					attacker == null ? "нет" : attacker.getClass().getName());
			ServerPlayerEntity killer = attacker instanceof ServerPlayerEntity ? (ServerPlayerEntity) attacker : null;
			if (killer == null && attacker instanceof net.minecraft.entity.projectile.ProjectileEntity) {
				Entity owner = ((net.minecraft.entity.projectile.ProjectileEntity) attacker).getOwner();
				if (owner instanceof ServerPlayerEntity) {
					killer = (ServerPlayerEntity) owner;             // стрела засчитывается стрелку
				}
			}
			if (killer == null) {
				killer = CombatTag.opponentOf(player);              // последний, кто ударил, пока бой свежий
			}
			Stats.addDeath(player.getUuid(), player.getEntityName());
			CombatTag.clear(player.getUuid());
			RandomBlocks.LOGGER.info("death: victim={} killer={}", player.getEntityName(),
					killer == null ? "нет" : killer.getEntityName());
			if (killer != null && killer != player) {
				Stats.addKill(killer.getUuid(), killer.getEntityName());
				CombatTag.clear(killer.getUuid());
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("death tracking failed: {}", t.toString());
		}
	}

	@Inject(method = "tick()V", at = @At("HEAD"))
	private void randomblocks$onTick(CallbackInfo ci) {
		ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;
		ModConfig cfg = RandomBlocks.getConfig();

		// Часть 2: отсчёт и выдача предметов.
		ItemTimerManager.tick(player, cfg);

		// Часть 3: таймер событий и голосование.
		EventManager.tick(player, cfg);

		// Часть 5: привилегии — префикс в табе и над головой (работает всегда, режимы тут ни при чём).
		RankManager.tick(player, cfg);
		SpawnZone.tick(player);                         // отложенный возврат на спавн после отменённой смерти
		randomblocks$trackDeath(player);                // учёт смертей/убийств (см. ниже)

		// Часть 1: превращение блока под ногами.
		if (!cfg.enabled) {
			return;
		}
		if (cfg.skipSpectator && player.isSpectator()) {
			return;
		}
		if (cfg.skipCreative && player.abilities.creativeMode) {
			return;
		}

		boolean onGround = player.isOnGround();
		boolean justLanded = onGround && !randomblocks$wasOnGround;
		randomblocks$wasOnGround = onGround;
		if (!onGround) {
			return;
		}

		BlockPos target = BlockRandomizer.blockUnder(player);
		if (target == null) {
			return;
		}

		boolean sameBlock = BlockRandomizer.isSameAsLast(player, target);
		if (sameBlock && !justLanded) {
			// Стоим на месте — этот блок уже превращали, второй раз не трогаем.
			return;
		}
		if (sameBlock && !cfg.transformOnLandingSameBlock) {
			return;
		}
		BlockRandomizer.rememberLast(player, target);

		ServerWorld world = player.getServerWorld();
		if (cfg.transformChance < 1.0D && world.random.nextDouble() >= cfg.transformChance) {
			return;
		}

		if (BlockRandomizer.transform(world, target, cfg) && cfg.debugLog) {
			RandomBlocks.LOGGER.info("{} stepped on {} {} {} -> random block",
					player.getEntityName(), target.getX(), target.getY(), target.getZ());
		}
	}
}
