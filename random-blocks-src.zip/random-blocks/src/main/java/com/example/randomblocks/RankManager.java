package com.example.randomblocks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Привилегии игроков: хранение, выдача и применение.
 *
 * <p>Привилегия видна в трёх местах:</p>
 * <ul>
 *     <li><b>чат</b> — «§9§lHERO §9Ник §8»§r текст» (мод сам собирает строку чата);</li>
 *     <li><b>таб</b> — имя игрока в списке и его место: ванильный таб сортирует игроков
 *         по имени их scoreboard-команды (а внутри команды — по нику), поэтому имя команды
 *         начинается с ключа порядка «rb_<1000−вес>_<привилегия>»: чем выше привилегия,
 *         тем меньше ключ и тем выше игрок. Работает у любых клиентов, даже без мода;</li>
 *     <li><b>над головой</b> — префикс и цвет ника задаются ванильной «командой» (scoreboard team),
 *         поэтому работает у всех клиентов, даже без мода.</li>
 * </ul>
 *
 * <p>Хранится в {@code config/randomblocks-ranks.json}.</p>
 */
public final class RankManager {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
	private static final String FILE_NAME = "randomblocks-ranks.json";
	/** Префикс названий команд в scoreboard, чтобы не мешать чужим. */
	private static final String TEAM_PREFIX = "rb_";
	/** Перезарядка /grant — 5 дней. */
	private static final long GRANT_COOLDOWN_SECONDS = 5L * 24L * 60L * 60L;
	/** Один раз за запуск сервера убираем команды от прежних версий мода. */
	private static boolean pruned = false;

	/** Что записано про игрока: его ник и привилегия. */
	public static final class Entry {
		public String name = "";
		public String rank = Rank.PLAYER.name;
		/** Когда игрок последний раз выдавал донат через /grant (миллисекунды) — раз в 5 дней. */
		public long grantAt;
	}

	private static final class Data {
		/** UUID игрока (в виде строки) → запись. */
		Map<String, Entry> players = new LinkedHashMap<>();
	}

	private static Data data = new Data();

	/**
	 * Имя команды для привилегии: ключ порядка (1000 − вес) плюс название в нижнем регистре.
	 *
	 * <p><b>Важно:</b> в 1.16.5 {@code Scoreboard.addTeam} падает с IllegalArgumentException,
	 * если имя длиннее 16 символов — именно на этом падал IMPERATOR в версии 1.10.0
	 * (там имя было «rb_0994_imperator», 17 символов). Поэтому разделителя перед названием нет,
	 * а лишние символы на всякий случай отрезаются: 3 + 4 + наибольшее название (IMPERATOR — 9)
	 * даёт ровно 16.</p>
	 */
	public static String teamName(Rank rank) {
		String name = TEAM_PREFIX + String.format(Locale.ROOT, "%04d", 1000 - rank.weight)
				+ rank.name.toLowerCase(Locale.ROOT);
		return name.length() > 16 ? name.substring(0, 16) : name;
	}

	/** Снимок применённого состояния, чтобы каждый тик не дёргать сервер зря. */
	private static final Map<UUID, String> APPLIED = new HashMap<>();

	private RankManager() {
	}

	// ------------------------------------------------------------------
	//  Файл
	// ------------------------------------------------------------------

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
	}

	public static void load() {
		Path path = path();
		Data loaded = null;
		if (Files.exists(path)) {
			try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
				loaded = GSON.fromJson(reader, Data.class);
			} catch (Exception e) {
				RandomBlocks.LOGGER.error("Could not read {}, using empty ranks", path, e);
			}
		}
		data = loaded == null ? new Data() : loaded;
		if (data.players == null) {
			data.players = new LinkedHashMap<>();
		}
		APPLIED.clear();
	}

	public static void save() {
		try {
			Path path = path();
			Files.createDirectories(path.getParent());
			try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
				GSON.toJson(data, writer);
			}
		} catch (IOException e) {
			RandomBlocks.LOGGER.error("Could not save ranks", e);
		}
	}

	// ------------------------------------------------------------------
	//  Привилегии игроков
	// ------------------------------------------------------------------

	public static Rank rankOf(UUID uuid) {
		Entry entry = data.players.get(uuid.toString());
		if (entry == null) {
			return Rank.PLAYER;
		}
		Rank rank = Rank.byName(entry.rank);
		return rank == null ? Rank.PLAYER : rank;
	}

	public static Rank rankOf(ServerPlayerEntity player) {
		return rankOf(player.getUuid());
	}

	/** Выдать привилегию (или снять — передав PLAYER). Возвращает прежнюю привилегию. */
	public static Rank setRank(UUID uuid, String playerName, Rank rank) {
		Entry entry = data.players.computeIfAbsent(uuid.toString(), key -> new Entry());
		Rank previous = rankOf(uuid);
		entry.rank = rank.name;
		if (playerName != null && !playerName.isEmpty()) {
			entry.name = playerName;
		}
		save();
		return previous;
	}

	/** Запомнить ник игрока (чтобы потом можно было выдать привилегию офлайн-игроку). */
	public static void rememberName(UUID uuid, String playerName) {
		Entry entry = data.players.get(uuid.toString());
		if (entry == null) {
			return;                                 // игрок без привилегии — зря не записываем
		}
		if (!playerName.equals(entry.name)) {
			entry.name = playerName;
			save();
		}
	}

	/** Найти UUID по нику: сначала среди онлайн-игроков, потом по сохранённым записям. */
	public static UUID findByName(MinecraftServer server, String name) {
		String wanted = name.trim();
		if (server != null) {
			ServerPlayerEntity online = server.getPlayerManager().getPlayer(wanted);
			if (online != null) {
				return online.getUuid();
			}
		}
		for (Map.Entry<String, Entry> e : data.players.entrySet()) {
			if (e.getValue().name != null && e.getValue().name.equalsIgnoreCase(wanted)) {
				return UUID.fromString(e.getKey());
			}
		}
		return null;
	}

	public static String storedName(UUID uuid) {
		Entry entry = data.players.get(uuid.toString());
		return entry == null || entry.name == null ? "" : entry.name;
	}

	/** Сколько секунд осталось до следующего /grant (переживает перезапуск сервера). */
	public static long grantCooldownLeft(UUID uuid) {
		Entry entry = data.players.get(uuid.toString());
		if (entry == null || entry.grantAt <= 0L) {
			return 0L;
		}
		long passed = (System.currentTimeMillis() - entry.grantAt) / 1000L;
		return Math.max(0L, GRANT_COOLDOWN_SECONDS - passed);
	}

	/** Отметить выдачу доната. */
	public static void markGrant(UUID uuid) {
		Entry entry = data.players.computeIfAbsent(uuid.toString(), key -> new Entry());
		entry.grantAt = System.currentTimeMillis();
		save();
	}

	/** Все игроки с привилегией выше PLAYER — для /rank list. */
	public static List<String> granted() {
		List<String> list = new ArrayList<>();
		for (Entry entry : data.players.values()) {
			Rank rank = Rank.byName(entry.rank);
			if (rank != null && rank != Rank.PLAYER && entry.name != null && !entry.name.isEmpty()) {
				list.add(rank.name + " §7— §f" + entry.name);
			}
		}
		java.util.Collections.sort(list);
		return list;
	}

	// ------------------------------------------------------------------
	//  Применение: таб, над головой
	// ------------------------------------------------------------------

	/**
	 * Убедиться, что привилегия игрока применена (имя в табе, команда над головой).
	 * Вызывается каждый тик, но работу делает только при изменениях.
	 */
	public static void tick(ServerPlayerEntity player, ModConfig cfg) {
		if (player.getServer() == null) {
			return;
		}
		if (!cfg.ranksEnabled) {
			// Привилегии выключены — снимаем префикс, если он остался от прошлого запуска.
			APPLIED.remove(player.getUuid());
			Scoreboard scoreboard = player.getServer().getScoreboard();
			Team team = scoreboard.getPlayerTeam(player.getEntityName());
			if (team != null && team.getName().startsWith(TEAM_PREFIX)) {
				scoreboard.clearPlayerTeam(player.getEntityName());
			}
			return;
		}
		checkFly(player);
		Rank rank = rankOf(player);
		String key = rank.name + "|" + player.getEntityName();
		if (key.equals(APPLIED.get(player.getUuid()))) {
			return;
		}
		applySafe(player, rank);
	}

	/**
	 * Применить привилегию, но безопасно: если что-то пошло не так (например, сервер запретил
	 * команду с таким именем), игрок не вылетит и сервер не упадёт — в лог уйдёт причина.
	 */
	public static void applySafe(ServerPlayerEntity player, Rank rank) {
		try {
			apply(player, rank);
		} catch (Throwable t) {
			APPLIED.put(player.getUuid(), rank.name + "|" + player.getEntityName());
			RandomBlocks.LOGGER.error("Could not apply rank {} to {}: {}", rank.name,
					player.getEntityName(), t.toString());
		}
	}

	/** Применить привилегию сейчас (после команды выдачи — сразу, не дожидаясь тика). */
	public static void apply(ServerPlayerEntity player, Rank rank) {
		// И таб, и табличка над головой берутся из ванильной команды (scoreboard team):
		// в 1.16.5 имя в табе — это либо присланное сервером displayName (его мы не трогаем,
		// он null), либо украшенное командой имя, поэтому префикс попадает сразу и в таб,
		// и над головой, и при этом работает у любых клиентов, даже без мода.
		MinecraftServer server = player.getServer();
		if (server == null) {
			return;
		}
		Scoreboard scoreboard = server.getScoreboard();
		String teamName = teamName(rank);
		Team team = scoreboard.getTeam(teamName);
		if (team == null) {
			team = scoreboard.addTeam(teamName);
		}
		// Ник всегда обычный: префикс заканчивается сбросом цвета, а цвет самой команды — RESET,
		// иначе ванила красит им и ник, и его пришлось бы «перекрашивать».
		// Префикс: либо фото-бейдж привилегии (1.12.0), либо обычный текст «§4§lOWNER §f».
		team.setPrefix(RankBadges.prefix(rank));
		team.setColor(Formatting.RESET);
		// PvP не меняем: в ваниле участники одной команды не бьют друг друга,
		// а нам нужно, чтобы игроки одной привилегии дрались между собой как обычно.
		team.setFriendlyFireAllowed(true);
		team.setShowFriendlyInvisibles(false);

		Team current = scoreboard.getPlayerTeam(player.getEntityName());
		if (current != team) {
			if (current != null) {
				scoreboard.clearPlayerTeam(player.getEntityName());
			}
			scoreboard.addPlayerToTeam(player.getEntityName(), team);
		}
		APPLIED.put(player.getUuid(), rank.name + "|" + player.getEntityName());
		pruneStaleTeams(server);
	}

	/**
	 * Убрать команды, которые остались от прежних версий мода или от привилегий, которых больше нет.
	 * Делается один раз за запуск сервера (scoreboard сохраняется в мире, поэтому старые команды
	 * живут между перезапусками).
	 */
	private static void pruneStaleTeams(MinecraftServer server) {
		if (pruned) {
			return;
		}
		pruned = true;
		List<String> valid = new ArrayList<>();
		for (Rank rank : Rank.values()) {
			valid.add(teamName(rank));
		}
		Scoreboard scoreboard = server.getScoreboard();
		for (Team team : new ArrayList<>(scoreboard.getTeams())) {
			String name = team.getName();
			if (name.startsWith(TEAM_PREFIX) && !valid.contains(name)) {
				RandomBlocks.LOGGER.info("Removing stale rank team {}", name);
				scoreboard.removeTeam(team);
			}
		}
	}

	/**
	 * Чистка при старте сервера: убираем все команды привилегий, которых нет в текущей версии
	 * (например, «rb_0995_magister» от версии 1.10.0 или команду с именем длиннее 16 символов,
	 * из-за которой падал IMPERATOR). Работает до входа игроков, поэтому никакие старые данные
	 * до клиентов не доедут.
	 */
	public static void cleanupOnServerStart(MinecraftServer server) {
		try {
			pruned = false;
			pruneStaleTeams(server);
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("Could not clean up rank teams: {}", t.toString());
		}
	}

	/** Убрать все наши команды из scoreboard (привилегии выключены). */
	public static void cleanupAll(MinecraftServer server) {
		if (server == null) {
			return;
		}
		Scoreboard scoreboard = server.getScoreboard();
		for (Team team : new ArrayList<>(scoreboard.getTeams())) {
			if (team.getName().startsWith(TEAM_PREFIX)) {
				scoreboard.removeTeam(team);
			}
		}
		APPLIED.clear();
		pruned = true;
	}

	/** После перечитывания конфига: либо применить заново, либо убрать префиксы. */
	public static void onConfigReload(MinecraftServer server) {
		if (server == null) {
			return;
		}
		if (!RandomBlocks.getConfig().ranksEnabled) {
			cleanupAll(server);
			return;
		}
		for (ServerPlayerEntity online : server.getPlayerManager().getPlayerList()) {
			APPLIED.remove(online.getUuid());
		}
	}

	/** Если привилегия не даёт полёт, а он включён (например, игрока понизили) — выключаем. */
	public static void checkFly(ServerPlayerEntity player) {
		if (player.isCreative() || player.isSpectator()) {
			return;
		}
		if (Permissions.has(player, Permissions.FLY)) {
			return;
		}
		if (player.abilities.allowFlying || player.abilities.flying) {
			player.abilities.allowFlying = false;
			player.abilities.flying = false;
			player.sendAbilitiesUpdate();
			player.sendMessage(new LiteralText("§6[Привилегии]§r полёт выключен: привилегия §e"
					+ rankOf(player).name + "§r его не даёт."), false);
		}
	}

	/** Игрок вышел: забываем «применённое», чтобы после возврата всё применилось заново. */
	public static void forget(UUID uuid) {
		APPLIED.remove(uuid);
	}

	// ------------------------------------------------------------------
	//  Чат
	// ------------------------------------------------------------------

}
