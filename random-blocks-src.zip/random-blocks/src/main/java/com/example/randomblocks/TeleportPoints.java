package com.example.randomblocks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.RegistryKey;
import net.minecraft.world.World;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Точки телепортации: общий спавн сервера и именованные «дома» игроков.
 *
 * Файл: {@code config/randomblocks-teleport.json} — чтобы настройки самого мода
 * ({@code randomblocks.json}) оставались только про поведение.
 */
public final class TeleportPoints {

	/** Сколько точек дома разрешено одному игроку по умолчанию (настраивается: maxHomes). */
	public static final int DEFAULT_MAX_HOMES = 10;

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
	private static final String FILE_NAME = "randomblocks-teleport.json";

	/** Одна точка: координаты, поворот и измерение. */
	public static final class Point {
		public String world = "minecraft:overworld";
		public double x;
		public double y;
		public double z;
		public float yaw;
		public float pitch;
	}

	/** Всё, что хранится в файле. */
	private static final class Data {
		Point spawn;
		Map<String, Map<String, Point>> homes = new LinkedHashMap<>();
	}

	private static Data data = new Data();

	private TeleportPoints() {
	}

	// ------------------------------------------------------------------
	//  Файл
	// ------------------------------------------------------------------

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
	}

	/** Перечитать файл (вызывается при старте сервера и по /randomblock reload). */
	public static void load() {
		Path path = path();
		Data loaded = null;
		if (Files.exists(path)) {
			try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
				loaded = GSON.fromJson(reader, Data.class);
			} catch (Exception e) {
				RandomBlocks.LOGGER.error("Could not read {}, using empty teleport points", path, e);
			}
		}
		data = loaded == null ? new Data() : loaded;
		if (data.homes == null) {
			data.homes = new LinkedHashMap<>();
		}
	}

	public static void save() {
		try {
			Path path = path();
			Files.createDirectories(path.getParent());
			try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
				GSON.toJson(data, writer);
			}
		} catch (IOException e) {
			RandomBlocks.LOGGER.error("Could not save teleport points", e);
		}
	}

	// ------------------------------------------------------------------
	//  Спавн сервера
	// ------------------------------------------------------------------

	public static Point spawn() {
		return data.spawn;
	}

	/** Установить спавн: запоминаем и у самих настроек мода, и в ванильном мире (там спавн после смерти). */
	public static void setSpawn(net.minecraft.server.world.ServerWorld world, double x, double y, double z, float yaw, float pitch) {
		Point point = new Point();
		point.world = world.getRegistryKey().getValue().toString();
		point.x = x;
		point.y = y;
		point.z = z;
		point.yaw = yaw;
		point.pitch = pitch;
		data.spawn = point;
		world.setSpawnPos(new BlockPos(x, y, z), yaw);
		save();
	}

	// ------------------------------------------------------------------
	//  Дома игроков
	// ------------------------------------------------------------------

	public static Map<String, Point> homesOf(java.util.UUID player) {
		return data.homes.computeIfAbsent(player.toString(), key -> new LinkedHashMap<>());
	}

	public static Point home(java.util.UUID player, String name) {
		return homesOf(player).get(normalize(name));
	}

	/** Поставить (или обновить) точку дома. Лимит проверяет команда — он настраивается (maxHomes). */
	public static Point setHome(java.util.UUID player, String name, World world, double x, double y, double z,
			float yaw, float pitch) {
		Map<String, Point> homes = homesOf(player);
		String key = normalize(name);
		Point point = new Point();
		point.world = world.getRegistryKey().getValue().toString();
		point.x = x;
		point.y = y;
		point.z = z;
		point.yaw = yaw;
		point.pitch = pitch;
		homes.put(key, point);
		save();
		return point;
	}

	public static boolean removeHome(java.util.UUID player, String name) {
		boolean removed = homesOf(player).remove(normalize(name)) != null;
		if (removed) {
			save();
		}
		return removed;
	}

	/** Имя точки приводим к одному виду: нижний регистр, без лишних пробелов по краям и внутри. */
	public static String normalize(String name) {
		if (name == null || name.trim().isEmpty()) {
			return "home";
		}
		String trimmed = name.trim().toLowerCase(java.util.Locale.ROOT).replaceAll("\\s+", " ");
		return trimmed.length() > 24 ? trimmed.substring(0, 24) : trimmed;
	}

	/** Мир точки, если он сейчас загружен (иначе null). */
	public static net.minecraft.server.world.ServerWorld worldOf(net.minecraft.server.MinecraftServer server, Point point) {
		if (server == null || point == null || point.world == null) {
			return null;
		}
		return server.getWorld(RegistryKey.of(Registry.WORLD_KEY, new Identifier(point.world)));
	}

	/** Карта type для Gson (нужна, чтобы читать вложенные объекты). */
	static Map<String, Point> mapOf(String json) {
		return GSON.fromJson(json, new TypeToken<Map<String, Point>>() {
		}.getType());
	}
}
