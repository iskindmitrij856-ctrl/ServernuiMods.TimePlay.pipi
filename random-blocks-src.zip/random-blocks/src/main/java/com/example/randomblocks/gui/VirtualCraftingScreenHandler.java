package com.example.randomblocks.gui;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.CraftingScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;

/**
 * Виртуальный верстак (1.13.0) — сетка 3×3 без настоящего блока верстака.
 *
 * <p>Почему не обойтись обычным {@link CraftingScreenHandler}: он считает результат крафта внутри
 * {@code context.run(...)}, а если передать {@code ScreenHandlerContext.EMPTY}, этот вызов ничего не
 * делает — сетка заполняется, а слот результата остаётся пустым. Именно поэтому «нельзя крафтить».</p>
 *
 * <p>Поэтому контекст здесь настоящий (мир и точка игрока): тогда результат считается, ингредиенты
 * списываются, звук крафта играет рядом. Единственное, что приходится поправить, — проверка
 * «блок верстака ещё на месте?»: у виртуального верстака блока нет, поэтому {@link #canUse}
 * просто разрешает работу с окном.</p>
 */
public class VirtualCraftingScreenHandler extends CraftingScreenHandler {

	public VirtualCraftingScreenHandler(int syncId, PlayerInventory playerInventory, ScreenHandlerContext context) {
		super(syncId, playerInventory, context);
	}

	@Override
	public boolean canUse(PlayerEntity player) {
		return true;
	}
}
