package com.example.randomblocks.command;

import com.example.randomblocks.Permissions;
import com.example.randomblocks.RandomBlocks;
import com.example.randomblocks.RankManager;
import com.example.randomblocks.TeleportPoints;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.BlockPos;

import java.util.Map;

/**
 * Телепорт-команды мода:
 *
 * <ul>
 *     <li>{@code /setspawn} — поставить общий спавн (нужен OP), после этого работает {@code /spawn};</li>
 *     <li>{@code /spawn} — телепорт на поставленный спавн (для всех игроков);</li>
 *     <li>{@code /sethome [название]} — поставить точку дома (до 10 у каждого игрока);</li>
 *     <li>{@code /home [название]} — телепорт на свою точку (без названия — на «дом»);</li>
 *     <li>{@code /homes} — список своих точек; {@code /delhome <название>} — удалить точку.</li>
 * </ul>
 *
 * Точки хранятся в {@code config/randomblocks-teleport.json} и переживают перезапуск сервера.
 * Если спавн ещё не поставлен, {@code /spawn} честно говорит об этом, а не телепортирует «куда-нибудь».
 */
public final class TeleportCommand {

	private TeleportCommand() {
	}

	public static void register() {
		// Регистрируем каждую команду отдельно и терпимо: если на сервере уже есть чужая /spawn
		// или /home (например, от другого мода), мод не упадёт — просто напишет в лог.
		tryRegister(dispatcher -> dispatcher.register(CommandManager.literal("setspawn")
				.requires(source -> source.hasPermissionLevel(2))
				.executes(TeleportCommand::setSpawn)));
		tryRegister(dispatcher -> dispatcher.register(CommandManager.literal("spawn")
				.executes(TeleportCommand::goSpawn)));
		tryRegister(dispatcher -> dispatcher.register(CommandManager.literal("sethome")
				.executes(context -> setHome(context, null))
				.then(CommandManager.argument("name", StringArgumentType.greedyString())
						.executes(context -> setHome(context, StringArgumentType.getString(context, "name"))))));
		tryRegister(dispatcher -> dispatcher.register(CommandManager.literal("home")
				.executes(context -> goHome(context, null))
				.then(CommandManager.argument("name", StringArgumentType.greedyString())
						.executes(context -> goHome(context, StringArgumentType.getString(context, "name"))))));
		tryRegister(dispatcher -> dispatcher.register(CommandManager.literal("homes")
				.executes(TeleportCommand::listHomes)));
		tryRegister(dispatcher -> dispatcher.register(CommandManager.literal("delhome")
				.then(CommandManager.argument("name", StringArgumentType.greedyString())
						.executes(context -> delHome(context, StringArgumentType.getString(context, "name"))))));
	}

	private interface Registrar {
		void register(CommandDispatcher<ServerCommandSource> dispatcher);
	}

	private static void tryRegister(Registrar registrar) {
		try {
			CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> registrar.register(dispatcher));
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("Teleport command not registered: {}", t.toString());
		}
	}

	// ------------------------------------------------------------------
	//  /setspawn и /spawn
	// ------------------------------------------------------------------

	private static int setSpawn(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerCommandSource source = context.getSource();
		ServerPlayerEntity player = source.getPlayer();
		ServerWorld world = player.getServerWorld();

		TeleportPoints.setSpawn(world, player.getX(), player.getY(), player.getZ(), player.yaw, player.pitch);
		BlockPos pos = new BlockPos(player.getX(), player.getY(), player.getZ());
		source.sendFeedback(new LiteralText("§6[Random Blocks]§r спавн установлен: §e"
				+ pos.getX() + " " + pos.getY() + " " + pos.getZ() + "§r §7(" + worldName(player) + ")"), false);
		source.sendFeedback(new LiteralText("§7Теперь любой игрок может вернуться сюда командой §e/spawn§7."), false);
		RandomBlocks.LOGGER.info("Spawn set by {} at {} {} {} ({})", player.getEntityName(),
				pos.getX(), pos.getY(), pos.getZ(), world.getRegistryKey().getValue());
		return 1;
	}

	private static int goSpawn(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerCommandSource source = context.getSource();
		ServerPlayerEntity player = source.getPlayer();
		TeleportPoints.Point spawn = TeleportPoints.spawn();
		if (spawn == null) {
			source.sendError(new LiteralText("§cСпавн ещё не установлен. Пусть оператор встанет в нужном месте и напишет §e/setspawn§c."));
			return 0;
		}
		ServerWorld world = TeleportPoints.worldOf(source.getMinecraftServer(), spawn);
		if (world == null) {
			source.sendError(new LiteralText("§cМир точки спавна сейчас недоступен."));
			return 0;
		}
		teleport(player, world, spawn);
		source.sendFeedback(new LiteralText("§6[Random Blocks]§r телепорт на спавн."), false);
		return 1;
	}

	// ------------------------------------------------------------------
	//  /sethome, /home, /homes, /delhome
	// ------------------------------------------------------------------

	private static int setHome(CommandContext<ServerCommandSource> context, String name) throws CommandSyntaxException {
		ServerCommandSource source = context.getSource();
		ServerPlayerEntity player = source.getPlayer();
		String key = TeleportPoints.normalize(name);
		Map<String, TeleportPoints.Point> homes = TeleportPoints.homesOf(player.getUuid());

		int max = Permissions.homeLimit(player);       // лимит зависит от привилегии
		boolean replaced = homes.containsKey(key);
		if (!replaced && homes.size() >= max) {
			source.sendError(new LiteralText("§cУ тебя уже §e" + max
					+ "§c точек дома (максимум для привилегии §e" + RankManager.rankOf(player).name
					+ "§c). Удали ненужную: §e/delhome <название>§c, либо получи привилегию выше."));
			return 0;
		}

		TeleportPoints.setHome(player.getUuid(), key, player.getServerWorld(),
				player.getX(), player.getY(), player.getZ(), player.yaw, player.pitch);
		BlockPos pos = new BlockPos(player.getX(), player.getY(), player.getZ());
		boolean defaultName = name == null || name.trim().isEmpty();
		source.sendFeedback(new LiteralText("§6[Random Blocks]§r " + (replaced ? "точка дома §e«" + key + "»§r обновлена" : "точка дома §e«" + key + "»§r поставлена")
				+ ": §7" + pos.getX() + " " + pos.getY() + " " + pos.getZ()
				+ " §8(" + homes.size() + "/" + Permissions.homeLimitText(player) + ")"), false);
		if (defaultName) {
			source.sendFeedback(new LiteralText("§7Своё название: §e/sethome дача у озера§7 (можно с пробелами), телепорт — §e/home дача у озера§7."), false);
		}
		RandomBlocks.LOGGER.info("Home '{}' set by {} at {} {} {} ({})", key, player.getEntityName(),
				pos.getX(), pos.getY(), pos.getZ(), player.getServerWorld().getRegistryKey().getValue());
		return 1;
	}

	private static int goHome(CommandContext<ServerCommandSource> context, String name) throws CommandSyntaxException {
		ServerCommandSource source = context.getSource();
		ServerPlayerEntity player = source.getPlayer();
		String key = TeleportPoints.normalize(name);
		TeleportPoints.Point point = TeleportPoints.home(player.getUuid(), key);
		if (point == null) {
			Map<String, TeleportPoints.Point> homes = TeleportPoints.homesOf(player.getUuid());
			if (homes.isEmpty()) {
				source.sendError(new LiteralText("§cУ тебя пока нет точек дома. Поставь: §e/sethome <название>§c."));
			} else {
				source.sendError(new LiteralText("§cТочки дома §e«" + key + "»§c нет. Твои точки: §e" + String.join("§7, §e", homes.keySet()) + "§c."));
			}
			return 0;
		}
		ServerWorld world = TeleportPoints.worldOf(source.getMinecraftServer(), point);
		if (world == null) {
			source.sendError(new LiteralText("§cМир этой точки сейчас недоступен."));
			return 0;
		}
		teleport(player, world, point);
		source.sendFeedback(new LiteralText("§6[Random Blocks]§r телепорт домой: §e«" + key + "»"
				+ "§r §7(мир " + worldName(player) + ")"), false);
		return 1;
	}

	private static int listHomes(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerCommandSource source = context.getSource();
		ServerPlayerEntity player = source.getPlayer();
		Map<String, TeleportPoints.Point> homes = TeleportPoints.homesOf(player.getUuid());
		if (homes.isEmpty()) {
			source.sendFeedback(new LiteralText("§6[Random Blocks]§r точек дома нет. Поставь первую: §e/sethome <название>§r."), false);
			return 1;
		}
		StringBuilder text = new StringBuilder("§6[Random Blocks]§r твои точки дома §7(" + homes.size() + "/"
				+ Permissions.homeLimitText(player) + ")§r: ");
		boolean first = true;
		for (Map.Entry<String, TeleportPoints.Point> entry : homes.entrySet()) {
			if (!first) {
				text.append("§7, §r");
			}
			first = false;
			TeleportPoints.Point p = entry.getValue();
			text.append("§e").append(entry.getKey()).append("§8 [")
					.append((int) p.x).append(' ').append((int) p.y).append(' ').append((int) p.z).append(']');
		}
		source.sendFeedback(new LiteralText(text.toString()), false);
		source.sendFeedback(new LiteralText("§7Телепорт: §e/home <название>§7, удалить: §e/delhome <название>§7."), false);
		return 1;
	}

	private static int delHome(CommandContext<ServerCommandSource> context, String name) throws CommandSyntaxException {
		ServerCommandSource source = context.getSource();
		ServerPlayerEntity player = source.getPlayer();
		String key = TeleportPoints.normalize(name);
		if (TeleportPoints.removeHome(player.getUuid(), key)) {
			source.sendFeedback(new LiteralText("§6[Random Blocks]§r точка дома §e«" + key + "»§r удалена."), false);
			return 1;
		}
		source.sendError(new LiteralText("§cТочки дома §e«" + key + "»§c нет."));
		return 0;
	}

	// ------------------------------------------------------------------

	private static void teleport(ServerPlayerEntity player, ServerWorld world, TeleportPoints.Point point) {
		if (player.getServerWorld() != world) {
			player.teleport(world, point.x, point.y, point.z, point.yaw, point.pitch);
		} else {
			player.teleport(world, point.x, point.y, point.z, point.yaw, point.pitch);
		}
		// Если игрок стоял на транспорте — после телепорта он с него сходит (иначе телепорт «утащит» лодку).
		player.stopRiding();
	}

	private static String worldName(ServerPlayerEntity player) {
		String path = player.getServerWorld().getRegistryKey().getValue().getPath();
		switch (path) {
			case "overworld":
				return "обычный мир";
			case "the_nether":
				return "Нижний мир";
			case "the_end":
				return "Край";
			default:
				return path;
		}
	}
}
