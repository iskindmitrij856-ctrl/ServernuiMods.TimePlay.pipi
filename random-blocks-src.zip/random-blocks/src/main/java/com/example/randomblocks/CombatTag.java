package com.example.randomblocks;

import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameRules;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * ПВП-бой (1.13.0).
 *
 * <p>Правила владельца сервера:</p>
 * <ul>
 *     <li>ударил игрока — у обоих включается «бой» на 20 секунд;</li>
 *     <li>каждый следующий удар <b>продлевает</b> бой (снова 20 секунд);</li>
 *     <li>пока идёт бой — <b>нельзя писать команды</b>;</li>
 *     <li>вышел из игры в бою — <b>умирает и теряет вещи</b>.</li>
 * </ul>
 *
 * <p>Всё настраивается: {@code combatTagEnabled} и {@code combatTagSeconds} в конфиге.</p>
 */
public final class CombatTag {

	/** До какого момента (мс) игрок считается «в бою». */
	private static final Map<UUID, Long> TAGGED = new HashMap<>();

	/** Последний, кто ударил игрока, и до какого времени это «свежо» (для зачёта убийства). */
	private static final Map<UUID, long[]> LAST_ATTACKER = new HashMap<>();

	private CombatTag() {
	}

	public static int seconds() {
		ModConfig config = RandomBlocks.getConfig();
		return config == null ? 20 : Math.max(1, config.combatTagSeconds);
	}

	public static boolean enabled() {
		ModConfig config = RandomBlocks.getConfig();
		return config == null || config.combatTagEnabled;
	}

	/**
	 * Кому бой не ставится вообще: креатив/наблюдатель (там не дерутся по-настоящему) и зона
	 * защиты спавна (по правилам сервера там драться нельзя). Проверяем обоих — и того, кто ударил,
	 * и того, кому прилетело: если хоть один «неприкосновенный», бой не включается ни у кого.
	 */
	public static boolean protectedFromCombat(ServerPlayerEntity player) {
		if (player == null) {
			return true;
		}
		if (player.isCreative() || player.isSpectator()) {
			return true;
		}
		return SpawnZone.protect(player);
	}

	/** Отметить бой для двоих: удар продлевает его обоим. Возвращает false, если бой запрещён. */
	public static boolean tag(ServerPlayerEntity first, ServerPlayerEntity second) {
		if (!enabled() || first == null || second == null) {
			return false;
		}
		if (protectedFromCombat(first) || protectedFromCombat(second)) {
			return false;
		}
		long until = System.currentTimeMillis() + seconds() * 1000L;
		TAGGED.put(first.getUuid(), until);
		TAGGED.put(second.getUuid(), until);
		LAST_ATTACKER.put(second.getUuid(), new long[]{first.getUuid().getMostSignificantBits(), first.getUuid().getLeastSignificantBits(), until});
		LAST_ATTACKER.put(first.getUuid(), new long[]{second.getUuid().getMostSignificantBits(), second.getUuid().getLeastSignificantBits(), until});
		return true;
	}

	public static boolean tagged(ServerPlayerEntity player) {
		if (!enabled() || player == null) {
			return false;
		}
		Long until = TAGGED.get(player.getUuid());
		if (until == null) {
			return false;
		}
		if (until < System.currentTimeMillis()) {
			TAGGED.remove(player.getUuid());
			return false;
		}
		return true;
	}

	/** Сколько секунд боя осталось (0 — не в бою). */
	public static long secondsLeft(ServerPlayerEntity player) {
		Long until = TAGGED.get(player.getUuid());
		if (until == null) {
			return 0L;
		}
		long left = (until - System.currentTimeMillis() + 999L) / 1000L;
		return Math.max(0L, left);
	}

	/**
	 * Последний нападавший на игрока — но только пока бой ещё «свежий» (в пределах того же
	 * окна, что и сам бой). Так килл засчитывается тому, кто реально дрался, а не тому,
	 * кто ударил когда-то давно.
	 */
	public static ServerPlayerEntity opponentOf(ServerPlayerEntity player) {
		if (player == null || player.getServer() == null) {
			return null;
		}
		long[] record = LAST_ATTACKER.get(player.getUuid());
		if (record == null) {
			return null;
		}
		if (System.currentTimeMillis() > record[2]) {
			LAST_ATTACKER.remove(player.getUuid());
			return null;
		}
		UUID uuid = new UUID(record[0], record[1]);
		ServerPlayerEntity other = player.getServer().getPlayerManager().getPlayer(uuid);
		return other == player ? null : other;
	}

	public static void clear(UUID uuid) {
		TAGGED.remove(uuid);
		LAST_ATTACKER.remove(uuid);
	}

	/** Текст для сообщения игроку, когда он попытался что-то сделать в бою. */
	public static String message(ServerPlayerEntity player) {
		return "§cТы в бою! Ещё " + secondsLeft(player) + " с — команды нельзя.";
	}

	/**
	 * Игрок вышел в бою: он умирает и теряет вещи. Вещи разбрасываются там, где он стоял
	 * (если в мире включены дропы), счётчик смертей растёт, всем уходит сообщение.
	 */
	public static void onLogout(ServerPlayerEntity player) {
		if (!tagged(player)) {
			return;
		}
		UUID uuid = player.getUuid();
		String name = player.getEntityName();
		TAGGED.remove(uuid);
		boolean keepInventory = player.world.getGameRules().getBoolean(GameRules.KEEP_INVENTORY);
		BlockPos pos = player.getBlockPos();
		if (!keepInventory) {
			for (int slot = 0; slot < player.inventory.size(); slot++) {
				ItemStack stack = player.inventory.getStack(slot);
				if (!stack.isEmpty()) {
					player.dropItem(stack.copy(), true, false);
					player.inventory.setStack(slot, ItemStack.EMPTY);
				}
			}
		}
		Stats.addDeath(uuid, name);
		// Кто убил: тот, с кем шёл бой (последний нападавший). Выход в бою = смерть,
		// поэтому убийство засчитывается ему — так и задумано в правилах ПВП.
		ServerPlayerEntity killer = opponentOf(player);
		if (killer != null && killer != player) {
			Stats.addKill(killer.getUuid(), killer.getEntityName());
			TAGGED.remove(killer.getUuid());
			RandomBlocks.LOGGER.info("Combat logout: {} died, kill credited to {}", name, killer.getEntityName());
		}
		RandomBlocks.LOGGER.info("Combat logout: {} died and dropped items at {} {} {}",
				name, pos.getX(), pos.getY(), pos.getZ());
		for (ServerPlayerEntity online : player.getServer().getPlayerManager().getPlayerList()) {
			online.sendMessage(new LiteralText("§c[ПВП]§r §e" + name + "§r вышел из игры в бою — смерть и потеря вещей."), false);
		}
	}
}
