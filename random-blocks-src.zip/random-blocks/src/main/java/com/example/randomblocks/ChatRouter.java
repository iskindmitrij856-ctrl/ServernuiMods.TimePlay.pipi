package com.example.randomblocks;

import net.minecraft.network.MessageType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * Чат мода.
 *
 * <ul>
 *     <li>Обычное сообщение (без «!» в начале) видят только те, кто рядом — в радиусе
 *         {@code localChatRadius} блоков (по умолчанию 100). Помечается значком <b>Ⓛ</b>.</li>
 *     <li>Сообщение, начинающееся с «!», видят все. Помечается значком <b>Ⓖ</b>. Сам «!»
 *         в текст не попадает.</li>
 * </ul>
 *
 * <p>Строка чата собирается в виде «ПРИВИЛЕГИЯ Ник Ⓖ » текст»: префикс привилегии цветной
 * и жирный, а <b>сам ник всегда обычный, белый</b> — как просил владелец.</p>
 *
 * <p>Значки Ⓛ и Ⓖ — из стандартного шрифта игры (страница 24 юникода), поэтому их видят все
 * клиенты, даже без мода. Оба значка можно заменить в настройках.</p>
 */
public final class ChatRouter {

	private ChatRouter() {
	}

	/** Обработать сообщение игрока из чата. Возвращает true, если сообщение ушло в наш формат. */
	public static boolean handle(ServerPlayerEntity player, String raw) {
		ModConfig cfg = RandomBlocks.getConfig();
		if (!cfg.localChatEnabled) {
			return false;
		}
		String message = raw;
		boolean global = false;
		if (message.startsWith("!")) {
			global = true;
			message = message.substring(1);
		}
		if (message.trim().isEmpty()) {
			return false;
		}

		MinecraftServer server = player.getServer();
		if (server == null) {
			return false;
		}

		Text line = line(player, message, global);
		if (global) {
			server.getPlayerManager().broadcastChatMessage(line, MessageType.CHAT, player.getUuid());
			RandomBlocks.LOGGER.info("<{} {}> {}", tag(player), player.getEntityName(), message);
		} else {
			int sent = 0;
			ServerWorld world = player.getServerWorld();
			Vec3d pos = player.getPos();
			double radius = Math.max(1.0D, cfg.localChatRadius);
			List<ServerPlayerEntity> heard = new ArrayList<>();
			for (ServerPlayerEntity other : server.getPlayerManager().getPlayerList()) {
				if (other == player) {
					continue;
				}
				if (other.getServerWorld() == world && other.squaredDistanceTo(pos) <= radius * radius) {
					heard.add(other);
					other.sendMessage(line, false);
					sent++;
				}
			}
			player.sendMessage(line, false);            // себя всегда слышно
			RandomBlocks.LOGGER.info("<{} {}> [рядом: {}] {}", tag(player), player.getEntityName(), sent, message);
		}
		return true;
	}

	/** Готовая строка чата: «ПРИВИЛЕГИЯ Ник Ⓖ » текст». */
	public static Text line(ServerPlayerEntity player, String message, boolean global) {
		Rank rank = RankManager.rankOf(player);
		// Собираем строку из частей: префикс привилегии может быть картинкой (фото-бейдж),
		// а картинку нельзя «вписать» в строку с §-кодами — она задаётся шрифтом у части текста.
		MutableText text = new LiteralText("");
		if (RandomBlocks.getConfig().ranksEnabled) {
			text.append(RankBadges.prefix(rank));
		}
		text.append(new LiteralText(player.getEntityName() + " "));
		if (global) {
			text.append(new LiteralText("§a" + RandomBlocks.getConfig().globalChatIcon));
		} else {
			text.append(new LiteralText("§7" + RandomBlocks.getConfig().localChatIcon));
		}
		text.append(new LiteralText(" §8» §r" + message));
		return text;
	}

	/** Короткая пометка для консоли сервера. */
	public static String tag(ServerPlayerEntity player) {
		return RandomBlocks.getConfig().ranksEnabled ? RankManager.rankOf(player).name : "игрок";
	}

	/** Как выглядит значок для подсказок. */
	public static String legend() {
		ModConfig cfg = RandomBlocks.getConfig();
		return "§7" + cfg.localChatIcon + "§r — видят только те, кто рядом (" + (int) cfg.localChatRadius
				+ " блоков); §a" + cfg.globalChatIcon + "§r — видят все (напиши «!" + "привет»).";
	}
}
