package com.example.randomblocks;

import com.example.randomblocks.command.BanCommand;
import com.example.randomblocks.command.DonateCaseCommand;
import com.example.randomblocks.command.EventCommand;
import com.example.randomblocks.command.ExtraCommand;
import com.example.randomblocks.command.RandomBlocksCommand;
import com.example.randomblocks.command.RankCommand;
import com.example.randomblocks.command.TeleportCommand;
import com.example.randomblocks.command.VipCommand;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Random Blocks & Random Items — «два мода в одном».
 *
 * <ol>
 *   <li><b>Случайные блоки:</b> блок, на который встал игрок, превращается в случайный другой.
 *       Запускается и останавливается командой /randomblock start | stop.</li>
 *   <li><b>Случайные предметы:</b> таймер (по умолчанию 5 минут), который выдаёт игрокам случайные
 *       предметы и показывает обратный отсчёт над панелью инвентаря.
 *       Управление: /randomblock item start | stop | time &lt;минуты&gt;.</li>
 * </ol>
 *
 * Всё настраивается в config/randomblocks.json (создаётся при первом запуске).
 */
public class RandomBlocks implements ModInitializer {

	public static final String MOD_ID = "randomblocks";
	public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

	private static ModConfig config = new ModConfig();

	@Override
	public void onInitialize() {
		config = ModConfig.load();

		// С самого запуска сервера всё выключено: блоки не превращаются, предметы не выдаются,
		// события не спавнятся. Включить может только оператор командами — так и задумано.
		boolean wasRunning = config.enabled || config.itemTimerEnabled || config.eventTimerEnabled;
		config.enabled = false;
		config.itemTimerEnabled = false;
		config.eventTimerEnabled = false;
		ItemTimerManager.reset(config);
		EventManager.reset(config);
		config.save();
		LOGGER.info("Loaded (everything starts OFF on server start). blocks={} (chance={}, onlyFullBlocks={}), items={} (every {}s, enchantChance={}), events={} (every {}s, voting={}, vote {}s){}",
				config.enabled, config.transformChance, config.onlyFullBlocks,
				config.itemTimerEnabled, config.itemIntervalSeconds, config.itemEnchantChance,
				config.eventTimerEnabled, config.eventIntervalSeconds, config.eventVotingEnabled,
				config.eventVoteDurationSeconds,
				wasRunning ? " — previous session had modes running, they were switched off" : "");
		TeleportPoints.load();
		RankManager.load();
		Economy.load();
		Stats.load();
		Bans.load();

		// Чистка команд привилегий при старте сервера (до входа игроков): убираем всё, что
		// осталось от прежних версий мода, чтобы старые имена не мешали и не ломали клиентов.
		try {
			net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STARTED.register(
					RankManager::cleanupOnServerStart);
			// Скорборд: раз в секунду обновляем строки у каждого игрока (ник, ранг, У/С, деньги, пинг).
			net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(Sidebar::tick);
			// Колесо фортуны донат-кейсов крутится по тикам сервера.
			net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(DonateCase::tick);
			// Ресурспак с фото-бейджами: собираем при старте и раздаём всем, кто зашёл.
			net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STARTED.register(
					server -> ResourcePack.setup());
			net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.JOIN.register(
					(handler, sender, server) -> {
						Economy.remember(handler.player);
						Stats.touch(handler.player.getUuid(), handler.player.getEntityName());
						Sidebar.onJoin(handler.player);
						ResourcePack.send(handler.player);
					});
		} catch (Throwable t) {
			LOGGER.warn("Rank team cleanup is unavailable: {}", t.toString());
		}

		// Команда /randomblock требует Fabric API, но сами механики работают и без него.
		if (config.commandEnabled && FabricLoader.getInstance().isModLoaded("fabric-command-api-v1")) {
			RandomBlocksCommand.register();
			EventCommand.register();
			TeleportCommand.register();
			RankCommand.register();
			VipCommand.register();
			ExtraCommand.register();
			BanCommand.register();
			DonateCaseCommand.register();
		} else if (!config.commandEnabled) {
			LOGGER.info("Commands are disabled in the config.");
		} else {
			LOGGER.info("Fabric API not found: /randomblock command is unavailable, everything else works.");
		}
	}

	/** Версия мода — показывается в /randomblock, чтобы было видно, какой jar установлен. */
	public static String version() {
		return FabricLoader.getInstance().getModContainer(MOD_ID)
				.map(container -> container.getMetadata().getVersion().getFriendlyString())
				.orElse("unknown");
	}

	public static ModConfig getConfig() {
		return config;
	}

	public static void setConfig(ModConfig newConfig) {
		config = newConfig;
		BlockRandomizer.invalidatePool();
		RandomItems.invalidatePool();
	}

	public static void reloadConfig() {
		config = ModConfig.load();
		TeleportPoints.load();
		Economy.load();
		Stats.load();
		Bans.load();
		DonateCase.load();
		BlockRandomizer.invalidatePool();
		RandomItems.invalidatePool();
		ItemTimerManager.reset(config);
	}
}
