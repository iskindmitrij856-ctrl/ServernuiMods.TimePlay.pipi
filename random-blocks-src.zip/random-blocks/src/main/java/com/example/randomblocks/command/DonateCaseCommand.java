package com.example.randomblocks.command;

import com.example.randomblocks.DonateCase;
import com.example.randomblocks.Permissions;
import com.example.randomblocks.RandomBlocks;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

import java.util.List;
import java.util.UUID;

/**
 * Донат-кейсы: {@code /dk}.
 *
 * <pre>
 * /dk                              — справка
 * /dk create                       — сделать блок, на который смотришь, донат-кейсом
 * /dk delete                       — убрать кейс с блока, на который смотришь
 * /dk list                         — список кейсов и сколько их
 * /dk keys [ник]                   — сколько ключей (по умолчанию — у себя)
 * /dk give|set|remove &lt;ник&gt; &lt;число&gt;   — выдать / установить / забрать ключи
 * </pre>
 *
 * <p>Открыть кейс можно только с ключом: без ключей игрок получит подсказку. Всё, что можно
 * выкрутить, и с какими шансами — в {@link DonateCase}.</p>
 */
public final class DonateCaseCommand {

	private DonateCaseCommand() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
			try {
				registerAll(dispatcher);
				RandomBlocks.LOGGER.info("Donate case commands registered");
			} catch (Throwable t) {
				RandomBlocks.LOGGER.error("Donate case commands not registered: {}", t.toString());
			}
		});
	}

	private static void registerAll(CommandDispatcher<ServerCommandSource> dispatcher) {
		dispatcher.register(CommandManager.literal("dk")
				.executes(DonateCaseCommand::help)
				.then(CommandManager.literal("help").executes(DonateCaseCommand::help))
				.then(CommandManager.literal("create").executes(DonateCaseCommand::create))
				.then(CommandManager.literal("delete").executes(DonateCaseCommand::delete))
				.then(CommandManager.literal("list").executes(DonateCaseCommand::list))
				.then(CommandManager.literal("keys")
						.executes(DonateCaseCommand::ownKeys)
						.then(CommandManager.argument("ник", StringArgumentType.word())
								.suggests(Suggestions.NICKS)
								.executes(DonateCaseCommand::otherKeys)))
				.then(CommandManager.literal("give")
						.then(CommandManager.argument("ник", StringArgumentType.word()).suggests(Suggestions.NICKS)
								.then(CommandManager.argument("число", IntegerArgumentType.integer(1, 100000))
										.executes(context -> change(context, Kind.GIVE)))))
				.then(CommandManager.literal("set")
						.then(CommandManager.argument("ник", StringArgumentType.word()).suggests(Suggestions.NICKS)
								.then(CommandManager.argument("число", IntegerArgumentType.integer(0, 100000))
										.executes(context -> change(context, Kind.SET)))))
				.then(CommandManager.literal("remove")
						.then(CommandManager.argument("ник", StringArgumentType.word()).suggests(Suggestions.NICKS)
								.then(CommandManager.argument("число", IntegerArgumentType.integer(1, 100000))
										.executes(context -> change(context, Kind.REMOVE))))));
	}

	private enum Kind {GIVE, SET, REMOVE}

	// ------------------------------------------------------------------

	private static int help(CommandContext<ServerCommandSource> context) {
		ServerCommandSource source = context.getSource();
		source.sendFeedback(new LiteralText("§6[Донат-кейс]§r как это работает:"), false);
		source.sendFeedback(new LiteralText("§7· поставь блок (сундук, шалкер, эндер-сундук…), смотри на него и напиши §e/dk create"), false);
		source.sendFeedback(new LiteralText("§7· убрать кейс: смотри на блок и напиши §e/dk delete"), false);
		source.sendFeedback(new LiteralText("§7· ключи: §e/dk give <ник> <число>§7, §e/dk set§7, §e/dk remove§7, посмотреть: §e/dk keys [ник]"), false);
		source.sendFeedback(new LiteralText("§7· шансы: §9HERO 70 §7· §eTITAN 50 §7· §5AVENDER 40 §7· §aOVERLORD 25 §7· §6MAGISTER 15 §7· §cIMPERATOR 5 §7· §dDRAGON 1"), false);
		source.sendFeedback(new LiteralText("§7· без ключа кейс не открыть; пока идёт прокрутка, кейс занят; если выпало ниже твоей привилегии — остаётся самая высокая."), false);
		return 1;
	}

	private static int create(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getEntity() instanceof ServerPlayerEntity
				? (ServerPlayerEntity) context.getSource().getEntity() : null;
		if (!Permissions.isOwner(player)) {
			context.getSource().sendError(new LiteralText("§cДонат-кейсы ставит только владелец (OWNER)."));
			return 0;
		}
		BlockPos pos = lookingAt(player);
		if (pos == null) {
			player.sendMessage(new LiteralText("§cНаведись на блок (не дальше 6 блоков) и повтори §e/dk create§c."), false);
			return 0;
		}
		if (DonateCase.addCase(player.world, pos)) {
			player.sendMessage(new LiteralText("§6[Донат-кейс]§r блок §e" + pos.getX() + " " + pos.getY() + " "
					+ pos.getZ() + "§r теперь донат-кейс! Открыть его можно ключом (§e/dk give <ник> <число>§r)."), false);
			return 1;
		}
		player.sendMessage(new LiteralText("§7Этот блок уже донат-кейс."), false);
		return 0;
	}

	private static int delete(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getEntity() instanceof ServerPlayerEntity
				? (ServerPlayerEntity) context.getSource().getEntity() : null;
		if (!Permissions.isOwner(player)) {
			context.getSource().sendError(new LiteralText("§cУбирать донат-кейсы может только владелец (OWNER)."));
			return 0;
		}
		BlockPos pos = lookingAt(player);
		if (pos == null) {
			player.sendMessage(new LiteralText("§cНаведись на блок кейса и повтори §e/dk delete§c."), false);
			return 0;
		}
		if (DonateCase.removeCase(player.world, pos)) {
			player.sendMessage(new LiteralText("§6[Донат-кейс]§r блок больше не кейс."), false);
			return 1;
		}
		player.sendMessage(new LiteralText("§7Этот блок и так не кейс."), false);
		return 0;
	}

	private static int list(CommandContext<ServerCommandSource> context) {
		ServerCommandSource source = context.getSource();
		List<DonateCase.CasePoint> cases = DonateCase.cases();
		if (cases.isEmpty()) {
			source.sendFeedback(new LiteralText("§6[Донат-кейс]§r кейсов пока нет: наведись на блок и напиши §e/dk create§r."), false);
			return 0;
		}
		source.sendFeedback(new LiteralText("§6[Донат-кейс]§r кейсов: §e" + cases.size()), false);
		for (DonateCase.CasePoint point : cases) {
			source.sendFeedback(new LiteralText("§7· §e" + (int) point.x + " " + (int) point.y + " "
					+ (int) point.z + "§7 (" + point.world + ")"), false);
		}
		return cases.size();
	}

	private static int ownKeys(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getEntity() instanceof ServerPlayerEntity
				? (ServerPlayerEntity) context.getSource().getEntity() : null;
		player.sendMessage(new LiteralText("§6[Донат-кейс]§r твоих ключей: §e" + DonateCase.keys(player.getUuid())), false);
		return 1;
	}

	private static int otherKeys(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		if (!Permissions.ownerOrOp(context.getSource())) {
			context.getSource().sendError(new LiteralText("§cЧужие ключи видит только владелец (OWNER)."));
			return 0;
		}
		String name = StringArgumentType.getString(context, "ник");
		UUID uuid = id(context, name);
		if (uuid == null) {
			return 0;
		}
		context.getSource().sendFeedback(new LiteralText("§6[Донат-кейс]§r ключей у §e" + name + "§r: §e"
				+ DonateCase.keys(uuid)), false);
		return 1;
	}

	private static int change(CommandContext<ServerCommandSource> context, Kind kind) throws CommandSyntaxException {
		ServerCommandSource source = context.getSource();
		ServerPlayerEntity player = context.getSource().getEntity() instanceof ServerPlayerEntity
				? (ServerPlayerEntity) context.getSource().getEntity() : null;
		if (!Permissions.ownerOrOp(context.getSource())) {
			context.getSource().sendError(new LiteralText("§cКлючи выдаёт только владелец (OWNER), оператор или консоль."));
			return 0;
		}
		String name = StringArgumentType.getString(context, "ник");
		int amount = IntegerArgumentType.getInteger(context, "число");
		UUID uuid = id(context, name);
		if (uuid == null) {
			return 0;
		}
		int before = DonateCase.keys(uuid);
		switch (kind) {
			case SET:
				DonateCase.setKeys(uuid, name, amount);
				break;
			case REMOVE:
				DonateCase.setKeys(uuid, name, before - amount);
				break;
			default:
				DonateCase.addKeys(uuid, name, amount);
				break;
		}
		int now = DonateCase.keys(uuid);
		String text = "§6[Донат-кейс]§r ключи §e" + name + "§r: §a" + now
				+ (kind == Kind.GIVE ? "§r (+" + amount + ")" : "§r (было " + before + ")");
		if (player == null) {
			context.getSource().sendFeedback(new LiteralText(text), false);
		} else {
			player.sendMessage(new LiteralText(text), false);
		}
		ServerPlayerEntity target = context.getSource().getMinecraftServer().getPlayerManager().getPlayer(name);
		if (target != null && target != player) {
			target.sendMessage(new LiteralText("§6[Донат-кейс]§r твои ключи: §a" + now
					+ "§r — открой кейс правым кликом по нему!"), false);
		}
		return 1;
	}

	private static UUID id(CommandContext<ServerCommandSource> context, String name) {
		ServerPlayerEntity online = context.getSource().getMinecraftServer().getPlayerManager().getPlayer(name);
		if (online != null) {
			return online.getUuid();
		}
		UUID stored = com.example.randomblocks.RankManager.findByName(
				context.getSource().getMinecraftServer(), name);
		if (stored != null) {
			return stored;
		}
		context.getSource().sendError(new LiteralText("§cИгрок §e" + name + "§c не найден: пусть хотя бы раз зайдёт."));
		return null;
	}

	/** Блок, на который смотрит игрок (не дальше 6 блоков). */
	private static BlockPos lookingAt(ServerPlayerEntity player) {
		HitResult hit = player.raycast(6.0D, 1.0F, false);
		if (!(hit instanceof BlockHitResult) || hit.getType() != HitResult.Type.BLOCK) {
			return null;
		}
		return ((BlockHitResult) hit).getBlockPos();
	}
}
