package com.example.randomblocks.mixin;

import com.example.randomblocks.CombatTag;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ПВП-бой (1.13.0): как только игрок бьёт другого игрока — обоим включается «бой»
 * на 20 секунд (каждый удар продлевает).
 */
@Mixin(PlayerEntity.class)
public class PlayerEntityMixin {

	@Inject(method = "attack(Lnet/minecraft/entity/Entity;)V", at = @At("HEAD"))
	private void randomblocks$onAttack(Entity target, CallbackInfo ci) {
		if (!((Object) this instanceof ServerPlayerEntity)) {
			return;
		}
		if (!(target instanceof ServerPlayerEntity)) {
			return;
		}
		ServerPlayerEntity attacker = (ServerPlayerEntity) (Object) this;
		ServerPlayerEntity victim = (ServerPlayerEntity) target;
		if (!CombatTag.tag(attacker, victim)) {
			return;                       // креатив или зона спавна — бой не начинается
		}
		if (CombatTag.secondsLeft(victim) > 0) {
			attacker.sendMessage(new LiteralText("§c[ПВП]§r бой! Ещё " + CombatTag.secondsLeft(attacker)
					+ " с — в бою нельзя писать команды и нельзя выходить из игры."), true);
			victim.sendMessage(new LiteralText("§c[ПВП]§r тебя атаковал §e" + attacker.getEntityName()
					+ "§c! Ещё " + CombatTag.secondsLeft(victim) + " с."), true);
		}
	}
}
