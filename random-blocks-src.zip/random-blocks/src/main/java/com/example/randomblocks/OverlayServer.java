package com.example.randomblocks;

import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Identifier;

/**
 * Кастомные меню на экране — серверная половина.
 *
 * Никакого ванильного «сайдбара» (скорборд справа) нет: сервер отправляет клиенту свой пакет,
 * а мод на клиенте сам рисует:
 * <ul>
 *     <li><b>верхнюю плашку</b> — таймер до события «До события: N с» с полоской прогресса;</li>
 *     <li><b>нижнюю плашку</b> — таймер выдачи предметов над хотбаром («Предметы | Следующий через 4:59»);</li>
 * </ul>
 *
 * Игроки без мода ничего не теряют: вместо нижней плашки им по-прежнему приходит отсчёт
 * короткой строкой над инвентарём (action bar).
 *
 * Пакет {@code randomblocks:timer}: {@code kind}, {@code text}, {@code sub}, {@code percent}.
 */
public final class OverlayServer {

	/** Канал, который слушает клиентская часть мода. */
	public static final Identifier CHANNEL = new Identifier("randomblocks", "timer");

	/** Убрать обе плашки. */
	public static final int HIDE = 0;
	/** Верхняя плашка: таймер до события. */
	public static final int TIMER = 1;
	/** Верхняя плашка: идёт голосование. */
	public static final int VOTE = 2;
	/** Верхняя плашка: только что сработало событие. */
	public static final int FLASH = 3;
	/** Нижняя плашка: таймер выдачи предметов. */
	public static final int ITEM = 5;
	/** Убрать нижнюю плашку. */
	public static final int ITEM_HIDE = 6;

	private OverlayServer() {
	}

	/** Счётчик вызовов — чтобы диагностика (debugLog) не засоряла лог. */
	private static int calls;

	/** Отправить состояние меню всем игрокам, у которых есть мод на клиенте. */
	public static void send(MinecraftServer server, int kind, String text, String sub, float percent) {
		if (server == null) {
			return;
		}
		calls++;
		boolean debug = RandomBlocks.getConfig() != null && RandomBlocks.getConfig().debugLog && calls % 60 == 0;
		StringBuilder state = debug ? new StringBuilder("HUD send kind=").append(kind).append(", клиенты: ") : null;
		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			try {
				boolean can = ServerPlayNetworking.canSend(player, CHANNEL);
				if (state != null) {
					state.append(player.getEntityName()).append('=').append(can).append(' ');
				}
				if (!can) {
					continue;               // ванильный клиент — просто живёт без плашек
				}
				PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
				buf.writeInt(kind);
				buf.writeString(text == null ? "" : text, 262144);
				buf.writeString(sub == null ? "" : sub, 262144);
				buf.writeFloat(percent);
				ServerPlayNetworking.send(player, CHANNEL, buf);
			} catch (Throwable t) {
				// Fabric API может отсутствовать (мод умеет работать и без неё) — тогда плашек просто нет.
				if (RandomBlocks.getConfig() != null && RandomBlocks.getConfig().debugLog) {
					RandomBlocks.LOGGER.warn("HUD packet not sent to {}: {}", player.getEntityName(), t.toString());
				}
				return;
			}
		}
		if (state != null) {
			RandomBlocks.LOGGER.info("{}", state.toString());
		}
	}

	/** Есть ли у игрока мод на клиенте (то есть увидит ли он кастомные меню). */
	public static boolean hasMod(MinecraftServer server, ServerPlayerEntity player) {
		try {
			return ServerPlayNetworking.canSend(player, CHANNEL);
		} catch (Throwable t) {
			return false;
		}
	}

	/** Убрать плашки с экрана. */
	public static void hide(MinecraftServer server) {
		send(server, HIDE, "", "", 0.0F);
	}

	/** Таймер до следующего события (верхняя плашка). */
	public static void timer(MinecraftServer server, int secondsLeft, int totalSeconds, String extra) {
		float percent = totalSeconds <= 0 ? 0.0F : (float) secondsLeft / (float) totalSeconds;
		send(server, TIMER, "§6Случайные события  §8|  §fДо события: §e" + secondsLeft + " §7с"
				+ (extra == null ? "" : extra), "", clamp(percent));
	}

	/** Вспышка «событие сработало» — держится пару секунд, потом снова таймер. */
	public static void flash(MinecraftServer server, String eventName) {
		send(server, FLASH, "§c§l➤ СОБЫТИЕ!  §r§f" + eventName, "", 0.0F);
	}

	/** То же, но с готовым текстом (используется при повторной отрисовке вспышки). */
	public static void flashText(MinecraftServer server, String text) {
		send(server, FLASH, text, "", 0.0F);
	}

	/** Таймер голосования (верхняя плашка). */
	public static void vote(MinecraftServer server, int secondsLeft, int totalSeconds, int voted) {
		float percent = totalSeconds <= 0 ? 0.0F : (float) secondsLeft / (float) totalSeconds;
		send(server, VOTE, "§aГолосование  §8|  §fОсталось: §e" + secondsLeft + " §7с  §8|  §fГолосов: §e" + voted,
				"", clamp(percent));
	}

	/**
	 * Таймер выдачи предметов — как и раньше, компактная строка над панелью инвентаря.
	 * Короткий текст уходит и владельцам мода (клиент рисует его уменьшенным), и всем остальным
	 * (ванильная строка над инвентарём), поэтому вид одинаковый — только размер у мода меньше.
	 */
	public static void itemTimer(MinecraftServer server, int secondsLeft, int totalSeconds, String lastItem) {
		String text = "§b[Random Blocks]§r предмет через §e" + ItemTimerManager.formatTime(secondsLeft);
		// Владельцам мода: короткая строка для маленькой отрисовки над хотбаром.
		send(server, ITEM, text, "", 0.0F);
		// Ванильным клиентам (без мода) — привычная строка над панелью инвентаря.
		actionBarForVanilla(server, text);
	}

	/** Убрать нижнюю плашку (таймер предметов выключили). */
	public static void hideItemTimer(MinecraftServer server) {
		send(server, ITEM_HIDE, "", "", 0.0F);
		actionBarForVanilla(server, "");
	}

	private static void actionBarForVanilla(MinecraftServer server, String text) {
		if (server == null) {
			return;
		}
		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			if (!hasMod(server, player)) {
				player.sendMessage(new LiteralText(text), true);
			}
		}
	}

	private static float clamp(float value) {
		return Math.max(0.0F, Math.min(1.0F, value));
	}
}
