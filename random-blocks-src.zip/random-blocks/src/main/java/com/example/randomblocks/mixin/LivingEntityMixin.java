package com.example.randomblocks.mixin;

import com.example.randomblocks.CombatTag;
import com.example.randomblocks.RandomBlocks;
import com.example.randomblocks.Stats;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Счётчик смертей и убийств (1.13.0).
 *
 * <p>Смерти считаются любые (падение, лава, мобы, ПВП), а убийства — только по игрокам:
 * если игрока убил другой игрок, убийца получает +1 к «У».</p>
 */
@Mixin(LivingEntity.class)
public class LivingEntityMixin {

	/**
	 * Бой включается и от дальнего урона (лук, взрыв от игрока) — не только от удара рукой:
	 * «ударил игрока» = любой урон, который нанёс другой игрок.
	 */
	@Inject(method = "damage(Lnet/minecraft/entity/damage/DamageSource;F)Z", at = @At("HEAD"))
	private void randomblocks$tagCombat(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
		if (!((Object) this instanceof ServerPlayerEntity)) {
			return;
		}
		if (source.getAttacker() instanceof ServerPlayerEntity) {
			ServerPlayerEntity victim = (ServerPlayerEntity) (Object) this;
			ServerPlayerEntity attacker = (ServerPlayerEntity) source.getAttacker();
			if (attacker != victim) {
				CombatTag.tag(attacker, victim);       // false, если кто-то в креативе или в зоне спавна
			}
		}
	}

	// Учёт смертей перенесён в ServerPlayerEntityMixin (инъекция в onDeath в рантайме не срабатывает).

}
