package com.example.randomblocks;

import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Фото-бейджи привилегий (начиная с 1.12.0).
 *
 * <p>Вместо слова «OWNER» в чате, табе и над головой рисуется картинка из jar мода.
 * Механика — обычный ванильный шрифт: в моде лежит {@code assets/randomblocks/font/badges.json},
 * который описывает растровый шрифт {@code randomblocks:badges} с одной картинкой
 * {@code assets/randomblocks/textures/font/rank_badges.png}. В этой картинке девять ячеек —
 * по одной на привилегию, в порядке {@link Rank} (PLAYER — первая, OWNER — последняя).
 * Текст с этим шрифтом клиент рисует как картинку, а не как буквы.</p>
 *
 * <p>Какая привилегия со своей картинкой — написано в {@code assets/randomblocks/rank_badges.txt}
 * (по одному имени на строку). Пользователь присылает фото → кладём файл в
 * {@code /home/user/badges/<привилегия>.png} → скрипт {@code work/build_badges.py} пересобирает
 * и картинку, и этот список.</p>
 *
 * <p>Если картинки нет (или владелец выключил опцию {@code rankBadges}) — используется
 * обычный текстовый префикс, как в 1.11.x.</p>
 */
public final class RankBadges {

	/** Идентификатор нашего растрового шрифта из {@code assets/randomblocks/font/badges.json}. */
	public static final Identifier FONT = new Identifier("randomblocks", "badges");

	/** Первый знак шрифта: нулевая привилегия — U+E000, дальше по порядку. */
	private static final char BASE = '\uE000';

	private static final String LIST = "/assets/randomblocks/rank_badges.txt";

	private static Set<String> withImage;

	private RankBadges() {
	}

	/** Включены ли бейджи (опция {@code rankBadges} и включённые привилегии). */
	public static boolean enabled() {
		ModConfig config = RandomBlocks.getConfig();
		return config != null && config.ranksEnabled && config.rankBadges;
	}

	/** Есть ли у привилегии своя картинка (ищем имя в списке ресурсов мода). */
	public static boolean hasImage(Rank rank) {
		if (!enabled()) {
			return false;
		}
		Set<String> names = withImage;
		if (names == null) {
			withImage = names = loadNames();
		}
		return names.contains(rank.name);
	}

	/** Знак нашего шрифта для этой привилегии. */
	public static char glyph(Rank rank) {
		return (char) (BASE + rank.ordinal());
	}

	/**
	 * Префикс игрока: «бейдж-картинка + пробел» либо обычное «§4§lOWNER §f».
	 * Готовый Text — его можно ставить и в команду таба, и в строку чата.
	 */
	public static MutableText prefix(Rank rank) {
		MutableText badge = hasImage(rank) ? badge(rank) : null;
		if (badge == null) {
			return new LiteralText(rank.prefix() + " §f");
		}
		badge.append(new LiteralText(" §f"));
		return badge;
	}

	/**
	 * Текст-картинка: знак нашего шрифта со стилем {@code font}.
	 *
	 * <p>Важно: собрать стиль напрямую ({@code Style.EMPTY.withFont(...)}) нельзя — метода
	 * {@code withFont} в серверном jar нет (он есть только в клиентском), и сервер падал бы
	 * с {@code NoSuchMethodError}, как когда-то на {@code /feed}. Зато серверный сериализатор
	 * текста умеет «font» из JSON — этим и пользуемся: строка разбирается в обычный Text,
	 * а клиент, получив стиль с шрифтом, рисует вместо знака картинку.</p>
	 */
	private static MutableText badge(Rank rank) {
		String json = "{\"text\":\"\\u" + String.format("%04X", (int) glyph(rank))
				+ "\",\"font\":\"" + FONT + "\"}";
		try {
			return Text.Serializer.fromJson(json);
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("rank badge text not built: {}", t.toString());
			return null;
		}
	}

	/** Список привилегий с картинками — из ресурса {@code rank_badges.txt}. */
	private static Set<String> loadNames() {
		Set<String> names = new HashSet<>();
		try (InputStream in = RankBadges.class.getResourceAsStream(LIST)) {
			if (in == null) {
				return names;
			}
			BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
			String line;
			while ((line = reader.readLine()) != null) {
				line = line.trim();
				if (!line.isEmpty() && !line.startsWith("#")) {
					names.add(line.toUpperCase(Locale.ROOT));
				}
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("rank badges list not read: {}", t.toString());
		}
		return names;
	}
}
