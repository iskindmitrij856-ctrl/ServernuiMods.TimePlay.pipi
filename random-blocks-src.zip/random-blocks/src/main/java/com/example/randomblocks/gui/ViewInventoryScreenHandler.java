package com.example.randomblocks.gui;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Просмотр чужого инвентаря для {@code /invsee}.
 *
 * <p>Обычный сундук на 6 рядов (54 слота — это инвентарь игрока: 36 слотов, броня и левая рука),
 * но клики по слотам игнорируются: <b>смотреть можно, взять нельзя</b>. У OWNER окно открывается
 * в обычном, «живом» режиме — он может и взять предмет (см. {@link #editable}).</p>
 *
 * <p>Содержимое окна сервер обновляет сам: {@code ServerPlayerEntity.tick()} каждый тик зовёт
 * {@code currentScreenHandler.sendContentUpdates()}, поэтому изменения в чужом инвентаре видно
 * сразу, без всяких костылей.</p>
 */
public class ViewInventoryScreenHandler extends GenericContainerScreenHandler {

	private final boolean editable;

	public ViewInventoryScreenHandler(int syncId, PlayerInventory viewerInventory, Inventory target, boolean editable) {
		// Важно: окну на 6 рядов нужен инвентарь ровно на 54 слота. У инвентаря игрока их 41,
		// поэтому подставляем прокси-«вид» (см. PlayerInventoryView), иначе checkSize падает.
		super(ScreenHandlerType.GENERIC_9X6, syncId, viewerInventory,
				target instanceof PlayerInventory ? new PlayerInventoryView((PlayerInventory) target) : target, 6);
		this.editable = editable;
	}

	/** Можно ли брать предметы (только OWNER) — иначе окно строго «только смотреть». */
	public boolean isEditable() {
		return editable;
	}

	/** Окно не должно закрываться само: игрок смотрит чужой инвентарь, а не свой. */
	@Override
	public boolean canUse(PlayerEntity player) {
		return true;
	}

	/** Просмотр — «только чтение»: любой клик возвращает пустоту и ничего не меняет. */
	@Override
	public ItemStack onSlotClick(int slotId, int clickData, SlotActionType actionType, PlayerEntity player) {
		if (!editable) {
			return ItemStack.EMPTY;
		}
		return super.onSlotClick(slotId, clickData, actionType, player);
	}
}
