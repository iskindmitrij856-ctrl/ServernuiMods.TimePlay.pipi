package com.example.randomblocks.gui;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;

/**
 * Окно меню привилегий {@code /donate} (1.13.0).
 *
 * <p>Обычный сундук 9×6, но взять из него ничего нельзя: это витрина. Клики обрабатываются в
 * {@code ServerPlayNetworkHandlerMixin} — по ним открывается подсказка о привилегии и цене.</p>
 */
public class DonateScreenHandler extends ViewInventoryScreenHandler {

	public DonateScreenHandler(int syncId, PlayerInventory playerInventory, Inventory target) {
		super(syncId, playerInventory, target, false);
	}
}
