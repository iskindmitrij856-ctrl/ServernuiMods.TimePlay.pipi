package com.example.randomblocks.mixin;

import com.example.randomblocks.Bans;
import com.example.randomblocks.CombatTag;
import com.example.randomblocks.Economy;
import com.example.randomblocks.RandomBlocks;
import com.example.randomblocks.Sidebar;
import com.example.randomblocks.Stats;
import net.minecraft.network.MessageType;
import net.minecraft.text.TranslatableText;
import java.util.UUID;
import net.minecraft.network.ClientConnection;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Вход и выход игроков (1.13.0):
 *
 * <ul>
 *     <li><b>бан:</b> забаненного сразу отключаем на входе, с причиной и остатком срока;</li>
 *     <li><b>бой:</b> если игрок выходит в бою — смерть и потеря вещей (см. {@link CombatTag});</li>
 *     <li><b>экономика/статистика/скорборд:</b> заводим записи и обновляем сайдбар.</li>
 * </ul>
 */
@Mixin(PlayerManager.class)
public class PlayerManagerMixin {

	@Inject(method = "onPlayerConnect(Lnet/minecraft/network/ClientConnection;Lnet/minecraft/server/network/ServerPlayerEntity;)V",
			at = @At("HEAD"), cancellable = true)
	private void randomblocks$onConnect(ClientConnection connection, ServerPlayerEntity player, CallbackInfo ci) {
		try {
			Bans.Entry entry = Bans.active(player.getEntityName());
			if (entry != null) {
				connection.disconnect(new net.minecraft.text.LiteralText(
						"§cТы забанен на этом сервере.\n§7Причина: §f" + entry.reason
								+ "\n§7Осталось: §f" + Bans.left(entry)));
				RandomBlocks.LOGGER.info("Banned player {} tried to join", player.getEntityName());
				ci.cancel();
				return;
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("ban check failed: {}", t.toString());
		}
	}

	/**
	 * Достижения и смерти в чат не пишутся (просьба владельца).
	 *
	 * <p>И то, и другое ваниль отправляет одним и тем же широковещательным сообщением, но текст
	 * у них «переводной» (TranslatableText): смерти — ключи {@code death.*}, достижения —
	 * {@code chat.type.advancement.*}. Поэтому фильтр смотрит на ключ, а не на игрока: чат самого
	 * мода, объявления и обычные сообщения остаются нетронутыми.</p>
	 */
	@Inject(method = "broadcastChatMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/MessageType;Ljava/util/UUID;)V",
			at = @At("HEAD"), cancellable = true)
	private void randomblocks$muteDeathAndAdvancement(Text message, MessageType type, UUID sender,
			CallbackInfo ci) {
		try {
			if (!(message instanceof TranslatableText)) {
				return;
			}
			String key = ((TranslatableText) message).getKey();
			if (key == null) {
				return;
			}
			if (key.startsWith("death.") && !RandomBlocks.getConfig().announceDeaths) {
				ci.cancel();
				return;
			}
			if (key.startsWith("chat.type.advancement") && !RandomBlocks.getConfig().announceAdvancements) {
				ci.cancel();
			}
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("chat filter failed: {}", t.toString());
		}
	}

	@Inject(method = "remove(Lnet/minecraft/server/network/ServerPlayerEntity;)V", at = @At("HEAD"))
	private void randomblocks$onRemove(ServerPlayerEntity player, CallbackInfo ci) {
		try {
			CombatTag.onLogout(player);            // выход в бою = смерть и потеря вещей
			Sidebar.onQuit(player.getUuid());
			Economy.save();
			Stats.save();
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("quit handling failed: {}", t.toString());
		}
	}
}
