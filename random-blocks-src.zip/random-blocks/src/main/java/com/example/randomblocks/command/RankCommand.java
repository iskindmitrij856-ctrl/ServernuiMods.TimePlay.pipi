package com.example.randomblocks.command;

import com.example.randomblocks.ChatRouter;
import com.example.randomblocks.Permissions;
import com.example.randomblocks.RandomBlocks;
import com.example.randomblocks.Rank;
import com.example.randomblocks.RankManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;

import java.util.UUID;

/**
 * Команды привилегий — как в LuckPerms, только это мод:
 *
 * <ul>
 *     <li>{@code /rank user <ник> info} — какая у игрока привилегия;</li>
 *     <li>{@code /rank user <ник> parent set <привилегия>} — выдать (аналог {@code lp user X parent set Y});</li>
 *     <li>{@code /rank user <ник> parent add <привилегия>} — то же самое (иерархия линейная);</li>
 *     <li>{@code /rank user <ник> parent clear} — снять, вернуть PLAYER;</li>
 *     <li>{@code /rank set <ник> <привилегия>} — короткая форма выдачи;</li>
 *     <li>{@code /rank [ник]} — своя привилегия;</li>
 *     <li>{@code /rank list} — вся иерархия; {@code /rank players} — кому что выдано;</li>
 *     <li>{@code /rank reload} — перечитать файл привилегий.</li>
 * </ul>
 *
 * Те же команды доступны и как {@code /lp ...} — для привычки к LuckPerms.
 */
public final class RankCommand {

	private RankCommand() {
	}

	public static void register() {
		tryRegister("rank");
		tryRegister("lp");
	}

	private static void tryRegister(String root) {
		try {
			CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> registerTree(dispatcher, root));
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("Rank command /{} not registered: {}", root, t.toString());
		}
	}

	private static void registerTree(CommandDispatcher<ServerCommandSource> dispatcher, String root) {
		dispatcher.register(CommandManager.literal(root)
				.executes(context -> own(context))
				.then(CommandManager.literal("help")
						.executes(context -> help(context, root)))
				.then(CommandManager.literal("list")
						.executes(context -> list(context)))
				.then(CommandManager.literal("players")
						.executes(context -> players(context)))
				.then(CommandManager.literal("reload")
						.requires(RankCommand::mayTryToManage)
						.executes(context -> reload(context)))
				.then(CommandManager.literal("set")
						.requires(RankCommand::mayTryToManage)
						.then(CommandManager.argument("ник", StringArgumentType.word())
								.then(CommandManager.argument("привилегия", StringArgumentType.word())
										.executes(context -> set(context, context)))))

				// /rank info [ник]
				.then(CommandManager.literal("info")
						.executes(context -> info(context, null))
						.then(CommandManager.argument("ник", StringArgumentType.word())
								.executes(context -> info(context, StringArgumentType.getString(context, "ник")))))

				// /rank user <ник> info | parent set <ранг> | parent add <ранг> | parent clear
				.then(CommandManager.literal("user")
						.then(CommandManager.argument("ник", StringArgumentType.word())
								.then(CommandManager.literal("info")
										.executes(context -> info(context, StringArgumentType.getString(context, "ник"))))
								.then(CommandManager.literal("parent")
										.then(CommandManager.literal("set")
												.then(CommandManager.argument("привилегия", StringArgumentType.word())
														.executes(context -> set(context, context))))
										.then(CommandManager.literal("add")
												.then(CommandManager.argument("привилегия", StringArgumentType.word())
														.executes(context -> set(context, context))))
										.then(CommandManager.literal("clear")
												.executes(context -> clear(context)))
										.then(CommandManager.literal("remove")
												.then(CommandManager.argument("привилегия", StringArgumentType.word())
														.executes(context -> remove(context, context)))))))
		);
	}

	// ------------------------------------------------------------------

	private static int help(CommandContext<ServerCommandSource> context, String root) {
		ServerCommandSource source = context.getSource();
		source.sendFeedback(new LiteralText("§6[Привилегии]§r команды (как в LuckPerms, только мод):"), false);
		source.sendFeedback(new LiteralText("§e/" + root + " user <ник> parent set <привилегия>§r — выдать"), false);
		source.sendFeedback(new LiteralText("§e/" + root + " user <ник> parent clear§r — снять (вернуть PLAYER)"), false);
		source.sendFeedback(new LiteralText("§e/" + root + " set <ник> <привилегия>§r — короткая форма"), false);
		source.sendFeedback(new LiteralText("§e/" + root + " user <ник> info§r — что выдано игроку"), false);
		source.sendFeedback(new LiteralText("§e/" + root + " list§r / §e/" + root + " players§r — иерархия и список игроков"), false);
		source.sendFeedback(new LiteralText("§7Названия: " + rankNames() + " §7(или номера 0…7, ∞ = OWNER)"), false);
		source.sendFeedback(new LiteralText("§7Команды привилегий: §e/rtp§7, §e/craft§7, §e/hat§7, §e/feed§7, §e/rtpfar§7, "
				+ "§e/ec§7, §e/ext§7, §e/clear§7, §e/repair§7, §e/near§7, §e/heal§7, §e/invsee§7, §e/broadcast§7, "
				+ "§e/lightning§7, §e/rtpnear§7, §e/fly§7, §e/grant§7, §e/sun§7, §e/rain§7, §e/day§7, §e/night"), false);
		source.sendFeedback(new LiteralText("§7Полный список своей привилегии: §e/" + root), false);
		return 1;
	}

	/** Кто вообще может пытаться: оператор сервера или игрок с привилегией HERO и выше. */
	private static boolean mayTryToManage(ServerCommandSource source) {
		if (source.hasPermissionLevel(2)) {
			return true;
		}
		ServerPlayerEntity player = issuer(source);
		return player != null && Permissions.canManageAny(player);
	}

	private static ServerPlayerEntity issuer(ServerCommandSource source) {
		return source.getEntity() instanceof ServerPlayerEntity ? (ServerPlayerEntity) source.getEntity() : null;
	}

	/**
	 * Проверка лестницы: выдавать и снимать можно только привилегии НИЖЕ своей
	 * (OWNER и оператор сервера — любые). Возвращает true, если можно продолжать.
	 */
	private static boolean checkIssuer(CommandContext<ServerCommandSource> context, Rank target) {
		ServerCommandSource source = context.getSource();
		if (source.hasPermissionLevel(2)) {
			return true;
		}
		ServerPlayerEntity player = issuer(source);
		if (player == null) {
			source.sendError(new LiteralText("§cИз консоли привилегии выдаёт только оператор сервера."));
			return false;
		}
		if (!Permissions.canManageAny(player)) {
			source.sendError(new LiteralText("§cВыдавать привилегии может привилегия §eHERO§c и выше. У тебя §e"
					+ RankManager.rankOf(player).name + "§c."));
			return false;
		}
		if (!Permissions.canManage(player, target)) {
			source.sendError(new LiteralText("§cНельзя выдавать привилегию §e" + target.name
					+ "§c: она не ниже твоей (§e" + RankManager.rankOf(player).name
					+ "§c). Можно только ниже своей."));
			return false;
		}
		return true;
	}

	private static String rankNames() {
		StringBuilder sb = new StringBuilder();
		for (Rank rank : Rank.values()) {
			if (sb.length() > 0) {
				sb.append("§7, ");
			}
			sb.append(rank.prefix());
		}
		return sb.toString();
	}

	private static int list(CommandContext<ServerCommandSource> context) {
		ServerCommandSource source = context.getSource();
		source.sendFeedback(new LiteralText("§6[Привилегии]§r иерархия (сверху — старше):"), false);
		Rank[] ranks = Rank.values();
		for (int i = ranks.length - 1; i >= 0; i--) {
			Rank rank = ranks[i];
			String marker = rank == Rank.OWNER ? "§7(∞)" : "§7(" + (rank.weight) + ")";
			source.sendFeedback(new LiteralText(" " + marker + " " + rank.prefix()), false);
		}
		source.sendFeedback(new LiteralText("§7Своя привилегия: §e/rank§7, выдать — §e/rank user <ник> parent set <привилегия>§7."), false);
		return 1;
	}

	private static int players(CommandContext<ServerCommandSource> context) {
		ServerCommandSource source = context.getSource();
		java.util.List<String> granted = RankManager.granted();
		if (granted.isEmpty()) {
			source.sendFeedback(new LiteralText("§6[Привилегии]§r пока всем выдана только §7§lPLAYER§r."), false);
			return 1;
		}
		source.sendFeedback(new LiteralText("§6[Привилегии]§r выдано (" + granted.size() + "):"), false);
		for (String line : granted) {
			source.sendFeedback(new LiteralText(" §7· §r" + line), false);
		}
		return 1;
	}

	private static int reload(CommandContext<ServerCommandSource> context) {
		RankManager.load();
		context.getSource().sendFeedback(new LiteralText("§6[Привилегии]§r файл привилегий перечитан."), false);
		return 1;
	}

	private static int own(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		Rank rank = RankManager.rankOf(player);
		context.getSource().sendFeedback(new LiteralText("§6[Привилегии]§r твоя привилегия: " + rank.prefix()
				+ " §7(в табе и над головой — «" + rank.prefix() + " §f" + player.getEntityName() + "§7»)"), false);
		context.getSource().sendFeedback(new LiteralText("§7точек дома: §e" + rank.homesText()
				+ "§7, перезарядок нет только у OWNER"), false);
		String available = Permissions.availableText(player);
		context.getSource().sendFeedback(new LiteralText("§7твои команды: §e" + available), false);
		context.getSource().sendFeedback(new LiteralText(ChatRouter.legend()), false);
		return 1;
	}

	private static int info(CommandContext<ServerCommandSource> context, String name) throws CommandSyntaxException {
		ServerCommandSource source = context.getSource();
		ServerPlayerEntity target = name == null ? source.getPlayer() : source.getMinecraftServer().getPlayerManager().getPlayer(name);
		UUID uuid;
		String display;
		if (target != null) {
			uuid = target.getUuid();
			display = target.getEntityName();
		} else {
			String wanted = name == null ? "" : name;
			uuid = RankManager.findByName(source.getMinecraftServer(), wanted);
			if (uuid == null) {
				source.sendError(new LiteralText("§cИгрок §e" + wanted + "§c не найден: он не в сети и привилегий ему раньше не выдавали."));
				return 0;
			}
			display = RankManager.storedName(uuid);
			if (display.isEmpty()) {
				display = wanted;
			}
		}
		Rank rank = RankManager.rankOf(uuid);
		source.sendFeedback(new LiteralText("§6[Привилегии]§r " + rank.decorate(display) + " §7— привилегия "
				+ rank.prefix() + " §7(уровень " + (rank == Rank.OWNER ? "∞" : String.valueOf(rank.weight)) + ")"), false);
		return 1;
	}

	private static int set(CommandContext<ServerCommandSource> context, CommandContext<ServerCommandSource> ignored)
			throws CommandSyntaxException {
		return apply(context, StringArgumentType.getString(context, "ник"), StringArgumentType.getString(context, "привилегия"));
	}

	private static int apply(CommandContext<ServerCommandSource> context, String name, String rankName) throws CommandSyntaxException {
		ServerCommandSource source = context.getSource();
		Rank rank = Rank.byName(rankName);
		if (rank == null) {
			source.sendError(new LiteralText("§cНе знаю привилегию §e" + rankName + "§c. Есть: " + rankNames()));
			return 0;
		}
		ServerPlayerEntity online = source.getMinecraftServer().getPlayerManager().getPlayer(name);
		UUID uuid = online != null ? online.getUuid() : RankManager.findByName(source.getMinecraftServer(), name);
		if (uuid == null) {
			source.sendError(new LiteralText("§cИгрок §e" + name + "§c не найден: пусть хотя бы раз зайдёт на сервер."));
			return 0;
		}
		if (!checkIssuer(context, rank)) {
			return 0;
		}
		Rank previous = RankManager.setRank(uuid, online != null ? online.getEntityName() : RankManager.storedName(uuid), rank);
		String targetName = online != null ? online.getEntityName() : RankManager.storedName(uuid);

		if (previous == rank) {
			source.sendFeedback(new LiteralText("§6[Привилегии]§r у " + rank.decorate(targetName) + " §7уже эта привилегия."), false);
			return 1;
		}
		if (online != null) {
			RankManager.applySafe(online, rank);            // видно сразу, без ожидания тика
			online.sendMessage(new LiteralText("§6[Привилегии]§r тебе выдана привилегия " + rank.prefix()
					+ " §7(было: " + previous.prefix() + "§7)"), false);
		}
		source.sendFeedback(new LiteralText("§6[Привилегии]§r " + rank.decorate(targetName)
				+ " §7— выдана привилегия " + rank.prefix() + " §7(было: " + previous.prefix() + "§7)"), true);
		RandomBlocks.LOGGER.info("Rank: {} set to {} (was {}) by {}", targetName, rank.name, previous.name,
				source.getName());
		return 1;
	}

	private static int clear(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		return apply(context, StringArgumentType.getString(context, "ник"), Rank.PLAYER.name);
	}

	private static int remove(CommandContext<ServerCommandSource> context, CommandContext<ServerCommandSource> ignored)
			throws CommandSyntaxException {
		String name = StringArgumentType.getString(context, "ник");
		String rankName = StringArgumentType.getString(context, "привилегия");
		Rank rank = Rank.byName(rankName);
		if (rank == null) {
			context.getSource().sendError(new LiteralText("§cНе знаю привилегию §e" + rankName + "§c."));
			return 0;
		}
		UUID uuid = RankManager.findByName(context.getSource().getMinecraftServer(), name);
		if (uuid == null) {
			context.getSource().sendError(new LiteralText("§cИгрок §e" + name + "§c не найден."));
			return 0;
		}
		if (!checkIssuer(context, rank)) {
			return 0;
		}
		if (RankManager.rankOf(uuid) != rank) {
			context.getSource().sendFeedback(new LiteralText("§6[Привилегии]§r у игрока не эта привилегия — снимать нечего."), false);
			return 1;
		}
		return apply(context, name, Rank.PLAYER.name);
	}
}
