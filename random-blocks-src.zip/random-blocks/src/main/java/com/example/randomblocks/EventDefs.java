package com.example.randomblocks;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.Angerable;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.explosion.Explosion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.function.Supplier;

/**
 * Третий «мод»: список случайных событий, которые запускаются голосованием в чате.
 *
 * События бывают положительные (подарки, благословения), отрицательные (голод, молнии,
 * нашествие зомби) и смешанные (лотерея телепортов, хаос блоков). Каждое событие — это
 * пара «название + описание для голосования + что оно делает со всеми игроками онлайн».
 */
public final class EventDefs {

	/** 1 секунда в тиках. */
	private static final int SEC = 20;
	/** Минута — обычный срок для событий-эффектов (в 1.5.0 длинные события длятся именно столько). */
	private static final int MIN1 = 60 * SEC;

	public enum Kind {
		POSITIVE("§a+", "положительное"),
		NEGATIVE("§c-", "отрицательное"),
		MIXED("§e~", "смешанное");

		public final String tag;
		public final String label;

		Kind(String tag, String label) {
			this.tag = tag;
			this.label = label;
		}
	}

	public interface Action {
		void run(MinecraftServer server, ModConfig cfg);
	}

	public static final class Def {
		public final String id;
		public final String name;
		public final String description;
		public final Kind kind;
		/** Для Kind.MIXED: true = по характеру это «плохое» событие, false = «хорошее». */
		public final boolean mixedBad;
		public final Action action;

		Def(String id, String name, String description, Kind kind, Action action) {
			this(id, name, description, kind, false, action);
		}

		Def(String id, String name, String description, Kind kind, boolean mixedBad, Action action) {
			this.id = id;
			this.name = name;
			this.description = description;
			this.kind = kind;
			this.mixedBad = mixedBad;
			this.action = action;
		}

		/** Идёт ли событие в «плохую» корзину при отборе (по умолчанию 60% плохих / 40% хороших). */
		public boolean isBad() {
			return kind == Kind.NEGATIVE || (kind == Kind.MIXED && mixedBad);
		}
	}

	private static List<Def> all;

	private EventDefs() {
	}

	public static List<Def> all() {
		if (all == null) {
			all = build();
		}
		return all;
	}

	public static Def byId(String id) {
		if (id == null) {
			return null;
		}
		String trimmed = id.trim();
		for (Def def : all()) {
			if (def.id.equalsIgnoreCase(trimmed)) {
				return def;
			}
		}
		return null;
	}

	/**
	 * Одно случайное событие для автоматического режима — с перевесом по «плохости».
	 *
	 * По умолчанию 60% — плохое событие и 40% — хорошее/нейтральное
	 * (настраивается в конфиге: eventNegativeChance). Смешанные события (Kind.MIXED)
	 * раскладываются по своему характеру через mixedBad. Если отрицательные события
	 * запрещены (eventAllowNegative = false), плохие просто не участвуют.
	 */
	public static Def randomWeighted(Random random, ModConfig cfg) {
		List<Def> bad = new ArrayList<>();
		List<Def> good = new ArrayList<>();
		for (Def def : all()) {
			if (def.isBad()) {
				if (cfg.eventAllowNegative) {
					bad.add(def);
				}
			} else {
				good.add(def);
			}
		}
		boolean wantBad = !bad.isEmpty()
				&& (good.isEmpty() || random.nextDouble() < cfg.eventNegativeChance);
		List<Def> pool = wantBad ? bad : good;
		if (pool.isEmpty()) {
			pool = all();
		}
		return pool.isEmpty() ? null : pool.get(random.nextInt(pool.size()));
	}

	/** Пачка одинаковых мобов вокруг игрока (обычные, без агрессии). */
	private static void spawnPack(ServerPlayerEntity player, Random random, EntityType<?> type, int count,
			double base, double spread) {
		ServerWorld world = player.getServerWorld();
		for (int i = 0; i < count; i++) {
			double[] spot = ringSpot(player, random, base, spread);
			spawnMob(world, type, spot[0], player.getY(), spot[1], random, player);
		}
	}

	/**
	 * Пачка мобов, которые сразу настроены против игрока. Работает для тех, у кого есть «злость»
	 * (волки, пчёлы): выставляем и цель, и anger-таймер, иначе они бы просто стояли рядом.
	 */
	private static void spawnAngryPack(ServerPlayerEntity player, Random random, EntityType<?> type, int count,
			double base, double spread) {
		ServerWorld world = player.getServerWorld();
		for (int i = 0; i < count; i++) {
			double[] spot = ringSpot(player, random, base, spread);
			MobEntity mob = spawnMob(world, type, spot[0], player.getY(), spot[1], random, player);
			if (mob instanceof Angerable) {
				Angerable angerable = (Angerable) mob;
				angerable.setAngryAt(player.getUuid());
				angerable.setAngerTime(60 * SEC);
			}
		}
	}

	/**
	 * Место на земле рядом с игроком: воздух, под которым есть твёрдый блок.
	 * Нужно событиям, которые ставят блоки (огонь, паутина, цветы, шерсть).
	 */
	private static BlockPos groundSpot(ServerWorld world, ServerPlayerEntity player, Random random,
			double base, double spread) {
		double[] spot = ringSpot(player, random, base, spread);
		int x = (int) Math.floor(spot[0]);
		int z = (int) Math.floor(spot[1]);
		int y = (int) Math.floor(player.getY());
		for (int dy = 1; dy >= -2; dy--) {
			BlockPos pos = new BlockPos(x, y + dy, z);
			if (world.isAir(pos) && !world.isAir(pos.down())) {
				return pos;
			}
		}
		return null;
	}

	/** Случайные варианты для голосования (все — разные). */
	public static List<Def> randomOptions(int count, Random random, ModConfig cfg) {
		List<Def> pool = new ArrayList<>();
		for (Def def : all()) {
			if (!cfg.eventAllowNegative && def.kind == Kind.NEGATIVE) {
				continue;
			}
			pool.add(def);
		}
		Collections.shuffle(pool, random);
		if (pool.size() > count) {
			pool = new ArrayList<>(pool.subList(0, count));
		}
		return pool;
	}

	public static void run(Def def, MinecraftServer server, ModConfig cfg) {
		def.action.run(server, cfg);
	}

	// ------------------------------------------------------------------
	//  Сами события
	// ------------------------------------------------------------------

	private static List<Def> build() {
		List<Def> list = new ArrayList<>();

		// ---------------- положительные ----------------

		list.add(new Def("xp_blessing", "Благословение опыта", "+25 уровней каждому", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						player.addExperienceLevels(25);
						player.sendMessage(new LiteralText("§6[Событие]§r тебе начислено §e25 уровней"), false);
					}
					broadcast(server, "§aОпыт льётся рекой!");
				}));

		list.add(new Def("full_heal", "Полное исцеление", "здоровье и еда восстановлены, плохие эффекты сняты", Kind.POSITIVE,
				(server, cfg) -> {
					StatusEffect[] bad = {StatusEffects.POISON, StatusEffects.WITHER, StatusEffects.WEAKNESS,
							StatusEffects.SLOWNESS, StatusEffects.BLINDNESS, StatusEffects.HUNGER,
							StatusEffects.LEVITATION, StatusEffects.NAUSEA, StatusEffects.MINING_FATIGUE,
							StatusEffects.UNLUCK, StatusEffects.BAD_OMEN};
					for (ServerPlayerEntity player : players(server)) {
						player.setHealth(player.getMaxHealth());
						player.getHungerManager().setFoodLevel(20);
						player.getHungerManager().add(0, 1.0F);
						for (StatusEffect effect : bad) {
							player.removeStatusEffect(effect);
						}
					}
					broadcast(server, "§aВсе раны и болезни исчезли!");
				}));

		list.add(new Def("hero_hour", "Герой часа", "регенерация II, скорость II и сопротивление на 60 секунд", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.REGENERATION, 1200, 1);
						effect(player, StatusEffects.SPEED, 1200, 1);
						effect(player, StatusEffects.RESISTANCE, 1200, 0);
					}
					broadcast(server, "§aСилы героя наполняют всех на минуту!");
				}));

		// ---------------- отрицательные ----------------

		list.add(new Def("sudden_hunger", "Внезапный голод", "шкала еды падает в ноль и нападает голод", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						player.getHungerManager().setFoodLevel(0);
						player.getHungerManager().add(0, 0.0F);
						effect(player, StatusEffects.HUNGER, 20 * SEC, 0);
						player.sendMessage(new LiteralText("§6[Событие]§r живот сводит от голода!"), false);
					}
					broadcast(server, "§cНа всех напал зверский голод!");
				}));

		list.add(new Def("poison_fog", "Ядовитый туман", "отравление II на 15 секунд", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.POISON, 300, 1);
					}
					broadcast(server, "§cВокруг разлился ядовитый туман!");
				}));

		list.add(new Def("curse_of_weakness", "Проклятие слабости", "слабость III и замедление II на 1 минуту", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.WEAKNESS, MIN1, 2);
						effect(player, StatusEffects.SLOWNESS, MIN1, 1);
					}
					broadcast(server, "§cНоги налились свинцом, руки ослабли!");
				}));

		list.add(new Def("pitch_black", "Кромешная тьма", "слепота на 12 секунд", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.BLINDNESS, 240, 0);
					}
					broadcast(server, "§cСвет погас — все ослепли на 12 секунд!");
				}));

		list.add(new Def("zero_gravity", "Невесомость", "все плавно взлетают на 8 секунд (потом падать!)", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.LEVITATION, 160, 0);
					}
					broadcast(server, "§cГравитация отключилась — держитесь!");
				}));

		list.add(new Def("wrath_of_sky", "Гнев небес", "молния бьёт вплотную к каждому игроку", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						LightningEntity lightning = EntityType.LIGHTNING_BOLT.create(world);
						if (lightning != null) {
							lightning.refreshPositionAfterTeleport(player.getX() + random.nextDouble() * 2.0D - 1.0D,
									player.getY(), player.getZ() + random.nextDouble() * 4.0D - 2.0D);
							world.spawnEntity(lightning);
						}
						player.extinguish();   // молния пугает и бьёт током, но не оставляет игрока горящим
					}
					broadcast(server, "§cНебо разверзлось — берегись молний! (не поджигает)");
				}));

		list.add(new Def("invasion", "Нашествие", "рядом с каждым игроком появляются 5 зомби", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 5; i++) {
							MobEntity zombie = EntityType.ZOMBIE.create(world);
							if (zombie == null) {
								continue;
							}
							prepareMob(world, zombie, player.getX(), player.getY(), player.getZ());
							zombie.refreshPositionAndAngles(player.getX() + random.nextDouble() * 5.0D - 2.5D,
									player.getY(), player.getZ() + random.nextDouble() * 6.0D - 3.0D,
									random.nextFloat() * 360.0F, 0.0F);
							zombie.setTarget(player);
							world.spawnEntity(zombie);
						}
					}
					broadcast(server, "§cИз ниоткуда полезли зомби!");
				}));

		list.add(new Def("blast", "Взрыв под ногами", "взрыв вплотную: подбрасывает высоко и больно бьёт, но блоки целы", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						// Скрытая страховка: сопротивление V на 3 секунды гасит урон и от взрыва, и от падения
						// после подброса. Сам взрыв — ванильный (звук, частицы, толчок), мощность 1.0 и без разрушений.
						player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 20, 1, false, false, false));
						player.getServerWorld().createExplosion(null, player.getX(), player.getY(), player.getZ(),
								1.7F, Explosion.DestructionType.NONE);
					}
					broadcast(server, "§cЗемля взорвалась под ногами — подбрасывает высоко и бьёт больно!");
				}));

		// ---------------- смешанные ----------------

		list.add(new Def("teleport_lottery", "Лотерея телепортов", "все игроки меняются местами (один — подлетает)", Kind.MIXED, true,
				(server, cfg) -> {
					List<ServerPlayerEntity> players = players(server);
					if (players.size() >= 2) {
						List<ServerPlayerEntity> order = new ArrayList<>(players);
						Collections.rotate(order, 1);
						for (int i = 0; i < players.size(); i++) {
							ServerPlayerEntity who = players.get(i);
							ServerPlayerEntity where = order.get(i);
							who.teleport(where.getServerWorld(), where.getX(), where.getY(), where.getZ(),
									who.yaw, who.pitch);
						}
						broadcast(server, "§eВсе поменялись местами!");
					} else {
						for (ServerPlayerEntity player : players) {
							player.teleport(player.getServerWorld(), player.getX(), player.getY() + 25.0D,
									player.getZ(), player.yaw, player.pitch);
							effect(player, StatusEffects.SLOW_FALLING, 300, 0);
						}
						broadcast(server, "§eИгрока подбросило высоко в небо (падение мягкое)!");
					}
				}));

		list.add(new Def("block_chaos", "Блок-хаос", "20 случайных блоков вокруг каждого становятся другими", Kind.MIXED, true,
				(server, cfg) -> {
					Random random = rand(server);
					int changed = 0;
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 20; i++) {
							BlockPos pos = new BlockPos(
									(int) player.getX() + random.nextInt(13) - 6,
									(int) player.getY() + random.nextInt(5) - 2,
									(int) player.getZ() + random.nextInt(13) - 6);
							if (BlockRandomizer.transform(world, pos, cfg)) {
								changed++;
							}
						}
					}
					broadcast(server, "§eВолна хаоса прошла по блокам! Изменено блоков: §f" + changed);
				}));

		// ---------------- новые события 1.4.0 ----------------

		list.add(new Def("hand_loss", "Пропажа из рук", "предмет из руки исчезает навсегда", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						ItemStack main = player.getMainHandStack();
						ItemStack off = player.inventory.offHand.get(0);
						StringBuilder what = new StringBuilder();
						boolean lost = false;
						if (!main.isEmpty()) {
							what.append(main.getName().getString());
							if (main.getCount() > 1) {
								what.append(" x").append(main.getCount());
							}
							player.inventory.setStack(player.inventory.selectedSlot, ItemStack.EMPTY);
							lost = true;
						}
						if (!off.isEmpty()) {
							if (lost) {
								what.append(" и ");
							}
							what.append(off.getName().getString());
							if (off.getCount() > 1) {
								what.append(" x").append(off.getCount());
							}
							player.inventory.setStack(40, ItemStack.EMPTY);   // 40 — слот второй руки
							lost = true;
						}
						player.sendMessage(lost
								? new LiteralText("§6[Событие]§r §cиз рук пропало: §f" + what)
								: new LiteralText("§6[Событие]§r руки были пусты — терять было нечего."), false);
					}
					broadcast(server, "§cПредметы выскальзывают из рук и исчезают!");
				}));

		list.add(new Def("tnt_drop", "Подарочек с ТНТ", "ТНТ появляется ВПЛОТНУЮ, фитиль 4 секунды — беги", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						TntEntity tnt = EntityType.TNT.create(world);
						if (tnt == null) {
							continue;
						}
						double[] spot = ringSpot(player, random, 1.5D, 1.5D);
						tnt.refreshPositionAndAngles(spot[0], player.getY(), spot[1], 0.0F, 0.0F);
						tnt.setFuse(80);   // 4 секунды — время отбежать
						world.spawnEntity(tnt);
					}
					broadcast(server, "§cТНТ прямо под ногами! Фитиль 4 секунды — беги!");
				}));

		list.add(new Def("charged_creeper", "Заряженный крипер", "ЗАРЯЖЕННЫЙ крипер появляется вплотную", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						CreeperEntity creeper = EntityType.CREEPER.create(world);
						if (creeper == null) {
							continue;
						}
						// Тот же эффект, что у /summon minecraft:creeper ~ ~ ~ {powered:1b}:
						// NBT-тег powered:1b ставится криперу до его появления в мире.
						NbtCompound tag = new NbtCompound();
						tag.putBoolean("powered", true);
						creeper.readNbt(tag);
						double[] spot = ringSpot(player, random, 5.0D, 2.0D);
						creeper.refreshPositionAndAngles(spot[0], player.getY(), spot[1],
								random.nextFloat() * 360.0F, 0.0F);
						creeper.setTarget(player);
						world.spawnEntity(creeper);
					}
					broadcast(server, "§cИз ниоткуда появился ЗАРЯЖЕННЫЙ крипер!");
				}));

		list.add(new Def("mini_zombies", "Пять малышей", "рядом появляются 7 зомби-малышей (они быстрые!)", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 7; i++) {
							MobEntity zombie = EntityType.ZOMBIE.create(world);
							if (zombie == null) {
								continue;
							}
							prepareMob(world, zombie, player.getX(), player.getY(), player.getZ());
							zombie.setBaby(true);
							zombie.refreshPositionAndAngles(player.getX() + random.nextDouble() * 5.0D - 2.5D,
									player.getY(), player.getZ() + random.nextDouble() * 6.0D - 3.0D,
									random.nextFloat() * 360.0F, 0.0F);
							zombie.setTarget(player);
							world.spawnEntity(zombie);
						}
					}
					broadcast(server, "§cОткуда-то вылезли пять зомби-малышей!");
				}));

		list.add(new Def("inverted_controls", "Инверсия управления", "минута тошноты: камеру крутит и разворачивает", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.NAUSEA, MIN1, 0);
					}
					broadcast(server, "§eУправление путается целую минуту — камеру ведёт и разворачивает!");
					// Каждые 5 секунд переворачиваем камеру на 180° — сервер-сайд это делается
					// пакетом телепорта с поворотом (клиент его честно применяет).
					for (int i = 1; i <= 5; i++) {
						EventManager.schedule(server, i * 200, () -> {
							for (ServerPlayerEntity player : players(server)) {
								player.networkHandler.requestTeleport(player.getX(), player.getY(), player.getZ(),
										player.yaw + 180.0F, player.pitch);
							}
						});
					}
				}));

		// ================= 1.5.0: ещё 50+ событий =================

		// ---------------- подарки ----------------

		// ---------------- благословения на минуту ----------------

		list.add(new Def("second_wind", "Второе дыхание", "скорость II на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.SPEED, MIN1, 1);
					}
					broadcast(server, "§aНоги сами несут вперёд!");
				}));

		list.add(new Def("moon_boots", "Лунная походка", "прыгучесть II на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.JUMP_BOOST, MIN1, 1);
					}
					broadcast(server, "§aПрыгается легко и высоко!");
				}));

		list.add(new Def("cat_eyes", "Кошачье зрение", "ночное зрение на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.NIGHT_VISION, MIN1, 0);
					}
					broadcast(server, "§aТьма стала светлой!");
				}));

		list.add(new Def("fish_gills", "Рыбьи жабры", "водное дыхание на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.WATER_BREATHING, MIN1, 0);
					}
					broadcast(server, "§aДышится даже под водой!");
				}));

		list.add(new Def("fire_ward", "Огнеупорность", "огнестойкость на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.FIRE_RESISTANCE, MIN1, 0);
					}
					broadcast(server, "§aПламя больше не страшно!");
				}));

		list.add(new Def("dolphin_grace_ev", "Дельфинья грация", "грация дельфина на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.DOLPHINS_GRACE, MIN1, 0);
					}
					broadcast(server, "§aВ воде плывётся как дельфин!");
				}));

		list.add(new Def("conduit_power_ev", "Сила проводника", "сила проводника на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.CONDUIT_POWER, MIN1, 0);
					}
					broadcast(server, "§aМощь океана с тобой!");
				}));

		// ---------------- монстры ----------------

		list.add(new Def("skeleton_squad", "Отряд скелетов", "рядом появляются 5 скелетов", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						for (int i = 0; i < 5; i++) {
							double[] spot = ringSpot(player, random, 5.0D, 2.0D);
							spawnMob(player.getServerWorld(), EntityType.SKELETON, spot[0], player.getY(),
									spot[1], random, player);
						}
					}
					broadcast(server, "§cКостлявые гости уже натягивают луки!");
				}));

		list.add(new Def("spider_swarm", "Паучья стая", "рядом появляются 5 пауков", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						for (int i = 0; i < 5; i++) {
							double[] spot = ringSpot(player, random, 4.0D, 2.0D);
							spawnMob(player.getServerWorld(), EntityType.SPIDER, spot[0], player.getY(),
									spot[1], random, player);
						}
					}
					broadcast(server, "§cПауки спускаются со всех сторон!");
				}));

		list.add(new Def("cave_spiders", "Ядовитые гости", "рядом появляются 4 пещерных паука", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						for (int i = 0; i < 4; i++) {
							double[] spot = ringSpot(player, random, 4.0D, 2.0D);
							spawnMob(player.getServerWorld(), EntityType.CAVE_SPIDER, spot[0], player.getY(),
									spot[1], random, player);
						}
					}
					broadcast(server, "§cПещерные пауки — их укус отравляет!");
				}));

		list.add(new Def("slime_party", "Слизневая вечеринка", "рядом появляются 6 слизней", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						for (int i = 0; i < 6; i++) {
							double[] spot = ringSpot(player, random, 4.0D, 2.0D);
							spawnSmallSlime(player.getServerWorld(), EntityType.SLIME, spot[0], player.getY(),
									spot[1], random, false);
						}
					}
					broadcast(server, "§aЛипкие комки скачут во все стороны!");
				}));

		list.add(new Def("magma_cubes", "Магмовые кубики", "рядом появляются 5 магмовых кубов", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						for (int i = 0; i < 5; i++) {
							double[] spot = ringSpot(player, random, 4.0D, 2.0D);
							spawnSmallSlime(player.getServerWorld(), EntityType.MAGMA_CUBE, spot[0], player.getY(),
									spot[1], random, true);
						}
					}
					broadcast(server, "§cМагмовые кубики жгут при касании!");
				}));

		list.add(new Def("phantom_raid", "Небесные тени", "на тебя спускаются 4 фантома", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						for (int i = 0; i < 4; i++) {
							double[] spot = ringSpot(player, random, 4.0D, 2.0D);
							spawnMob(player.getServerWorld(), EntityType.PHANTOM, spot[0], player.getY() + 8.0D,
									spot[1], random, player);
						}
					}
					broadcast(server, "§cФантомы спикировали с неба!");
				}));

		list.add(new Def("silverfish_swarm", "Чешуйницы", "рядом появляются 8 чешуйниц", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						for (int i = 0; i < 8; i++) {
							double[] spot = ringSpot(player, random, 3.0D, 2.0D);
							spawnMob(player.getServerWorld(), EntityType.SILVERFISH, spot[0], player.getY(),
									spot[1], random, player);
						}
					}
					broadcast(server, "§cЧто-то шуршит под ногами…");
				}));

		list.add(new Def("vex_trouble", "Мелкие пакости", "рядом появляются 4 векса", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						for (int i = 0; i < 4; i++) {
							double[] spot = ringSpot(player, random, 4.0D, 2.0D);
							spawnMob(player.getServerWorld(), EntityType.VEX, spot[0], player.getY() + 2.0D,
									spot[1], random, player);
						}
					}
					broadcast(server, "§cВексы носятся вокруг и жалят!");
				}));

		list.add(new Def("pillager_party", "Незваные гости", "рядом появляются 4 разбойника", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						for (int i = 0; i < 4; i++) {
							double[] spot = ringSpot(player, random, 5.0D, 2.0D);
							spawnMob(player.getServerWorld(), EntityType.PILLAGER, spot[0], player.getY(),
									spot[1], random, player);
						}
					}
					broadcast(server, "§cРазбойники пришли за добычей!");
				}));

		list.add(new Def("polar_bear", "Белый медведь", "рядом появляются 2 белых медведя", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						double[] spot = ringSpot(player, random, 5.0D, 2.0D);
						spawnMob(player.getServerWorld(), EntityType.POLAR_BEAR, spot[0], player.getY(),
								spot[1], random, player);
					}
					broadcast(server, "§cБелый медведь не рад гостям!");
				}));

		list.add(new Def("witch_curse", "Злая ведьма", "рядом появляются 2 ведьмы с зельями", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						double[] spot = ringSpot(player, random, 6.0D, 2.0D);
						spawnMob(player.getServerWorld(), EntityType.WITCH, spot[0], player.getY(),
								spot[1], random, player);
					}
					broadcast(server, "§cВедьма уже занесла зелье!");
				}));

		list.add(new Def("arrow_volley", "Залп стрел", "в тебя летят 12 стрел со всех сторон", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 12; i++) {
							ArrowEntity arrow = EntityType.ARROW.create(world);
							if (arrow == null) {
								continue;
							}
							double angle = random.nextDouble() * Math.PI * 2.0D;
							double distance = 8.0D + random.nextDouble() * 4.0D;
							double x = player.getX() + Math.cos(angle) * distance;
							double y = player.getY() + 3.0D + random.nextDouble() * 2.0D;
							double z = player.getZ() + Math.sin(angle) * distance;
							arrow.refreshPositionAndAngles(x, y, z, 0.0F, 0.0F);
							arrow.setVelocity(player.getX() - x, (player.getY() + 1.0D) - y, player.getZ() - z,
									2.0F, 1.0F);
							world.spawnEntity(arrow);
						}
					}
					broadcast(server, "§cСвист стрел со всех сторон — пригнись!");
				}));

		list.add(new Def("burning_hat", "Горящая шляпа", "ты загораешься на 6 секунд", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						player.setOnFireFor(6);
					}
					broadcast(server, "§cЧто-то вспыхнуло прямо над головой!");
				}));

		list.add(new Def("xp_drain", "Утечка опыта", "минус 30 уровней", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						player.addExperienceLevels(-30);
					}
					broadcast(server, "§cОпыт утекает сквозь пальцы!");
				}));

		list.add(new Def("health_drain", "Половина здоровья", "здоровье падает до трети", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						player.setHealth(Math.max(2.0F, player.getHealth() * 0.35F));
					}
					broadcast(server, "§cСилы разом убавились на две трети!");
				}));

		list.add(new Def("hunger_curse", "Волчий голод", "голод II на полторы минуты", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						player.getHungerManager().setFoodLevel(0);
						effect(player, StatusEffects.HUNGER, MIN1 + 30 * SEC, 1);
					}
					broadcast(server, "§cЖивот сводит от голода!");
				}));

		list.add(new Def("mining_fatigue_ev", "Тяжёлые руки", "усталость III на 1 минуту", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.MINING_FATIGUE, MIN1, 2);
					}
					broadcast(server, "§cКирка стала ватной — копается медленно!");
				}));

		list.add(new Def("slowness_ev", "Свинцовые сапоги", "замедление III на 1 минуту", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.SLOWNESS, MIN1, 2);
					}
					broadcast(server, "§cШаги стали тяжёлыми и медленными!");
				}));

		list.add(new Def("nausea_long", "Карусель", "тошнота на 1 минуту", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.NAUSEA, MIN1, 0);
					}
					broadcast(server, "§cГолова кружится целую минуту!");
				}));

		list.add(new Def("tnt_trio", "Три ящика", "3 ТНТ падают вплотную, фитиль 5 секунд", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 3; i++) {
							TntEntity tnt = EntityType.TNT.create(world);
							if (tnt == null) {
								continue;
							}
							double[] spot = ringSpot(player, random, 2.5D, 2.0D);
							tnt.refreshPositionAndAngles(spot[0], player.getY(), spot[1], 0.0F, 0.0F);
							tnt.setFuse(100);   // 5 секунд
							world.spawnEntity(tnt);
						}
					}
					broadcast(server, "§cТри ящика с сюрпризом! Пять секунд — беги!");
				}));

		list.add(new Def("creeper_pair", "Парочка криперов", "3 крипера прямо рядом с тобой", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						for (int i = 0; i < 3; i++) {
							double[] spot = ringSpot(player, random, 3.0D, 1.5D);
							spawnMob(player.getServerWorld(), EntityType.CREEPER, spot[0], player.getY(),
									spot[1], random, player);
						}
					}
					broadcast(server, "§cТихо-тихо подкрадываются криперы…");
				}));

		// ---------------- смешанные ----------------

		list.add(new Def("random_teleport", "Куда-нибудь", "телепорт в случайное место за 50–150 блоков", Kind.MIXED, true,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						double angle = random.nextDouble() * Math.PI * 2.0D;
						double distance = 50.0D + random.nextDouble() * 100.0D;
						int x = (int) Math.floor(player.getX() + Math.cos(angle) * distance);
						int z = (int) Math.floor(player.getZ() + Math.sin(angle) * distance);
						int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z) + 1;
						player.teleport(world, x + 0.5D, y, z + 0.5D, player.yaw, player.pitch);
						effect(player, StatusEffects.SLOW_FALLING, 10 * SEC, 0);
					}
					broadcast(server, "§eКого-то занесло в неизвестное место (падение мягкое)!");
				}));

		list.add(new Def("tower_lift", "Подъём", "тебя поднимает на 30 блоков вверх", Kind.MIXED, true,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						player.teleport(player.getServerWorld(), player.getX(), player.getY() + 30.0D,
								player.getZ(), player.yaw, player.pitch);
						effect(player, StatusEffects.SLOW_FALLING, 20 * SEC, 0);
					}
					broadcast(server, "§eВсе поднялись на 30 блоков выше!");
				}));

		list.add(new Def("animal_friends", "Друзья животных", "рядом появляются корова, свинья и курица", Kind.POSITIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						EntityType<?>[] types = {EntityType.COW, EntityType.PIG, EntityType.CHICKEN};
						for (EntityType<?> type : types) {
							double[] spot = ringSpot(player, random, 4.0D, 2.0D);
							spawnMob(player.getServerWorld(), type, spot[0], player.getY(), spot[1], random, null);
						}
					}
					broadcast(server, "§aК тебе пришли милые животные!");
				}));

		list.add(new Def("parrot_gift", "Попугай на плечо", "рядом появляется попугай", Kind.POSITIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						double[] spot = ringSpot(player, random, 3.0D, 2.0D);
						spawnMob(player.getServerWorld(), EntityType.PARROT, spot[0], player.getY(), spot[1],
								random, null);
					}
					broadcast(server, "§aПопугай прилетел составить компанию!");
				}));

		list.add(new Def("bee_friends", "Пчелиный рой", "рядом появляются 3 пчелы", Kind.MIXED,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						for (int i = 0; i < 3; i++) {
							double[] spot = ringSpot(player, random, 3.0D, 2.0D);
							spawnMob(player.getServerWorld(), EntityType.BEE, spot[0], player.getY(), spot[1],
									random, null);
						}
					}
					broadcast(server, "§eПчёлы прилетели. Не зли их!");
				}));

		list.add(new Def("trader_visit", "Караван", "приходит странствующий торговец с ламами", Kind.POSITIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						double[] spot = ringSpot(player, random, 5.0D, 2.0D);
						NbtCompound tag = new NbtCompound();
						tag.putInt("DespawnDelay", 40 * 60 * SEC);
						spawnMob(player.getServerWorld(), EntityType.WANDERING_TRADER, spot[0], player.getY(),
								spot[1], random, null, tag);
						for (int i = 0; i < 2; i++) {
							double[] llamaSpot = ringSpot(player, random, 6.0D, 2.0D);
							spawnMob(player.getServerWorld(), EntityType.TRADER_LLAMA, llamaSpot[0], player.getY(),
									llamaSpot[1], random, null);
						}
					}
					broadcast(server, "§aС караваном приехал странствующий торговец!");
				}));

		list.add(new Def("weather_rain", "Ливень", "дождь на 5 минут", Kind.MIXED, true,
				(server, cfg) -> {
					server.getOverworld().setWeather(0, 5 * 60 * SEC, true, false);
					broadcast(server, "§eНебо затянуло — пошёл дождь!");
				}));

		list.add(new Def("weather_thunder", "Гроза", "гроза на 3 минуты", Kind.NEGATIVE,
				(server, cfg) -> {
					server.getOverworld().setWeather(0, 3 * 60 * SEC, true, true);
					broadcast(server, "§cСверкает и гремит — настоящая гроза!");
				}));

		list.add(new Def("time_noon", "Полдень", "время перескакивает на полдень", Kind.MIXED,
				(server, cfg) -> {
					server.getOverworld().setTimeOfDay(6000L);
					broadcast(server, "§eСолнце взлетело в зенит — наступил полдень!");
				}));

		list.add(new Def("time_night", "Глухая ночь", "время перескакивает на ночь", Kind.MIXED, true,
				(server, cfg) -> {
					server.getOverworld().setTimeOfDay(18000L);
					broadcast(server, "§eСолнце рухнуло за горизонт — настала ночь!");
				}));

		RandomBlocks.LOGGER.info("Event list built: {} events", list.size());
		// ================= 1.6.0: ещё 56 событий =================

		// ---------------- подарки ----------------

		// ---------------- благословения ----------------

		list.add(new Def("regen_heart", "Второе сердце", "регенерация II на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.REGENERATION, MIN1, 1);
					}
					broadcast(server, "§aРаны затягиваются на глазах!");
				}));

		list.add(new Def("strength_hour", "Сила титана", "сила II на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.STRENGTH, MIN1, 1);
					}
					broadcast(server, "§aУдары стали тяжелее!");
				}));

		list.add(new Def("resistance_hour", "Каменная кожа", "сопротивление II на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.RESISTANCE, MIN1, 1);
					}
					broadcast(server, "§aКожа стала как камень!");
				}));

		list.add(new Def("haste_hour", "Быстрые руки", "спешка III на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.HASTE, MIN1, 2);
					}
					broadcast(server, "§aКопается втрое быстрее!");
				}));

		list.add(new Def("feather_fall_hour", "Пёрышко", "замедленное падение на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.SLOW_FALLING, MIN1, 0);
					}
					broadcast(server, "§aПадать теперь мягко, как пёрышко!");
				}));

		list.add(new Def("health_boost_hour", "Крепкое здоровье", "+4 сердца на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.HEALTH_BOOST, MIN1, 3);
					}
					broadcast(server, "§aЗдоровья стало заметно больше!");
				}));

		list.add(new Def("absorption_gift", "Золотые сердца", "поглощение IV на 1 минуту", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.ABSORPTION, MIN1, 3);
					}
					broadcast(server, "§aВокруг тебя появились золотые сердца!");
				}));

		list.add(new Def("village_hero", "Герой деревни", "герой деревни на 1 минуту — скидки у жителей", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.HERO_OF_THE_VILLAGE, MIN1, 1);
					}
					broadcast(server, "§aЖители смотрят на тебя с уважением!");
				}));

		// ---------------- угрозы ----------------

		list.add(new Def("husk_pack", "Сухие мертвецы", "рядом появляются 4 кадавра", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						spawnPack(player, random, EntityType.HUSK, 4, 4.5D, 2.0D);
					}
					broadcast(server, "§cПесок шевелится — кадавры вылезли!");
				}));

		list.add(new Def("drowned_pack", "Утопцы", "рядом появляются 4 утопленника", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						spawnPack(player, random, EntityType.DROWNED, 4, 4.5D, 2.0D);
					}
					broadcast(server, "§cМокрые руки тянутся из темноты!");
				}));

		list.add(new Def("stray_pack", "Зимние охотники", "рядом появляются 4 зимогора", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						spawnPack(player, random, EntityType.STRAY, 4, 5.0D, 2.0D);
					}
					broadcast(server, "§cЛедяные стрелы уже летят!");
				}));

		list.add(new Def("enderman_visit", "Странник Края", "рядом появляется эндермен", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						double[] spot = ringSpot(player, random, 5.0D, 2.0D);
						spawnMob(player.getServerWorld(), EntityType.ENDERMAN, spot[0], player.getY(),
								spot[1], random, player);
					}
					broadcast(server, "§cФиолетовые глаза смотрят прямо на тебя… не смотри в ответ!");
				}));

		list.add(new Def("angry_wolves", "Злая стая", "5 волков, которые сразу бросаются", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						spawnAngryPack(player, random, EntityType.WOLF, 5, 4.0D, 2.0D);
					}
					broadcast(server, "§cСтая оскалилась — беги!");
				}));

		list.add(new Def("bee_swarm", "Разъярённые пчёлы", "6 злых пчёл", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						spawnAngryPack(player, random, EntityType.BEE, 6, 3.5D, 2.0D);
					}
					broadcast(server, "§cЖужжание всё ближе — пчёлы в ярости!");
				}));

		list.add(new Def("bat_swarm", "Летучие мыши", "10 мышей вылетают из темноты", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						spawnPack(player, random, EntityType.BAT, 10, 3.0D, 2.0D);
					}
					broadcast(server, "§cЧто-то зашуршало над головой!");
				}));

		list.add(new Def("zombie_horde", "Орда", "рядом появляются 8 зомби", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						spawnPack(player, random, EntityType.ZOMBIE, 8, 5.0D, 3.0D);
					}
					broadcast(server, "§cТолпа зомби идёт за тобой!");
				}));

		list.add(new Def("wither_skeleton_guest", "Скелет-иссушитель", "рядом появляются 2 иссушителя", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						double[] spot = ringSpot(player, random, 6.0D, 2.0D);
						spawnMob(player.getServerWorld(), EntityType.WITHER_SKELETON, spot[0], player.getY(),
								spot[1], random, player);
					}
					broadcast(server, "§cЧёрные кости и каменный меч — держись подальше!");
				}));

		list.add(new Def("blaze_guest", "Гость из Нижнего мира", "рядом появляются 2 всполоха", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						double[] spot = ringSpot(player, random, 6.0D, 2.0D);
						spawnMob(player.getServerWorld(), EntityType.BLAZE, spot[0], player.getY() + 1.0D,
								spot[1], random, player);
					}
					broadcast(server, "§cСтало жарко — всполох уже заряжает огненные шары!");
				}));

		list.add(new Def("ghast_call", "Крик гаста", "в небе появляется гаст", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						double[] spot = ringSpot(player, random, 5.0D, 3.0D);
						spawnMob(player.getServerWorld(), EntityType.GHAST, spot[0], player.getY() + 12.0D,
								spot[1], random, null);
					}
					broadcast(server, "§cНебесный плач — огненные шары летят сверху!");
				}));

		list.add(new Def("endermite_burst", "Эндермиты", "рядом появляются 8 эндермитов", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						spawnPack(player, random, EntityType.ENDERMITE, 8, 3.0D, 2.0D);
					}
					broadcast(server, "§cМелкие твари грызут всё вокруг!");
				}));

		list.add(new Def("hoglin_pair", "Кровожадные свиньи", "рядом появляются 3 хоглина", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						spawnPack(player, random, EntityType.HOGLIN, 3, 5.0D, 2.0D);
					}
					broadcast(server, "§cХоглины разъярены — они бьют больно!");
				}));

		list.add(new Def("lightning_ring", "Кольцо молний", "6 молний бьют вплотную", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 6; i++) {
							double[] spot = ringSpot(player, random, 2.5D, 1.5D);
							LightningEntity lightning = EntityType.LIGHTNING_BOLT.create(world);
							if (lightning != null) {
								lightning.refreshPositionAfterTeleport(spot[0], player.getY(), spot[1]);
								world.spawnEntity(lightning);
							}
						}
					}
					broadcast(server, "§cГроза вокруг: молнии бьют со всех сторон!");
				}));

		list.add(new Def("fire_ring", "Огненный круг", "огонь вспыхивает вплотную вокруг тебя", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 10; i++) {
							BlockPos pos = groundSpot(world, player, random, 1.5D, 1.5D);
							if (pos != null) {
								world.setBlockState(pos, Blocks.FIRE.getDefaultState());
							}
						}
					}
					broadcast(server, "§cЗемля занялась — по сторонам огонь!");
				}));

		list.add(new Def("tnt_cluster", "ТНТ-кластер", "5 зарядов ТНТ вплотную, фитиль 5 секунд", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 5; i++) {
							double[] spot = ringSpot(player, random, 2.5D, 2.0D);
							TntEntity tnt = EntityType.TNT.create(world);
							if (tnt != null) {
								tnt.refreshPositionAndAngles(spot[0], player.getY(), spot[1], 0.0F, 0.0F);
								tnt.setFuse(100);            // 5 секунд — время отбежать
								world.spawnEntity(tnt);
							}
						}
					}
					broadcast(server, "§cПять зарядов ТНТ вплотную — пять секунд, беги!");
				}));

		list.add(new Def("blindness_short", "Слепота", "слепота на 25 секунд", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.BLINDNESS, 25 * SEC, 0);
					}
					broadcast(server, "§cСвет погас — ты ничего не видишь!");
				}));

		list.add(new Def("levitation_short", "Подъём в небо", "левитация на 12 секунд (потом падать с высоты)", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.LEVITATION, 12 * SEC, 0);
					}
					broadcast(server, "§cЗемля уходит из-под ног… держись!");
				}));

		list.add(new Def("wither_touch", "Прикосновение иссушения", "иссушение II на 25 секунд", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.WITHER, 25 * SEC, 1);
					}
					broadcast(server, "§cЖизнь утекает из тебя чёрной дымкой!");
				}));

		list.add(new Def("armor_wear", "Потрёпанные доспехи", "у брони разом съедает три четверти прочности", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST,
								EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
							ItemStack stack = player.getEquippedStack(slot);
							if (stack.isEmpty() || !stack.isDamageable()) {
								continue;
							}
							int max = stack.getMaxDamage();
							stack.setDamage(Math.min(max - 1, (int) (max * 0.75D)));
						}
					}
					broadcast(server, "§cДоспехи разом потеряли три четверти прочности!");
				}));

		list.add(new Def("inventory_shuffle", "Переполох в руках", "предметы в хотбаре перемешиваются", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						PlayerInventory inventory = player.inventory;
						ItemStack[] hotbar = new ItemStack[9];
						for (int i = 0; i < 9; i++) {
							hotbar[i] = inventory.getStack(i).copy();
						}
						for (int i = 8; i > 0; i--) {
							int j = random.nextInt(i + 1);
							ItemStack tmp = hotbar[i];
							hotbar[i] = hotbar[j];
							hotbar[j] = tmp;
						}
						for (int i = 0; i < 9; i++) {
							inventory.setStack(i, hotbar[i]);
						}
					}
					broadcast(server, "§cХотбар перепутался — ищи свой меч заново!");
				}));

		list.add(new Def("cobweb_trap", "Паутина под ногами", "под тобой появляется паутина", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						BlockPos pos = player.getBlockPos();
						if (world.isAir(pos)) {
							world.setBlockState(pos, Blocks.COBWEB.getDefaultState());
						}
					}
					broadcast(server, "§cПод ногами паутина — двигаться стало тяжело!");
				}));

		// ---------------- смешанные ----------------

		list.add(new Def("chicken_bomb", "Куриная бомба", "8 кур падают на тебя сверху", Kind.MIXED,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						for (int i = 0; i < 8; i++) {
							double[] spot = ringSpot(player, random, 1.0D, 2.0D);
							spawnMob(player.getServerWorld(), EntityType.CHICKEN, spot[0], player.getY() + 15.0D,
									spot[1], random, null);
						}
					}
					broadcast(server, "§eС неба сыплются куры!");
				}));

		list.add(new Def("slime_trampoline", "Слизневый батут", "под тобой блок слизи и прыгучесть на 15 секунд", Kind.MIXED,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						BlockPos pos = player.getBlockPos().down();
						if (!world.isAir(pos)) {
							world.setBlockState(pos, Blocks.SLIME_BLOCK.getDefaultState());
						}
						effect(player, StatusEffects.JUMP_BOOST, 15 * SEC, 1);
					}
					broadcast(server, "§eПод ногами батут — прыгается выше крыши!");
				}));

		list.add(new Def("effect_roulette", "Рулетка эффектов", "каждому случайный эффект на 30 секунд", Kind.MIXED, true,
				(server, cfg) -> {
					Random random = rand(server);
					StatusEffect[] pool = {StatusEffects.SPEED, StatusEffects.SLOWNESS, StatusEffects.STRENGTH,
							StatusEffects.WEAKNESS, StatusEffects.REGENERATION, StatusEffects.POISON,
							StatusEffects.JUMP_BOOST, StatusEffects.NIGHT_VISION, StatusEffects.INVISIBILITY,
							StatusEffects.HASTE, StatusEffects.MINING_FATIGUE, StatusEffects.ABSORPTION,
							StatusEffects.RESISTANCE, StatusEffects.HUNGER, StatusEffects.WATER_BREATHING};
					for (ServerPlayerEntity player : players(server)) {
						StatusEffect chosen = pool[random.nextInt(pool.length)];
						effect(player, chosen, 30 * SEC, 0);
						player.sendMessage(new LiteralText("§6[Событие]§r рулетка выдала: §e"
								+ chosen.getName().getString()), false);
					}
					broadcast(server, "§eКаждому — свой случайный эффект на 30 секунд!");
				}));

		list.add(new Def("ice_floor", "Ледяной пол", "блок под тобой становится льдом — скользко", Kind.MIXED, true,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						BlockPos pos = player.getBlockPos().down();
						if (!world.isAir(pos)) {
							world.setBlockState(pos, Blocks.ICE.getDefaultState());
						}
					}
					broadcast(server, "§eПод ногами лёд — тормозить стало сложнее!");
				}));

		list.add(new Def("time_dawn", "Рассвет", "время переводится на утро", Kind.MIXED,
				(server, cfg) -> {
					server.getOverworld().setTimeOfDay(23000L);
					broadcast(server, "§eНебо светлеет — скоро взойдёт солнце!");
				}));

		list.add(new Def("weather_clear", "Просветление", "погода становится ясной на 5 минут", Kind.MIXED,
				(server, cfg) -> {
					server.getOverworld().setWeather(5 * 60 * SEC, 0, false, false);
					broadcast(server, "§eТучи расходятся — дождь прекратился!");
				}));

		list.add(new Def("flower_meadow", "Цветочная поляна", "вокруг тебя вырастают цветы", Kind.MIXED,
				(server, cfg) -> {
					Random random = rand(server);
					Block[] flowers = {Blocks.DANDELION, Blocks.POPPY, Blocks.BLUE_ORCHID, Blocks.AZURE_BLUET,
							Blocks.OXEYE_DAISY, Blocks.CORNFLOWER, Blocks.LILY_OF_THE_VALLEY};
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 16; i++) {
							BlockPos pos = groundSpot(world, player, random, 2.0D, 6.0D);
							if (pos != null) {
								world.setBlockState(pos, flowers[random.nextInt(flowers.length)].getDefaultState());
							}
						}
					}
					broadcast(server, "§dОглянись — всё вокруг в цветах!");
				}));

		list.add(new Def("block_paint", "Перекраска мира", "12 блоков вокруг становятся цветной шерстью", Kind.MIXED, true,
				(server, cfg) -> {
					Random random = rand(server);
					Block[] palette = {Blocks.WHITE_WOOL, Blocks.RED_WOOL, Blocks.ORANGE_WOOL, Blocks.YELLOW_WOOL,
							Blocks.LIME_WOOL, Blocks.LIGHT_BLUE_WOOL, Blocks.PURPLE_WOOL, Blocks.PINK_WOOL};
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 12; i++) {
							BlockPos pos = groundSpot(world, player, random, 2.0D, 6.0D);
							if (pos != null) {
								world.setBlockState(pos, palette[random.nextInt(palette.length)].getDefaultState());
							}
						}
					}
					broadcast(server, "§dМир вокруг перекрасился в шерсть!");
				}));

		list.add(new Def("mob_parade", "Парад животных", "рядом появляются корова, свинья, курица, овца и лошадь", Kind.MIXED,
				(server, cfg) -> {
					Random random = rand(server);
					EntityType<?>[] types = {EntityType.COW, EntityType.PIG, EntityType.CHICKEN, EntityType.SHEEP,
							EntityType.HORSE};
					for (ServerPlayerEntity player : players(server)) {
						for (EntityType<?> type : types) {
							double[] spot = ringSpot(player, random, 3.0D, 3.0D);
							spawnMob(player.getServerWorld(), type, spot[0], player.getY(), spot[1], random, null);
						}
					}
					broadcast(server, "§eЦелая ферма пришла к тебе в гости!");
				}));

		list.add(new Def("pumpkin_helmet", "Тыква на голову", "на голову надевается светящаяся тыква", Kind.MIXED,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						player.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.CARVED_PUMPKIN));
					}
					broadcast(server, "§eНа голове тыква — обзор стал хуже, зато светит!");
				}));


		// ================= 1.7.0: события больше не выдают предметы =================
		// Все «подарочные» события (дождь алмазов, наборы брони, еда в инвентарь и т.п.) удалены:
		// за предметы отвечает отдельный таймер выдачи. Вместо них — жёсткие события и
		// благословения-эффекты, где в инвентарь не попадает ни одна вещь.

		// ---------------- очень плохие ----------------

		list.add(new Def("anvil_rain", "Кузнечный дождь", "пять наковален падают тебе на голову", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 5; i++) {
							double[] spot = closeSpot(player, random, 0.5D, 1.5D);
							FallingBlockEntity anvil = new FallingBlockEntity(world, spot[0],
									player.getY() + 8.0D, spot[1], Blocks.ANVIL.getDefaultState());
							NbtCompound tag = new NbtCompound();
							tag.putBoolean("HurtEntities", true);
							anvil.readNbt(tag);
							anvil.refreshPositionAndAngles(spot[0], player.getY() + 8.0D, spot[1], 0.0F, 0.0F);
							world.spawnEntity(anvil);
						}
						EventManager.schedule(server, 30, () -> {
							if (player.isAlive()) {
								player.damage(DamageSource.ANVIL, 6.0F);
								effect(player, StatusEffects.SLOWNESS, 60, 1);
							}
						});
					}
					broadcast(server, "§cНаковальни! Прямо на голову!");
				}));

		list.add(new Def("magma_floor", "Кипящий пол", "блоки под тобой вскипают магмой на 6 секунд", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						BlockPos center = player.getBlockPos();
						List<BlockPos> changed = new ArrayList<>();
						List<BlockState> before = new ArrayList<>();
						int[][] offsets = {{0, 0}, {1, 0}, {-1, 0}, {0, 1}, {0, -1}};
						for (int[] o : offsets) {
							BlockPos pos = center.add(o[0], -1, o[1]);
							BlockState state = world.getBlockState(pos);
							if (state.isAir() || state.getBlock() == Blocks.MAGMA_BLOCK) {
								continue;
							}
							changed.add(pos);
							before.add(state);
							world.setBlockState(pos, Blocks.MAGMA_BLOCK.getDefaultState());
						}
						if (!changed.isEmpty()) {
							EventManager.schedule(server, 120, () -> {
								for (int i = 0; i < changed.size(); i++) {
									world.setBlockState(changed.get(i), before.get(i));
								}
							});
						}
					}
					broadcast(server, "§cПол под ногами вскипает магмой — не стой на месте!");
				}));

		list.add(new Def("zoglin_pair", "Гости из Нижнего", "два зоглина вырываются вплотную", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						spawnPack(player, random, EntityType.ZOGLIN, 2, 4.0D, 2.0D);
					}
					broadcast(server, "§cТяжёлое хрюканье за спиной — зоглины идут по твою душу!");
				}));

		list.add(new Def("ravager_call", "Разоритель", "рядом появляется разоритель и ломает всё на пути", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						double[] spot = ringSpot(player, random, 6.0D, 2.0D);
						spawnMob(player.getServerWorld(), EntityType.RAVAGER, spot[0], player.getY(), spot[1],
								random, player);
					}
					broadcast(server, "§cТопот сотрясает землю — разоритель!");
				}));

		list.add(new Def("witch_trio", "Три ведьмы", "три ведьмы с зельями вплотную", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						spawnPack(player, random, EntityType.WITCH, 3, 4.5D, 2.0D);
					}
					broadcast(server, "§cТри ведьмы уже занесли зелья!");
				}));

		list.add(new Def("siege", "Осада", "3 разбойника и 2 виндикатора с топорами", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 3; i++) {
							double[] spot = ringSpot(player, random, 6.0D, 2.0D);
							spawnMob(world, EntityType.PILLAGER, spot[0], player.getY(), spot[1], random, player);
						}
						for (int i = 0; i < 2; i++) {
							double[] spot = ringSpot(player, random, 5.0D, 2.0D);
							MobEntity vindicator = spawnMob(world, EntityType.VINDICATOR, spot[0], player.getY(),
									spot[1], random, player);
							if (vindicator != null) {
								vindicator.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_AXE));
							}
						}
					}
					broadcast(server, "§cНастоящая осада: разбойники и виндикаторы!");
				}));

		list.add(new Def("lightning_barrage", "Шквал молний", "шесть молний бьют вплотную", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 6; i++) {
							LightningEntity lightning = EntityType.LIGHTNING_BOLT.create(world);
							if (lightning == null) {
								continue;
							}
							double[] spot = ringSpot(player, random, 1.0D, 2.0D);
							lightning.refreshPositionAfterTeleport(spot[0], player.getY(), spot[1]);
							world.spawnEntity(lightning);
						}
						player.extinguish();      // бьёт током и пугает, но не поджигает игрока
					}
					broadcast(server, "§cШквал молний — вплотную!");
				}));

		list.add(new Def("tnt_hell", "ТНТ-ад", "5 зарядов ТНТ прямо под ногами, фитиль 2.5 секунды", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 5; i++) {
							TntEntity tnt = EntityType.TNT.create(world);
							if (tnt == null) {
								continue;
							}
							double[] spot = closeSpot(player, random, 0.5D, 1.5D);
							tnt.refreshPositionAndAngles(spot[0], player.getY(), spot[1], 0.0F, 0.0F);
							tnt.setFuse(50);
							world.spawnEntity(tnt);
						}
					}
					broadcast(server, "§cПять зарядов ТНТ прямо под ногами — 2.5 секунды!");
				}));

		list.add(new Def("tnt_ring", "Кольцо ТНТ", "6 зарядов ТНТ по кругу в двух блоках", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 6; i++) {
							TntEntity tnt = EntityType.TNT.create(world);
							if (tnt == null) {
								continue;
							}
							double angle = (Math.PI * 2.0D / 6.0D) * i;
							double x = player.getX() + Math.cos(angle) * 2.0D;
							double z = player.getZ() + Math.sin(angle) * 2.0D;
							tnt.refreshPositionAndAngles(x, player.getY(), z, 0.0F, 0.0F);
							tnt.setFuse(80);
							world.spawnEntity(tnt);
						}
					}
					broadcast(server, "§cКольцо ТНТ вокруг тебя — четыре секунды!");
				}));

		list.add(new Def("creeper_squad", "Отряд криперов", "4 крипера прямо рядом", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						spawnPack(player, random, EntityType.CREEPER, 4, 3.0D, 1.5D);
					}
					broadcast(server, "§cКриперы уже шипят со всех сторон!");
				}));

		list.add(new Def("blind_fury", "Слепая ярость", "слепота на 25 секунд и 4 зомби с мечами", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.BLINDNESS, 25 * SEC, 0);
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 4; i++) {
							double[] spot = ringSpot(player, random, 3.0D, 2.0D);
							NbtCompound tag = new NbtCompound();
							NbtList hand = new NbtList();
							NbtCompound sword = new NbtCompound();
							sword.putString("id", "minecraft:iron_sword");
							sword.putByte("Count", (byte) 1);
							hand.add(sword);
							hand.add(new NbtCompound());
							tag.put("HandItems", hand);
							spawnMob(world, EntityType.ZOMBIE, spot[0], player.getY(), spot[1], random, player, tag);
						}
					}
					broadcast(server, "§cТьма и сталь: слепота и зомби с мечами!");
				}));

		list.add(new Def("shockwave", "Ударная волна", "всех подбрасывает в воздух и мутит 20 секунд", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						double angle = random.nextDouble() * Math.PI * 2.0D;
						player.addVelocity(Math.cos(angle) * 0.9D, 1.1D, Math.sin(angle) * 0.9D);
						player.velocityModified = true;
						effect(player, StatusEffects.NAUSEA, 20 * SEC, 0);
					}
					broadcast(server, "§cУдарная волна подбросила всех в воздух!");
				}));

		list.add(new Def("wither_grip", "Хватка иссушения", "иссушение II и слабость на 20 секунд", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.WITHER, 20 * SEC, 1);
						effect(player, StatusEffects.WEAKNESS, 20 * SEC, 1);
					}
					broadcast(server, "§cЧёрная хватка сдавила грудь!");
				}));

		list.add(new Def("spider_nest", "Паучье гнездо", "5 пауков и паутина вокруг", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 5; i++) {
							double[] spot = ringSpot(player, random, 3.0D, 2.0D);
							spawnMob(world, EntityType.SPIDER, spot[0], player.getY(), spot[1], random, player);
						}
						for (int i = 0; i < 8; i++) {
							BlockPos pos = groundSpot(world, player, random, 1.5D, 1.5D);
							if (pos != null && world.isAir(pos)) {
								world.setBlockState(pos, Blocks.COBWEB.getDefaultState());
							}
						}
					}
					broadcast(server, "§cВсё вокруг в паутине, а пауки уже близко!");
				}));

		list.add(new Def("ghast_squad", "Хор гастов", "два гаста появляются в небе", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 2; i++) {
							double[] spot = ringSpot(player, random, 5.0D, 3.0D);
							spawnMob(world, EntityType.GHAST, spot[0], player.getY() + 12.0D, spot[1], random, null);
						}
					}
					broadcast(server, "§cНебесный плач в два голоса — огненные шары сверху!");
				}));

		list.add(new Def("arrow_storm", "Стрелопад", "12 стрел падают на тебя сверху", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 12; i++) {
							ArrowEntity arrow = EntityType.ARROW.create(world);
							if (arrow == null) {
								continue;
							}
							double x = player.getX() + random.nextDouble() * 6.0D - 3.0D;
							double z = player.getZ() + random.nextDouble() * 6.0D - 3.0D;
							double y = player.getY() + 9.0D;
							arrow.refreshPositionAndAngles(x, y, z, 0.0F, 0.0F);
							arrow.setVelocity(0.0D, -1.8D, 0.0D, 1.4F, 0.4F);
							world.spawnEntity(arrow);
						}
					}
					broadcast(server, "§cСтрелы сыплются с неба — беги зигзагом!");
				}));

		list.add(new Def("xp_zero", "Опыт в ноль", "весь накопленный опыт сгорает", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						player.addExperienceLevels(-player.experienceLevel);
						player.sendMessage(new LiteralText("§6[Событие]§r опыт обнулился!"), false);
					}
					broadcast(server, "§cВесь опыт улетучился чёрным дымом!");
				}));

		list.add(new Def("hunger_bottom", "Пустой живот", "еда в ноль и голод II на 40 секунд", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						player.getHungerManager().setFoodLevel(0);
						player.getHungerManager().add(0, 0.0F);
						effect(player, StatusEffects.HUNGER, 40 * SEC, 1);
					}
					broadcast(server, "§cЖивот сводит от голода — еда на нуле!");
				}));

		list.add(new Def("lead_hands", "Свинцовые руки", "усталость III и слабость II на полторы минуты", Kind.NEGATIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.MINING_FATIGUE, MIN1 + 30 * SEC, 2);
						effect(player, StatusEffects.WEAKNESS, MIN1 + 30 * SEC, 1);
					}
					broadcast(server, "§cРуки налились свинцом — ни копать, ни бить!");
				}));

		list.add(new Def("blaze_inferno", "Инферно", "два всполоха и огонь вокруг", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 2; i++) {
							double[] spot = ringSpot(player, random, 5.0D, 2.0D);
							spawnMob(world, EntityType.BLAZE, spot[0], player.getY() + 1.0D, spot[1], random, player);
						}
						for (int i = 0; i < 6; i++) {
							BlockPos pos = groundSpot(world, player, random, 1.5D, 1.5D);
							if (pos != null && world.isAir(pos)) {
								world.setBlockState(pos, Blocks.FIRE.getDefaultState());
							}
						}
					}
					broadcast(server, "§cИнферно: всполохи и огонь вплотную!");
				}));

		list.add(new Def("drowned_elite", "Утопцы с трезубцами", "4 утопца с трезубцами вплотную", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 4; i++) {
							double[] spot = ringSpot(player, random, 4.0D, 2.0D);
							NbtCompound tag = new NbtCompound();
							NbtList hand = new NbtList();
							NbtCompound trident = new NbtCompound();
							trident.putString("id", "minecraft:trident");
							trident.putByte("Count", (byte) 1);
							hand.add(trident);
							hand.add(new NbtCompound());
							tag.put("HandItems", hand);
							spawnMob(world, EntityType.DROWNED, spot[0], player.getY(), spot[1], random, player, tag);
						}
					}
					broadcast(server, "§cУтопцы с трезубцами — держись подальше!");
				}));

		list.add(new Def("piglin_brutes", "Свинозвери", "2 свинозверя с золотыми топорами", Kind.NEGATIVE,
				(server, cfg) -> {
					Random random = rand(server);
					for (ServerPlayerEntity player : players(server)) {
						ServerWorld world = player.getServerWorld();
						for (int i = 0; i < 2; i++) {
							double[] spot = ringSpot(player, random, 5.0D, 2.0D);
							spawnMob(world, EntityType.PIGLIN_BRUTE, spot[0], player.getY(), spot[1], random, player);
						}
					}
					broadcast(server, "§cСвинозвери пришли за добычей — они не отступают!");
				}));

		// ---------------- хорошие (тоже без единого предмета) ----------------

		list.add(new Def("feast_heal", "Сытный стол", "еда и насыщение восстановлены полностью", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						player.getHungerManager().setFoodLevel(20);
						player.getHungerManager().add(10, 1.0F);
						player.removeStatusEffect(StatusEffects.HUNGER);
					}
					broadcast(server, "§aСытость вернулась — бегать можно без остановки!");
				}));

		list.add(new Def("night_vision_long", "Кошачьи глаза", "ночное зрение на 3 минуты", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.NIGHT_VISION, 3 * MIN1, 0);
					}
					broadcast(server, "§aТьма больше не помеха — видно как днём!");
				}));

		list.add(new Def("speed_burst", "Взрыв скорости", "скорость III на 45 секунд", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.SPEED, 45 * SEC, 2);
					}
					broadcast(server, "§aВетер в спину — скорость III!");
				}));

		list.add(new Def("regen_boost", "Живая вода", "регенерация III на 30 секунд", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.REGENERATION, 30 * SEC, 2);
					}
					broadcast(server, "§aРаны затягиваются на глазах!");
				}));

		list.add(new Def("xp_surge", "Поток опыта", "+40 уровней каждому", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						player.addExperienceLevels(40);
						player.sendMessage(new LiteralText("§6[Событие]§r тебе начислено §e40 уровней"), false);
					}
					broadcast(server, "§aОпыт льётся рекой!");
				}));

		list.add(new Def("guardian_angel", "Ангел-хранитель", "сопротивление III и регенерация II на 30 секунд", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.RESISTANCE, 30 * SEC, 2);
						effect(player, StatusEffects.REGENERATION, 30 * SEC, 1);
					}
					broadcast(server, "§aТебя прикрыли сверху — урон почти не проходит!");
				}));

		list.add(new Def("water_master", "Владыка воды", "водное дыхание и грация дельфина на 3 минуты", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.WATER_BREATHING, 3 * MIN1, 0);
						effect(player, StatusEffects.DOLPHINS_GRACE, 3 * MIN1, 0);
					}
					broadcast(server, "§aВода стала родной стихией!");
				}));

		list.add(new Def("conduit_master", "Сила проводника", "сила проводника II и ночное зрение на 3 минуты", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.CONDUIT_POWER, 3 * MIN1, 1);
						effect(player, StatusEffects.NIGHT_VISION, 3 * MIN1, 0);
					}
					broadcast(server, "§aСила проводника бурлит в крови!");
				}));

		list.add(new Def("haste_master", "Мастер-шахтёр", "спешка III и сила II на 2 минуты", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.HASTE, 2 * MIN1, 2);
						effect(player, StatusEffects.STRENGTH, 2 * MIN1, 1);
					}
					broadcast(server, "§aКирка летает в руках, а удар стал тяжелее!");
				}));

		list.add(new Def("lucky_hour", "Полоса везения", "удача III на 3 минуты — хороший лут и рыбалка", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.LUCK, 3 * MIN1, 2);
					}
					broadcast(server, "§aУдача на твоей стороне!");
				}));

		list.add(new Def("feather_grace", "Пёрышко", "замедленное падение на 3 минуты и прыгучесть III", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.SLOW_FALLING, 3 * MIN1, 0);
						effect(player, StatusEffects.JUMP_BOOST, 2 * MIN1, 2);
					}
					broadcast(server, "§aПадать больше не страшно!");
				}));

		list.add(new Def("inferno_walk", "Огнеход", "огнестойкость и скорость II на 2 минуты", Kind.POSITIVE,
				(server, cfg) -> {
					for (ServerPlayerEntity player : players(server)) {
						effect(player, StatusEffects.FIRE_RESISTANCE, 2 * MIN1, 0);
						effect(player, StatusEffects.SPEED, 2 * MIN1, 1);
					}
					broadcast(server, "§aОгонь больше не жжёт — вперёд, по лаве!");
				}));

		return list;
	}

	// ------------------------------------------------------------------
	//  Мелочи
	// ------------------------------------------------------------------

	private static List<ServerPlayerEntity> players(MinecraftServer server) {
		return server.getPlayerManager().getPlayerList();
	}

	private static Random rand(MinecraftServer server) {
		return server.getOverworld().random;
	}

	/** Ставит каждому игроку по предмету, который создаёт переданная фабрика. */
	private static void giveEach(MinecraftServer server, Supplier<ItemStack> factory) {
		for (ServerPlayerEntity player : players(server)) {
			give(player, factory.get());
		}
	}

	/**
	 * Спавнит моба рядом с точкой. Если target != null и моб умеет целиться — сразу идёт в атаку
	 * на этого игрока (у мирных мобов просто остаётся null).
	 */
	private static MobEntity spawnMob(ServerWorld world, EntityType<?> type, double x, double y, double z,
			Random random, ServerPlayerEntity target) {
		return spawnMob(world, type, x, y, z, random, target, null);
	}

	/**
	 * Ванильная «подготовка» моба: экипировка (лук у скелета, меч у зомби, топор у виндикатора …),
	 * сложность и прочие параметры, которые игра выставляет при обычном спавне и /summon.
	 *
	 * Без этого вызова мобы появлялись «пустыми» — бот-тест показывал у скелетов пустую руку.
	 * Вызывать ДО применения extraNbt: ручной NBT (например, HandItems) должен перекрывать ваниль.
	 */
	private static void prepareMob(ServerWorld world, MobEntity mob, double x, double y, double z) {
		try {
			mob.initialize(world, world.getLocalDifficulty(new BlockPos(x, y, z)), SpawnReason.EVENT, null, null);
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("Could not initialize mob {}: {}", mob.getType(), t.toString());
		}
	}

	/**
	 * Создаёт моба и ставит его в мир.
	 *
	 * @param extraNbt NBT, который надо применить ДО установки позиции (например, DespawnDelay торговца:
	 *                 readNbt сбрасывает координаты на 0,0,0, поэтому порядок важен)
	 */
	private static MobEntity spawnMob(ServerWorld world, EntityType<?> type, double x, double y, double z,
			Random random, ServerPlayerEntity target, NbtCompound extraNbt) {
		Entity entity = type.create(world);
		if (entity == null) {
			return null;
		}
		if (entity instanceof MobEntity) {
			prepareMob(world, (MobEntity) entity, x, y, z);
		}
		if (extraNbt != null) {
			entity.readNbt(extraNbt);
		}
		entity.refreshPositionAndAngles(x, y, z, random.nextFloat() * 360.0F, 0.0F);
		if (target != null && entity instanceof MobEntity) {
			((MobEntity) entity).setTarget(target);
		}
		world.spawnEntity(entity);
		return entity instanceof MobEntity ? (MobEntity) entity : null;
	}

	/** Слизень или магмовый куб самого маленького размера (1) — крупные слишком опасны. */
	private static void spawnSmallSlime(ServerWorld world, EntityType<?> type, double x, double y, double z,
			Random random, boolean target) {
		Entity entity = type.create(world);
		if (entity == null) {
			return;
		}
		if (entity instanceof MobEntity) {
			prepareMob(world, (MobEntity) entity, x, y, z);
		}
		if (entity instanceof SlimeEntity) {
			// setSize у SlimeEntity защищён, поэтому ставим размер тем же NBT-тегом,
			// что и /summon minecraft:slime ~ ~ ~ {Size:1}
			NbtCompound tag = new NbtCompound();
			tag.putInt("Size", 1);
			entity.readNbt(tag);
		}
		entity.refreshPositionAndAngles(x, y, z, random.nextFloat() * 360.0F, 0.0F);
		world.spawnEntity(entity);
	}

	/**
	 * Точка ВПЛОТНУЮ к игроку (0.5–2 блока): с 1.7.0 ТНТ, криперы и молнии приходят вплотную,
	 * а не «где-то в стороне» — хардкор должен быть хардкором.
	 */
	private static double[] closeSpot(ServerPlayerEntity player, Random random, double base, double spread) {
		return ringSpot(player, random, base, spread);
	}

	/**
	 * Точка на «кольце» вокруг игрока: радиус base … base + spread, случайный угол.
	 */
	private static double[] ringSpot(ServerPlayerEntity player, Random random, double base, double spread) {
		double angle = random.nextDouble() * Math.PI * 2.0D;
		double distance = base + random.nextDouble() * spread;
		return new double[]{player.getX() + Math.cos(angle) * distance,
				player.getZ() + Math.sin(angle) * distance};
	}

	/** Ищет рядом с игроком место, где стоит сундук: воздух, а под ним твёрдая опора. */
	private static BlockPos findChestSpot(ServerWorld world, ServerPlayerEntity player, Random random) {
		int px = (int) Math.floor(player.getX());
		int py = (int) Math.floor(player.getY());
		int pz = (int) Math.floor(player.getZ());
		int[][] offsets = {{1, 0}, {0, 1}, {-1, 0}, {0, -1}, {1, 1}, {-1, -1}, {1, -1}, {-1, 1}, {0, 0}};
		for (int i = offsets.length - 1; i > 0; i--) {          // перемешиваем порядок попыток
			int j = random.nextInt(i + 1);
			int[] tmp = offsets[i];
			offsets[i] = offsets[j];
			offsets[j] = tmp;
		}
		for (int[] o : offsets) {
			for (int dy = 0; dy >= -1; dy--) {
				BlockPos pos = new BlockPos(px + o[0], py + dy, pz + o[1]);
				if (world.isAir(pos) && !world.isAir(pos.down())) {
					return pos;
				}
			}
		}
		return new BlockPos(px, py, pz);
	}

	public static void broadcast(MinecraftServer server, String text) {
		broadcast(server, new LiteralText("§6[Событие]§r " + text));
	}

	public static void broadcast(MinecraftServer server, Text text) {
		for (ServerPlayerEntity player : players(server)) {
			player.sendMessage(text, false);
		}
	}

	public static void effect(ServerPlayerEntity player, StatusEffect effect, int ticks, int amplifier) {
		player.addStatusEffect(new StatusEffectInstance(effect, ticks, amplifier));
	}

	public static void give(ServerPlayerEntity player, ItemStack stack) {
		// Текст собираем ДО выдачи: giveItemStack обнуляет стек в случае успеха.
		MutableText message = new LiteralText("§6[Событие]§r ты получил: §e").append(stack.getName());
		if (stack.getCount() > 1) {
			message.append(new LiteralText(" x" + stack.getCount()));
		}
		if (!player.giveItemStack(stack) && !stack.isEmpty()) {
			player.dropItem(stack, false);
		}
		player.sendMessage(message, false);
	}
}
