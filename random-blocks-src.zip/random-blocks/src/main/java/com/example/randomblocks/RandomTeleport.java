package com.example.randomblocks;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Случайные телепорты:
 *
 * <ul>
 *     <li>{@code /rtp} — на случайное место в радиусе 100 блоков;</li>
 *     <li>{@code /rtpfar} — то же, но в радиусе 1000 блоков;</li>
 *     <li>{@code /rtpnear} — рядом со случайным игроком (не вплотную).</li>
 * </ul>
 *
 * <p>Точка выбирается на поверхности: по карте высот ищется столб, где можно стоять —
 * не вода, не листва, есть твёрдый блок под ногами.</p>
 */
public final class RandomTeleport {

	private static final Random RANDOM = new Random();
	private static final int ATTEMPTS = 32;

	private RandomTeleport() {
	}

	/** Случайная точка в радиусе {@code radius} блоков от игрока. */
	public static boolean around(ServerPlayerEntity player, int radius) {
		ServerWorld world = player.getServerWorld();
		for (int attempt = 0; attempt < ATTEMPTS; attempt++) {
			double angle = RANDOM.nextDouble() * Math.PI * 2.0D;
			// от 40% до 100% радиуса — чтобы не телепортировать «на два шага»
			double distance = radius * (0.4D + RANDOM.nextDouble() * 0.6D);
			int x = (int) Math.round(player.getX() + Math.cos(angle) * distance);
			int z = (int) Math.round(player.getZ() + Math.sin(angle) * distance);
			Vec3d spot = findGround(world, x, z);
			if (spot != null) {
				player.teleport(world, spot.x, spot.y, spot.z, player.yaw, player.pitch);
				player.stopRiding();
				player.sendMessage(new LiteralText("§6[Random Blocks]§r телепорт: §e"
						+ (int) spot.x + " " + (int) spot.y + " " + (int) spot.z
						+ " §7(" + (int) Math.round(distance) + " блоков от прежнего места)"), false);
				return true;
			}
		}
		player.sendMessage(new LiteralText("§cНе нашлось подходящего места — попробуй ещё раз."), false);
		return false;
	}

	/** Телепорт рядом со случайным игроком: не вплотную, в 30–80 блоках от него. */
	public static boolean nearPlayer(ServerPlayerEntity player) {
		List<ServerPlayerEntity> others = new ArrayList<>();
		for (ServerPlayerEntity other : player.getServer().getPlayerManager().getPlayerList()) {
			if (other != player) {
				others.add(other);
			}
		}
		if (others.isEmpty()) {
			player.sendMessage(new LiteralText("§cРядом никого нет — телепорт отменён."), false);
			return false;
		}
		ServerPlayerEntity target = others.get(RANDOM.nextInt(others.size()));
		ServerWorld world = target.getServerWorld();
		for (int attempt = 0; attempt < ATTEMPTS; attempt++) {
			double angle = RANDOM.nextDouble() * Math.PI * 2.0D;
			double distance = 30.0D + RANDOM.nextDouble() * 50.0D;
			int x = (int) Math.round(target.getX() + Math.cos(angle) * distance);
			int z = (int) Math.round(target.getZ() + Math.sin(angle) * distance);
			Vec3d spot = findGround(world, x, z);
			if (spot == null) {
				continue;
			}
			player.teleport(world, spot.x, spot.y, spot.z, player.yaw, player.pitch);
			player.stopRiding();
			player.sendMessage(new LiteralText("§6[Random Blocks]§r ты оказался рядом с §e"
					+ target.getEntityName() + "§r — §7" + (int) Math.round(distance) + " блоков от него."), false);
			return true;
		}
		player.sendMessage(new LiteralText("§cНе нашлось места рядом с игроком — попробуй позже."), false);
		return false;
	}

	/** Подходящее место в столбце (x, z) или null. */
	private static Vec3d findGround(ServerWorld world, int x, int z) {
		// Важно: у незагруженного чанка ванильный getTopY возвращает 0, и место «не находится»
		// (из-за этого /rtpfar не работал вовсе). Поэтому сначала грузим чанк точки — на сервере
		// getChunk идёт через ServerChunkManager и при create=true догружает/генерирует его.
		world.getChunk(x >> 4, z >> 4);
		int top = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
		for (int y = top; y > top - 6 && y > 2; y--) {
			BlockPos feet = new BlockPos(x, y, z);
			BlockPos head = feet.up();
			BlockPos below = feet.down();
			if (!world.getBlockState(below).getMaterial().isSolid()) {
				continue;
			}
			if (world.getBlockState(feet).getMaterial().isSolid() || world.getBlockState(head).getMaterial().isSolid()) {
				continue;
			}
			if (world.getBlockState(below).getMaterial().isLiquid()
					|| world.getBlockState(feet).getMaterial().isLiquid()) {
				continue;                               // не в воду
			}
			return new Vec3d(x + 0.5D, y, z + 0.5D);
		}
		return null;
	}
}
