package com.example.randomblocks.gui;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;

/**
 * «Вид» на чужой инвентарь для {@code /invsee}.
 *
 * <p>У инвентаря игрока 41 слот (36 обычных + броня + левая рука), а окну на 6 рядов нужно 54.
 * Напрямую подставить {@link PlayerInventory} нельзя — {@code ScreenHandler.checkSize} падает
 * с исключением (на этом и падала команда /invsee). Поэтому здесь прокси: слотов ровно 54,
 * первые 41 ведут к настоящему инвентарю игрока, остальные всегда пустые.</p>
 */
public class PlayerInventoryView implements Inventory {

	public static final int SLOTS = 54;

	private final PlayerInventory inventory;

	public PlayerInventoryView(PlayerInventory inventory) {
		this.inventory = inventory;
	}

	private static boolean real(int slot) {
		return slot >= 0 && slot < 41;
	}

	@Override
	public int size() {
		return SLOTS;
	}

	@Override
	public boolean isEmpty() {
		return inventory.isEmpty();
	}

	@Override
	public ItemStack getStack(int slot) {
		return real(slot) ? inventory.getStack(slot) : ItemStack.EMPTY;
	}

	@Override
	public ItemStack removeStack(int slot, int amount) {
		return real(slot) ? inventory.removeStack(slot, amount) : ItemStack.EMPTY;
	}

	@Override
	public ItemStack removeStack(int slot) {
		return real(slot) ? inventory.removeStack(slot) : ItemStack.EMPTY;
	}

	@Override
	public void setStack(int slot, ItemStack stack) {
		if (real(slot)) {
			inventory.setStack(slot, stack);
		}
	}

	@Override
	public void markDirty() {
		inventory.markDirty();
	}

	@Override
	public boolean canPlayerUse(PlayerEntity player) {
		return true;
	}

	@Override
	public void clear() {
		inventory.clear();
	}

	/** Открытие/закрытие окна не должно трогать настоящий инвентарь игрока. */
	@Override
	public void onOpen(PlayerEntity player) {
	}

	@Override
	public void onClose(PlayerEntity player) {
	}
}
