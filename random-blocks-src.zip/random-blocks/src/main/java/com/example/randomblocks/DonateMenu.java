package com.example.randomblocks;

import com.example.randomblocks.gui.DonateScreenHandler;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Меню привилегий {@code /donate} (1.13.0).
 *
 * <p>Большой сундук (6 рядов): каждая привилегия — свой цветной шалкер с названием, описанием
 * (что она даёт) и ценой. Наведись на шалкер — увидишь описание и цену в подсказке; клик — как
 * купить. Привилегию OWNER в меню не показываем: это сам владелец, её не продают.</p>
 */
public final class DonateMenu {

	/** Что продаём: привилегия → цена в рублях. */
	private static final Map<Rank, Integer> PRICES = new LinkedHashMap<>();
	private static final Map<Rank, Item> ICONS = new LinkedHashMap<>();
	/** Слот окна → привилегия (по ним и ловим клик). */
	private static final Map<Integer, Rank> SLOTS = new LinkedHashMap<>();

	static {
		PRICES.put(Rank.HERO, 49);
		PRICES.put(Rank.TITAN, 129);
		PRICES.put(Rank.AVENDER, 239);
		PRICES.put(Rank.OVERLORD, 349);
		PRICES.put(Rank.MAGISTER, 548);
		PRICES.put(Rank.IMPERATOR, 879);
		PRICES.put(Rank.DRAGON, 1299);

		ICONS.put(Rank.HERO, Items.BLUE_SHULKER_BOX);
		ICONS.put(Rank.TITAN, Items.YELLOW_SHULKER_BOX);
		ICONS.put(Rank.AVENDER, Items.PURPLE_SHULKER_BOX);
		ICONS.put(Rank.OVERLORD, Items.GREEN_SHULKER_BOX);
		ICONS.put(Rank.MAGISTER, Items.ORANGE_SHULKER_BOX);
		ICONS.put(Rank.IMPERATOR, Items.RED_SHULKER_BOX);
		ICONS.put(Rank.DRAGON, Items.MAGENTA_SHULKER_BOX);

		int slot = 10;                        // второй ряд сундука 9×6
		for (Rank rank : PRICES.keySet()) {
			SLOTS.put(slot++, rank);
		}
	}

	private DonateMenu() {
	}

	/** Открыть меню привилегий. */
	public static void open(ServerPlayerEntity player) {
		SimpleInventory inventory = new SimpleInventory(54);
		for (Map.Entry<Integer, Rank> entry : SLOTS.entrySet()) {
			inventory.setStack(entry.getKey(), stack(entry.getValue()));
		}
		// Подсказка внизу: как купить.
		ItemStack info = new ItemStack(Items.PAPER);
		info.setCustomName(new LiteralText("§e§lКак купить"));
		addLore(info, "§7Цены — в рилликах (₽).",
				"§7Нажми на привилегию, чтобы купить её сразу.",
				"§7Купить можно только привилегию выше своей.",
				"§7Привилегия сразу видна в чате, табе и над головой.");
		inventory.setStack(49, info);

		player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
				(syncId, playerInventory, viewer) -> new DonateScreenHandler(syncId, playerInventory, inventory),
				new LiteralText("§6§lДонат-привилегии")));
	}

	/** Клик по шалкеру в меню: показываем, что это и сколько стоит. */
	public static void handleClick(ServerPlayerEntity player, int slotId) {
		Rank rank = SLOTS.get(slotId);
		if (rank == null) {
			return;
		}
		int price = PRICES.getOrDefault(rank, 0);
		Rank current = RankManager.rankOf(player);
		player.sendMessage(new LiteralText("§6[Донат]§r привилегия " + rank.prefix() + "§r — §a"
				+ price + " рилликов§r. " + description(rank)), false);
		if (Permissions.isOwner(player)) {
			player.sendMessage(new LiteralText("§7Выдать: §f/rank user <ник> parent set " + rank.name.toLowerCase()), false);
			return;
		}
		// Покупка за риллики: только привилегия ВЫШЕ текущей, и только если хватает денег.
		if (rank.weight <= current.weight) {
			player.sendMessage(new LiteralText("§cОна не выше твоей текущей (" + current.prefix()
					+ "§c) — понижать привилегию нельзя."), false);
			play(player, net.minecraft.sound.SoundEvents.BLOCK_NOTE_BLOCK_BASS, 1.0F, 0.7F);
			return;
		}
		long rubles = Economy.rubles(player.getUuid());
		if (rubles < price) {
			player.sendMessage(new LiteralText("§cНе хватает рилликов: нужно §e" + price
					+ "§c, у тебя §e" + rubles + "§c. Недостаёт: §e" + (price - rubles)), false);
			play(player, net.minecraft.sound.SoundEvents.BLOCK_NOTE_BLOCK_BASS, 1.0F, 0.7F);
			return;
		}
		Economy.setRubles(player.getUuid(), player.getEntityName(), rubles - price);
		RankManager.setRank(player.getUuid(), player.getEntityName(), rank);
		RankManager.applySafe(player, rank);
		player.sendMessage(new LiteralText("§aКуплено! Привилегия " + rank.prefix() + " §aактивирована за §e"
				+ price + " рилликов§a. Осталось: §e" + Economy.rubles(player.getUuid())), false);
		play(player, net.minecraft.sound.SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0F, 1.2F);
		RandomBlocks.LOGGER.info("Donate purchase: {} bought {} for {} rubles", player.getEntityName(),
				rank.name, price);
	}

	private static void play(ServerPlayerEntity player, net.minecraft.sound.SoundEvent sound, float volume, float pitch) {
		try {
			player.playSound(sound, net.minecraft.sound.SoundCategory.PLAYERS, volume, pitch);
		} catch (Throwable ignored) {
			// звук — не критично
		}
	}

	/** «Что даёт привилегия» — по перкам из мода. */
	public static String description(Rank rank) {
		switch (rank) {
			case HERO:
				return "§7кит, §f/craft§7, §f/rtp§7, 2 дома";
			case TITAN:
				return "§7+ §f/hat§7, §f/feed§7, §f/rtpfar§7, 4 дома";
			case AVENDER:
				return "§7+ §f/ec§7, §f/ext§7, §f/clear§7, 6 домов";
			case OVERLORD:
				return "§7+ §f/repair§7, §f/near§7, 12 домов";
			case MAGISTER:
				return "§7+ §f/invsee§7, §f/repair all§7, §f/heal§7, 32 дома";
			case IMPERATOR:
				return "§7+ §f/broadcast§7, §f/lightning§7, §f/rtpnear§7, 48 домов";
			case DRAGON:
				return "§7+ §f/fly§7, §f/grant§7, погода и время, 100 домов";
			default:
				return "";
		}
	}

	private static ItemStack stack(Rank rank) {
		ItemStack stack = new ItemStack(ICONS.getOrDefault(rank, Items.SHULKER_BOX));
		stack.setCustomName(new LiteralText(rank.prefix() + " §r§7— §a" + PRICES.getOrDefault(rank, 0) + " рилликов"));
		addLore(stack, "§7Что даёт: " + description(rank),
				"§7Цена: §a" + PRICES.getOrDefault(rank, 0) + " рилликов",
				"§eНажми, чтобы купить",
				"§8Ниже своей привилегии купить нельзя");
		return stack;
	}

	/** Подсказка (lore) у предмета: строки — обычный текст, переводим в NBT как JSON. */
	public static void addLore(ItemStack stack, String... lines) {
		NbtList lore = new NbtList();
		for (String line : lines) {
			Text text = new LiteralText(line);
			lore.add(NbtString.of(Text.Serializer.toJson(text)));
		}
		stack.getOrCreateSubTag("display").put("Lore", lore);
	}
}
