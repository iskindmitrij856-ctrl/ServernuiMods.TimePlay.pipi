package com.example.randomblocks.command;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Подсказки для команд (1.13.0): чтобы при вводе {@code /ban}, {@code /eco}, {@code /dk} и других
 * клиент показывал, что можно вписать — ники, время, причины.
 */
public final class Suggestions {

	private Suggestions() {
	}

	/** Ники игроков в сети. */
	public static final SuggestionProvider<ServerCommandSource> NICKS = (context, builder) -> {
		try {
			for (ServerPlayerEntity player : context.getSource().getMinecraftServer()
					.getPlayerManager().getPlayerList()) {
				builder.suggest(player.getEntityName());
			}
		} catch (Throwable ignored) {
			// подсказок не будет — команда всё равно работает
		}
		return builder.buildFuture();
	};

	/** Время: как везде в моде (10s/10m/1h), плюс «forever» для бана. */
	public static final SuggestionProvider<ServerCommandSource> TIMES = (context, builder) -> {
		for (String value : new String[]{"30s", "1m", "5m", "30m", "1h", "6h", "1d", "7d", "forever"}) {
			builder.suggest(value);
		}
		return builder.buildFuture();
	};

	/** Типовые причины бана. */
	public static final SuggestionProvider<ServerCommandSource> BAN_REASONS = (context, builder) -> {
		for (String value : new String[]{"чит", "оскорбления", "гриферство", "спам", "нарушение правил"}) {
			builder.suggest(value);
		}
		return builder.buildFuture();
	};

	/** Привилегии — для /rank и /grant. */
	public static final SuggestionProvider<ServerCommandSource> RANKS = (context, builder) -> {
		for (String value : new String[]{"player", "hero", "titan", "avender", "overlord", "magister",
				"imperator", "dragon", "owner"}) {
			builder.suggest(value);
		}
		return builder.buildFuture();
	};

	/** Подсказка-текст для пустого ввода (когда аргумент не назван). */
	public static int usage(CommandContext<ServerCommandSource> context, String text) {
		context.getSource().sendFeedback(new net.minecraft.text.LiteralText(text), false);
		return 0;
	}
}
