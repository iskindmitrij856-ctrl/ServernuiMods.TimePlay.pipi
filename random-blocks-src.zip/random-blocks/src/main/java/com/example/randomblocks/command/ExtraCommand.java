package com.example.randomblocks.command;

import com.example.randomblocks.CombatTag;
import com.example.randomblocks.DonateMenu;
import com.example.randomblocks.Economy;
import com.example.randomblocks.Permissions;
import com.example.randomblocks.RandomBlocks;
import com.example.randomblocks.RankManager;
import com.example.randomblocks.gui.ViewInventoryScreenHandler;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.util.Formatting;
import net.minecraft.world.GameMode;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Новые команды 1.13.0.
 *
 * <p>Игрокам:</p>
 * <ul>
 *     <li>{@code /tpa <ник>} — запрос на телепорт: у второго игрока в чате появляются кнопки
 *         «Принять» и «Отклонить» (они же команды {@code /tpaccept} и {@code /tpdeny});</li>
 *     <li>{@code /gm 0|1|2|3} — режим игры (выживание, креатив, приключение, наблюдатель);</li>
 *     <li>{@code /eco give|set|remove <ник> <сумма>} — обычные деньги;</li>
 *     <li>{@code /p give|set|remove <ник> <сумма>} — риллики;</li>
 *     <li>{@code /kits} — меню китов и {@code /kit <название>} — выдача кита (пока в разработке).</li>
 * </ul>
 *
 * <p>OWNER: {@code /s <ник>} — игрок к тебе, {@code /tp <ник>} — ты к игроку;
 * блокировки — в {@link BanCommand}.</p>
 */
public final class ExtraCommand {

	private static final Map<UUID, Request> REQUESTS = new HashMap<>();

	private static final class Request {
		UUID from;
		String fromName;
		long at;
	}

	private ExtraCommand() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
			try {
				registerAll(dispatcher);
				RandomBlocks.LOGGER.info("Extra commands registered");
			} catch (Throwable t) {
				RandomBlocks.LOGGER.error("Extra commands not registered: {}", t.toString());
			}
		});
	}

	private static void registerAll(CommandDispatcher<ServerCommandSource> dispatcher) {
		// /s — OWNER телепортирует игрока к себе.
		dispatcher.register(CommandManager.literal("s")
				.executes(context -> Suggestions.usage(context, "§6Как использовать: §e/s <ник>§7 — игрок телепортируется к тебе."))
				.then(CommandManager.argument("ник", StringArgumentType.word()).suggests(Suggestions.NICKS)
						.executes(ExtraCommand::teleportHere)));

		// /tp — OWNER телепортируется к игроку. Ванильный /tp (координаты, цели) сохраняем:
		// просто делаем его доступным и владельцу, и добавляем короткую ветку «/tp <ник>».
		graftTeleport(dispatcher);

		dispatcher.register(CommandManager.literal("tpa")
				.executes(context -> Suggestions.usage(context, "§6Как использовать: §e/tpa <ник>§7 — попросить телепорт к игроку."))
				.then(CommandManager.argument("ник", StringArgumentType.word()).suggests(Suggestions.NICKS)
						.executes(ExtraCommand::requestTeleport)));
		dispatcher.register(CommandManager.literal("tpaccept")
				.then(CommandManager.argument("ник", StringArgumentType.word())
						.executes(ExtraCommand::acceptTeleport)));
		dispatcher.register(CommandManager.literal("tpdeny")
				.then(CommandManager.argument("ник", StringArgumentType.word())
						.executes(ExtraCommand::denyTeleport)));

		dispatcher.register(CommandManager.literal("gm")
				.executes(context -> Suggestions.usage(context, "§6Как использовать: §e/gm 0|1|2|3§7 (выживание, креатив, приключение, наблюдатель)."))
				.then(CommandManager.argument("режим", IntegerArgumentType.integer(0, 3))
						.suggests((context, builder) -> {
							for (String value : new String[]{"0", "1", "2", "3"}) {
								builder.suggest(value);
							}
							return builder.buildFuture();
						})
						.executes(context -> gameMode(context, IntegerArgumentType.getInteger(context, "режим")))));

		dispatcher.register(CommandManager.literal("eco")
				.executes(context -> Suggestions.usage(context, "§6Как использовать: §e/eco give|set|remove <ник> <сумма>§7 — деньги."))
				.then(moneyBranch("give", Kind.ADD, true))
				.then(moneyBranch("set", Kind.SET, true))
				.then(moneyBranch("remove", Kind.REMOVE, true)));
		dispatcher.register(CommandManager.literal("p")
				.executes(context -> Suggestions.usage(context, "§6Как использовать: §e/p give|set|remove <ник> <сумма>§7 — риллики."))
				.then(moneyBranch("give", Kind.ADD, false))
				.then(moneyBranch("set", Kind.SET, false))
				.then(moneyBranch("remove", Kind.REMOVE, false)));

		dispatcher.register(CommandManager.literal("donate").executes(ExtraCommand::openDonate));

		dispatcher.register(CommandManager.literal("kits").executes(ExtraCommand::openKits));
		dispatcher.register(CommandManager.literal("kit")
				.executes(context -> Suggestions.usage(context, "§6Как использовать: §e/kit <название>§7 — выдать кит (пока в разработке)."))
				.then(CommandManager.argument("название", StringArgumentType.greedyString())
						.executes(ExtraCommand::giveKit)));
	}

	/**
	 * Ванильный {@code /tp} требует OP. Здесь узел пересобирается: требование становится
	 * «OP или владелец (OWNER)», все ванильные ветки (координаты, цели) переносятся как есть,
	 * а сверху добавляется короткая ветка {@code /tp <ник>} — телепорт к игроку.
	 */
	/**
	 * Ванильный {@code /tp} требует OP и умеет координаты/цели. Здесь доступ у узла расширяется
	 * на владельца (OWNER), а сверху добавляется короткая ветка {@code /tp <ник>} — телепорт к игроку.
	 * Все ванильные ветки остаются нетронутыми (узел не пересобираем).
	 */
	private static void graftTeleport(CommandDispatcher<ServerCommandSource> dispatcher) {
		try {
			com.mojang.brigadier.tree.CommandNode<ServerCommandSource> root = dispatcher.getRoot();
			com.mojang.brigadier.tree.CommandNode<ServerCommandSource> node = root.getChild("tp");
			if (node == null) {
				RandomBlocks.LOGGER.warn("Ванильный /tp не найден — регистрируем только /tp <ник>");
				dispatcher.register(CommandManager.literal("tp")
						.requires(Permissions::ownerOrOp)
						.then(CommandManager.argument("ник", StringArgumentType.word()).suggests(Suggestions.NICKS)
								.executes(ExtraCommand::teleportToPlayer)));
				return;
			}
			// 1) доступ: как было (OP) или владелец мира.
			java.lang.reflect.Field requirement = com.mojang.brigadier.tree.CommandNode.class
					.getDeclaredField("requirement");
			requirement.setAccessible(true);
			requirement.set(node, (java.util.function.Predicate<ServerCommandSource>)
					source -> source.hasPermissionLevel(2) || Permissions.ownerOrOp(source));
			// 2) наша ветка «/tp <ник>» добавляется к существующему узлу: ванильные дети сохраняются.
			node.addChild(CommandManager.argument("ник", StringArgumentType.word()).suggests(Suggestions.NICKS)
					.executes(ExtraCommand::teleportToPlayer).build());
			RandomBlocks.LOGGER.info("Vanilla /tp kept and extended with /tp <ник> (ветки: {})",
					node.getChildren().size());
		} catch (Throwable t) {
			RandomBlocks.LOGGER.warn("Could not graft /tp: {}", t.toString());
		}
	}

	private enum Kind {ADD, SET, REMOVE}

	private static LiteralArgumentBuilder<ServerCommandSource> moneyBranch(String name, Kind kind, boolean money) {
		return CommandManager.literal(name)
				.then(CommandManager.argument("ник", StringArgumentType.word()).suggests(Suggestions.NICKS)
						.then(CommandManager.argument("сумма", LongArgumentType.longArg(0L))
								.executes(context -> money(context, kind, money))));
	}

	// ------------------------------------------------------------------
	//  OWNER: телепорты
	// ------------------------------------------------------------------

	private static int teleportHere(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		if (!Permissions.isOwner(player)) {
			context.getSource().sendError(new LiteralText("§cКоманда только для привилегии OWNER."));
			return 0;
		}
		ServerPlayerEntity target = target(context);
		if (target == null) {
			return 0;
		}
		target.teleport(player.getServerWorld(), player.getX(), player.getY(), player.getZ(),
				target.yaw, target.pitch);
		target.stopRiding();
		player.sendMessage(new LiteralText("§6[Random Blocks]§r §e" + target.getEntityName()
				+ "§r телепортирован к тебе."), false);
		target.sendMessage(new LiteralText("§6[Random Blocks]§r тебя телепортировал §e"
				+ player.getEntityName() + "§r."), false);
		return 1;
	}

	private static int teleportToPlayer(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		if (!Permissions.isOwner(player)) {
			context.getSource().sendError(new LiteralText("§cКоманда только для привилегии OWNER."));
			return 0;
		}
		ServerPlayerEntity target = target(context);
		if (target == null) {
			return 0;
		}
		player.teleport(target.getServerWorld(), target.getX(), target.getY(), target.getZ(),
				player.yaw, player.pitch);
		player.stopRiding();
		player.sendMessage(new LiteralText("§6[Random Blocks]§r телепорт к §e"
				+ target.getEntityName() + "§r."), true);
		return 1;
	}

	// ------------------------------------------------------------------
	//  /tpa
	// ------------------------------------------------------------------

	private static int requestTeleport(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		ServerPlayerEntity target = target(context);
		if (target == null) {
			return 0;
		}
		if (target == player) {
			player.sendMessage(new LiteralText("§cСебе запрос отправлять не нужно."), false);
			return 0;
		}
		if (CombatTag.tagged(player)) {
			player.sendMessage(new LiteralText(CombatTag.message(player)), false);
			return 0;
		}
		Request request = new Request();
		request.from = player.getUuid();
		request.fromName = player.getEntityName();
		request.at = System.currentTimeMillis();
		REQUESTS.put(target.getUuid(), request);

		player.sendMessage(new LiteralText("§6[Random Blocks]§r запрос на телепорт отправлен: §e"
				+ target.getEntityName() + "§r (ждём 60 секунд)."), false);
		target.sendMessage(new LiteralText("§6[Random Blocks]§r §e" + player.getEntityName()
						+ "§r просит телепортироваться к тебе. ")
						.append(button("Принять", "/tpaccept " + player.getEntityName(), Formatting.GREEN))
						.append(new LiteralText(" "))
						.append(button("Отклонить", "/tpdeny " + player.getEntityName(), Formatting.RED)), false);
		return 1;
	}

	private static MutableText button(String label, String command, Formatting formatting) {
		return new LiteralText("[" + label + "]").setStyle(net.minecraft.text.Style.EMPTY
				.withColor(formatting)
				.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, command))
				.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new LiteralText("нажми: " + command))));
	}

	private static int acceptTeleport(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		Request request = find(player, StringArgumentType.getString(context, "ник"));
		if (request == null) {
			return 0;
		}
		ServerPlayerEntity from = player.getServer().getPlayerManager().getPlayer(request.from);
		if (from == null) {
			player.sendMessage(new LiteralText("§cЭтот игрок уже вышел."), false);
			REQUESTS.remove(player.getUuid());
			return 0;
		}
		from.teleport(player.getServerWorld(), player.getX(), player.getY(), player.getZ(),
				from.yaw, from.pitch);
		from.stopRiding();
		from.sendMessage(new LiteralText("§6[Random Blocks]§r телепорт к §e"
				+ player.getEntityName() + "§r выполнен."), false);
		player.sendMessage(new LiteralText("§6[Random Blocks]§r запрос от §e" + from.getEntityName()
				+ "§r принят."), false);
		REQUESTS.remove(player.getUuid());
		return 1;
	}

	private static int denyTeleport(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		Request request = find(player, StringArgumentType.getString(context, "ник"));
		if (request == null) {
			return 0;
		}
		ServerPlayerEntity from = player.getServer().getPlayerManager().getPlayer(request.from);
		if (from != null) {
			from.sendMessage(new LiteralText("§c" + player.getEntityName() + " отклонил запрос на телепорт."), false);
		}
		player.sendMessage(new LiteralText("§6[Random Blocks]§r запрос отклонён."), false);
		REQUESTS.remove(player.getUuid());
		return 1;
	}

	private static Request find(ServerPlayerEntity player, String name) {
		Request request = REQUESTS.get(player.getUuid());
		if (request == null) {
			player.sendMessage(new LiteralText("§cНикто не просил телепорт (или запрос устарел)."), false);
			return null;
		}
		if (System.currentTimeMillis() - request.at > 60_000L) {
			REQUESTS.remove(player.getUuid());
			player.sendMessage(new LiteralText("§cЗапрос устарел — попроси заново."), false);
			return null;
		}
		if (name != null && !name.equalsIgnoreCase(request.fromName)) {
			player.sendMessage(new LiteralText("§cПоследний запрос был от §e" + request.fromName + "§c."), false);
			return null;
		}
		return request;
	}

	// ------------------------------------------------------------------
	//  /gm
	// ------------------------------------------------------------------

	private static int gameMode(CommandContext<ServerCommandSource> context, int mode) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		if (CombatTag.tagged(player)) {
			player.sendMessage(new LiteralText(CombatTag.message(player)), false);
			return 0;
		}
		GameMode[] modes = {GameMode.SURVIVAL, GameMode.CREATIVE, GameMode.ADVENTURE, GameMode.SPECTATOR};
		GameMode gameMode = modes[Math.max(0, Math.min(3, mode))];
		player.setGameMode(gameMode);
		player.sendMessage(new LiteralText("§6[Random Blocks]§r режим игры: §e" + names(gameMode) + "§r."), false);
		return 1;
	}

	private static String names(GameMode mode) {
		switch (mode) {
			case CREATIVE:
				return "креатив (/gm 1)";
			case ADVENTURE:
				return "приключение (/gm 2)";
			case SPECTATOR:
				return "наблюдатель (/gm 3)";
			default:
				return "выживание (/gm 0)";
		}
	}

	// ------------------------------------------------------------------
	//  /eco и /p
	// ------------------------------------------------------------------

	private static int money(CommandContext<ServerCommandSource> context, Kind kind, boolean money)
			throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		String name = StringArgumentType.getString(context, "ник");
		long amount = LongArgumentType.getLong(context, "сумма");

		UUID uuid = Economy.uuidByName(name);
		ServerPlayerEntity online = player.getServer().getPlayerManager().getPlayer(name);
		if (uuid == null && online != null) {
			uuid = online.getUuid();
		}
		if (uuid == null) {
			player.sendMessage(new LiteralText("§cИгрок §e" + name
					+ "§c не найден: пусть хотя бы раз зайдёт на сервер."), false);
			return 0;
		}
		String displayName = online != null ? online.getEntityName() : name;
		long current = money ? Economy.money(uuid) : Economy.rubles(uuid);
		long result;
		switch (kind) {
			case SET:
				result = amount;
				break;
			case REMOVE:
				result = current - amount;
				break;
			default:
				result = current + amount;
				break;
		}
		result = Math.max(0L, result);
		if (money) {
			Economy.setMoney(uuid, displayName, result);
		} else {
			Economy.setRubles(uuid, displayName, result);
		}
		String currency = money ? "деньги" : "риллики";
		player.sendMessage(new LiteralText("§6[Random Blocks]§r " + currency + " §e" + displayName
				+ "§r: §a" + Economy.format(result) + "§r" + (kind == Kind.SET ? " (установлено)"
				: " (было " + Economy.format(current) + ")") + "."), false);
		if (online != null && online != player) {
			online.sendMessage(new LiteralText("§6[Random Blocks]§r твои " + currency + ": §a"
					+ Economy.format(result) + "§r."), false);
		}
		return 1;
	}

	// ------------------------------------------------------------------
	//  /kits и /kit
	// ------------------------------------------------------------------

	private static int openKits(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		SimpleInventory inventory = new SimpleInventory(54);
		// Пока пусто: наборы ещё в разработке. Когда появятся — предметы-иконки раскладываются
		// в этот же инвентарь, а выдача делается по клику (см. README, раздел «Киты»).
		player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
				(syncId, playerInventory, viewer) -> new ViewInventoryScreenHandler(syncId, playerInventory,
						inventory, false),
				new LiteralText("§6§lКиты")));
		player.sendMessage(new LiteralText("§7Киты пока пустые — наборы появятся в следующих версиях."), false);
		return 1;
	}

	private static int openDonate(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		DonateMenu.open(player);
		return 1;
	}

	private static int giveKit(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
		ServerPlayerEntity player = context.getSource().getPlayer();
		String name = StringArgumentType.getString(context, "название");
		player.sendMessage(new LiteralText("§6[Random Blocks]§r кит «§e" + name
				+ "§r» ещё в разработке — готовые наборы появятся в меню §e/kits§r."), false);
		return 1;
	}

	// ------------------------------------------------------------------

	private static ServerPlayerEntity target(CommandContext<ServerCommandSource> context) {
		String name = StringArgumentType.getString(context, "ник");
		ServerPlayerEntity target = context.getSource().getMinecraftServer().getPlayerManager().getPlayer(name);
		if (target == null) {
			context.getSource().sendError(new LiteralText("§cИгрок §e" + name + "§c не в сети."));
		}
		return target;
	}

	/** Ник с привилегией — для сообщений (используется в других командах). */
	public static String decorated(ServerPlayerEntity player) {
		return RankManager.rankOf(player).decorate(player.getEntityName());
	}
}
